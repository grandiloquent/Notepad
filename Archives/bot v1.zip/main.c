
// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"
//===
// RECT dRect;
// GetWindowRect(GetDesktopWindow(),&dRect);

//===
static BOOL mStatus = FALSE;
static BOOL mStatus1 = FALSE;
static BOOL mStatus2 = FALSE;

static int mCout = 0;

void StrategySearch() {
  printf("Run Strategy.\n");
  _MouseClick(1090, 90, FALSE, FALSE);
  Sleep(1000);
  // 修改此处坐标，改变自动寻路目的地

  //华山地宫2层
  // int pos[][2] = {{701, 528}, {789, 289}};
  //出云北郊
  // int pos[][2] = {{565, 448}, {860, 379}};
  //出云之角
  // int pos[][2] = {{828, 428}, {470, 376}};
  //青山脚
  // int pos[][2] = {{507,367}, {869,448}};
  // 大秦山
  int pos[][2] = {{930, 384}, {520, 313}};

  if (mCout > 10) {
    _MouseClick(pos[0][0], pos[0][1], TRUE, FALSE);
    mCout++;
    if (mCout > 20) mCout = 0;
  } else {
    mCout++;
    _MouseClick(pos[1][0], pos[1][1], TRUE, FALSE);
  }

  Sleep(1000);
  _MouseClick(1090, 90, FALSE, FALSE);
  Sleep(1000);
  _MouseClick(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, FALSE, FALSE);
  Sleep(1000);
}

void GetCursorPixelColor() {
  char *buf = _GetPixelUnderMouse();
  printf(buf);
  if (buf) {
    _ClipboardSetText(buf);
  }
}
BOOL CheckPixelColor() {
  HDC hdc = GetDC(NULL);
  const size_t len = 2;
  //
  int pos[][2] = {{395, 37}, {386, 45}};
  int rgb[][3] = {{255, 238, 170}, {0, 0, 0}};
  if (hdc) {
    COLORREF crf = GetPixel(hdc, 375, 34);
    if (GetRValue(crf) == 189 || GetGValue(crf) == 179 || GetBValue(crf) == 179)
      return FALSE;
    for (size_t i = 0; i < len; i++) {
      COLORREF cr = GetPixel(hdc, pos[i][0], pos[i][1]);
      if (GetRValue(cr) != rgb[i][0] || GetGValue(cr) != rgb[i][1] ||
          GetBValue(cr) != rgb[i][2])
        return FALSE;
    }
    ReleaseDC(NULL, hdc);
    return TRUE;
  }
  return FALSE;
}

DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  int count = 0;
  int cf = 0;
  while (1) {
    count++;
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 376, 33) == 0xB3B3BD) {
        printf("%s\n", "The target is somthing for task, skip.");
        // 取消选定怪物
        _MouseClick(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, TRUE, FALSE);
        Sleep(1000);
        StrategySearch();
        continue;
      }
      // 447 614 FF5A5A
      if (GetPixel(hdc, 447, 614) == 0x5a5aff) {
        // 检查是否与怪物之间有阻隔
        // 如果阻隔尝试自动寻路
        printf("%s\n",
               "There is a barrier between the character and the target.");
        // 取消选定怪物
        _MouseClick(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2, TRUE, FALSE);
        Sleep(1000);
        // 清空聊天框标记
        _MouseClick(185, 586, FALSE, FALSE);

        StrategySearch();
        continue;
      }
      // 305 41 FFAA22
      if (GetPixel(hdc, 310, 42) != 0x22AA11) {
        _SendKeyBackground(hWnd, 0x71);
        Sleep(1000);
      }
      // 395,37 394,36

      if (GetPixel(hdc, 395, 37) == 0xAAEEFF &&
          GetPixel(hdc, 394, 36) == 0x112244) {
        cf = 0;
        _SendKeyBackground(hWnd, 0x70);
        Sleep(1000);
      } else {
        if (count > 100) {
          // 如果没有锁定怪物
          // 加状态
          count = 0;
          Sleep(1000);
          // 防御术 0 2
          _SendKeyWithAlt(hWnd, 0x36);
          Sleep(2500);
          // 祝福术 0 2.5
          _SendKeyWithAlt(hWnd, 0x37);
          Sleep(2500);
        }
        if (cf > 2) {
          cf = 0;
          printf("[=] Don't match color so move.");
          StrategySearch();
        } else {
          // Tab;
          _SendKeyBackground(hWnd, 0x9);
          Sleep(1000);
          cf++;
        }
      }

      ReleaseDC(NULL, hdc);
    }
  }
  return 0;
}
DWORD WINAPI StrategyAutoFight(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  const size_t len = 100;
  int count = 0;
  while (1) {
    if (count > len) {
      count = 0;
      Sleep(1000);
      // 防御术 0 2
      _SendKeyWithAlt(hWnd, 0x36);
      Sleep(2500);
      // 祝福术 0 2.5
      _SendKeyWithAlt(hWnd, 0x37);
      Sleep(2500);
    }
    count++;
    if (count % 5 == 0) {
      // 30 级
      _SendKeyBackground(hWnd, 0x72);
      Sleep(1000);
      _SendKeyBackground(hWnd, 0x71);
      Sleep(1000);
    }
    _SendKeyBackground(hWnd, 0x70);
    Sleep(1000);
  }
  return 0;
}
DWORD WINAPI StrategyHardly(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  // setlocale(LC_ALL, "");
  while (1) {
    // _SendKeyBackground(hWnd, 0x70);
    // Sleep(1000);
    _SendKeyBackground(hWnd, 0x71);
    Sleep(1000);
    // 30 级
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
    // PostMessage(hWnd, 0x0100, 0xD, 0);
    // PostMessage(hWnd, 0x0101, 0xD, 0);
    // char str[] = "30ys+++";
    // for (int i = 0; i < strlen(str); i++) {
    //   PostMessage(hWnd, WM_CHAR, str[i] & 0xFF, 0);
    // }
    // // int buf[11] = {51, 48, 121, 115, 230, 177, 130, 231, 187, 132, 46};
    // // for (int i = 0; i < 11; i++) {
    // //   PostMessage(hWnd, WM_CHAR, buf[i], 0);
    // // }
    // PostMessage(hWnd, 0x0100, 0xD, 0);
    // PostMessage(hWnd, 0x0101, 0xD, 0);
    // Sleep(8000);
  }
  return 0;
}
int main() {
  // _PrintPixelColor(447, 614);
  //    Color color={0};
  //    printf("%d\n",color.r);
  //    _PixelColor(&color,100,199);
  //   printf("%d\n",color.r);
  //===
  //
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  //===
  int keyId = 1;
  int keyId1 = 2;
  int keyId2 = 3;
  int keyId3 = 4;
  int keyId4 = 5;

  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId1, MOD_CONTROL, 0x32)) {
    printf("Register Hotkey: [Ctrl+2] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId2, MOD_CONTROL, 0x33)) {
    printf("Register Hotkey: [Ctrl+3] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId3, 0x0, 0x74)) {
    printf("Register Hotkey: [F5] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId4, MOD_CONTROL, 0x4D)) {
    printf("Register Hotkey: [Ctrl+M] Success.\n");
  }
  //===

  MSG msg = {0};
  HANDLE hThread = {0};
  HANDLE hThread1 = {0};
  HANDLE hThread2 = {0};

  DWORD dwThreadIdArray[3];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        if (!hThread) {
          hThread = CreateThread(NULL, 0, StrategyAutoFight, hWnd, 0,
                                 &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      } else if (msg.wParam == keyId1) {
        if (!hThread1) {
          hThread1 = CreateThread(NULL, 0, StrategyHardly, hWnd, 0,
                                  &dwThreadIdArray[1]);
          mStatus1 = TRUE;
          printf("Create Thread 2.\n");
        } else {
          if (mStatus1) {
            SuspendThread(hThread1);
            mStatus1 = FALSE;
            printf("Suspend Thread 2.\n");
          } else {
            ResumeThread(hThread1);
            mStatus1 = TRUE;
            printf("Resume Thread 2.\n");
          }
        }
      } else if (msg.wParam == keyId2) {
        if (!hThread2) {
          hThread2 =
              CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[2]);
          mStatus2 = TRUE;
          printf("Create Thread 3.\n");
        } else {
          if (mStatus2) {
            SuspendThread(hThread2);
            mStatus2 = FALSE;
            printf("Suspend Thread 3.\n");
          } else {
            ResumeThread(hThread2);
            mStatus2 = TRUE;
            printf("Resume Thread 3.\n");
          }
        }
      } else if (msg.wParam == keyId3) {
        _PrintMousePosition();
      } else if (msg.wParam == keyId4) {
        
      }
    }
  }
  return 0;
}
