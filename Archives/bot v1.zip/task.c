// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"
#include "qfx.h"

void FamliyTaskXiJiao(HWND hWnd) {
  OpenMap();
  _ClickRight(524, 297);
  Sleep(1000);
  CloseMap();
  int coordinates[2][3] = {{1110, 5, 0x10CFFF}, {1113, 12, 0x10CFFF}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // 0xbbggrr
      if (coordinates[0][2] ==
              GetPixel(hdc, coordinates[0][0], coordinates[0][1]) &&
          coordinates[1][2] ==
              GetPixel(hdc, coordinates[1][0], coordinates[1][1])) {
        // 点击自动寻路图标
        _Click(1121, 171);
        Sleep(1000);

        // 点击地图菜单项
        _Click(1075, 176);
        Sleep(1000);

        // 点击NPC洞察
        _Click(909, 182);
        Sleep(1000);
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  // 匹配NPC打开对话框的白色
  int coordinates1[2][3] = {{481, 231, 0xFFFFFF}, {482, 232, 0xFFFFFF}};

  while (1) {
    HDC hdc = GetDC(NULL);
    printf("%s\n", "2");
    if (hdc) {
      printf("%x\n", GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]));
      // 0xbbggrr
      if (coordinates1[0][2] ==
              GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]) &&
          coordinates1[1][2] ==
              GetPixel(hdc, coordinates1[1][0], coordinates1[1][1])) {
        // 点击自动寻路图标
        _Click(541, 366);
        Sleep(1000);
        // 关闭对话框
        _Click(898, 208);
        Sleep(1000);

        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  CompleteHonorMission(hWnd);
}
void FamliyTaskBeiJiao(HWND hWnd) {
  // 点击自动寻路图标
  _Click(1121, 171);
  Sleep(1000);
  // 点击地图菜单项
  _Click(1064, 216);
  Sleep(1000);

  //  点击下拉按钮
  _Click(999, 397);
  Sleep(1000);
  _Click(999, 397);
  Sleep(1000);
  _Click(999, 397);
  Sleep(1000);
  _Click(999, 397);
  Sleep(1000);

  // 选择龙城北郊
  _Click(908, 399);
  Sleep(1000);

  int coordinates[2][3] = {{1110, 8, 0x10CFFF}, {1120, 12, 0x10CFFF}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // 0xbbggrr
      if (coordinates[0][2] ==
              GetPixel(hdc, coordinates[0][0], coordinates[0][1]) &&
          coordinates[1][2] ==
              GetPixel(hdc, coordinates[1][0], coordinates[1][1])) {
        // 点击自动寻路图标
        _Click(1121, 171);
        Sleep(1000);

        // 点击地图菜单项
        _Click(1075, 176);
        Sleep(1000);

        // 点击NPC
        _Click(903, 202);
        Sleep(1000);
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  int coordinates1[2][3] = {{481, 231, 0xFFFFFF}, {482, 232, 0xFFFFFF}};

  while (1) {
    HDC hdc = GetDC(NULL);
    printf("%s\n", "2");
    if (hdc) {
      printf("%x\n", GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]));
      // 0xbbggrr
      if (coordinates1[0][2] ==
              GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]) &&
          coordinates1[1][2] ==
              GetPixel(hdc, coordinates1[1][0], coordinates1[1][1])) {
        // 点击自动寻路图标
        _Click(541, 366);
        Sleep(1000);
        // 关闭对话框
        _Click(898, 208);
        Sleep(1000);

        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  CompleteHonorMission(hWnd);
}
void FamliyTaskNanJiao(HWND hWnd) {
  // 初始坐标值69/37
  // AskFamilyHonorMission(hWnd);
  OpenMap();
  _ClickRight(524, 464);
  Sleep(1000);
  CloseMap();

  int coordinates[2][3] = {{1113, 13, 0x10CFFF}, {1117, 15, 0x10CFFF}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // 0xbbggrr
      if (coordinates[0][2] ==
              GetPixel(hdc, coordinates[0][0], coordinates[0][1]) &&
          coordinates[1][2] ==
              GetPixel(hdc, coordinates[1][0], coordinates[1][1])) {
        // 点击自动寻路图标
        _Click(1121, 171);
        Sleep(1000);

        // 点击地图菜单项
        _Click(1075, 176);
        Sleep(1000);

        // 点击NPC洞察
        _Click(909, 182);
        Sleep(1000);
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  // 匹配NPC打开对话框的白色
  int coordinates1[2][3] = {{481, 231, 0xFFFFFF}, {482, 232, 0xFFFFFF}};

  while (1) {
    HDC hdc = GetDC(NULL);
    printf("%s\n", "2");
    if (hdc) {
      printf("%x\n", GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]));
      // 0xbbggrr
      if (coordinates1[0][2] ==
              GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]) &&
          coordinates1[1][2] ==
              GetPixel(hdc, coordinates1[1][0], coordinates1[1][1])) {
        // 点击自动寻路图标
        _Click(541, 366);
        Sleep(1000);
        // 关闭对话框
        _Click(898, 208);
        Sleep(1000);

        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  CompleteHonorMission(hWnd);
}
void FamliyTaskDongJiao(HWND hWnd) {
  OpenMap();
  _ClickRight(843, 475);
  Sleep(1000);
  CloseMap();

  int coordinates[2][3] = {{1110, 14, 0x10CFFF}, {1111, 14, 0x10CFFF}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // 0xbbggrr
      if (coordinates[0][2] ==
              GetPixel(hdc, coordinates[0][0], coordinates[0][1]) &&
          coordinates[1][2] ==
              GetPixel(hdc, coordinates[1][0], coordinates[1][1])) {
        // 点击自动寻路图标
        _Click(1121, 171);
        Sleep(1000);

        // 点击地图菜单项
        _Click(1075, 176);
        Sleep(1000);

        // 点击NPC洞察
        _Click(921, 217);
        Sleep(1000);
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  // 匹配NPC打开对话框的白色
  int coordinates1[2][3] = {{481, 231, 0xFFFFFF}, {482, 232, 0xFFFFFF}};

  while (1) {
    HDC hdc = GetDC(NULL);
    printf("%s\n", "2");
    if (hdc) {
      printf("%x\n", GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]));
      // 0xbbggrr
      if (coordinates1[0][2] ==
              GetPixel(hdc, coordinates1[0][0], coordinates1[0][1]) &&
          coordinates1[1][2] ==
              GetPixel(hdc, coordinates1[1][0], coordinates1[1][1])) {
        // 点击自动寻路图标
        _Click(541, 366);
        Sleep(1000);
        // 关闭对话框
        _Click(898, 208);
        Sleep(1000);

        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  CompleteHonorMission(hWnd);
}
int main() {
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  //===
  int keyId = 1;
  int keyId1 = 2;
  int keyId2 = 3;
  int keyId3 = 4;
  int keyId4 = 5;

  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId1, MOD_CONTROL, 0x32)) {
    printf("Register Hotkey: [Ctrl+2] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId2, MOD_CONTROL, 0x33)) {
    printf("Register Hotkey: [Ctrl+3] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId3, MOD_CONTROL, 0x34)) {
    printf("Register Hotkey: [Ctrl+4] Success.\n");
  }
  //===

  MSG msg = {0};

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        FamliyTaskBeiJiao(hWnd);
      } else if (msg.wParam == keyId1) {
        FamliyTaskDongJiao(hWnd);
      } else if (msg.wParam == keyId2) {
        FamliyTaskNanJiao(hWnd);
      } else if (msg.wParam == keyId3) {
        FamliyTaskXiJiao(hWnd);
      }
    }
  }
  return 0;
}
