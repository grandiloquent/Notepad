//#ifndef SHARED_H
//#define SHARED_H

#include <Windows.h>
#include <stdio.h>
#include <TlHelp32.h>
#include <wchar.h>
#include <time.h>
#include "define.h"

typedef enum { KEYDOWN, KEYUP } EventType;

void BackgroundMouseLeftClick(HWND hWnd, int x, int y);
void BackgroundMouseMove(HWND hWnd, int x, int y);
BOOL CheckPixelColor(size_t array[][3], size_t length);
void Click(int x, int y);
void ClickDelay(int x, int y, int delay);
void ClickDouble(int x, int y);
void ClickMap();
void ClickRight(int x, int y);
void Failed(const char *reason);
SIZE_T GetAddressHealth(HANDLE hProcess);
HWND GetHWNDByClassName(const char *className);
HANDLE GetProcessHandle(DWORD pid);
DWORD GetProcessIdByName(const wchar_t *processName);
void GetSkillAuto(HWND hWnd);
void GetSkillCancelAuto(HWND hWnd);
void GetSkillCKStealth(HWND hWnd);
void GetSkillCollect(HWND hWnd);
void GetSkillHorse(HWND hWnd, BOOL bDown);
void GetSkillPsychic(HWND hWnd);
HANDLE GetToken(HANDLE hProcess);
void GoBackCity(HWND hWnd);
void GoPosition(HANDLE hProc, DWORD_PTR address, BYTE value[], size_t pos[]);
void HideOthers(HWND hWnd);
SIZE_T IsArrayMatch(HANDLE proc, SIZE_T address, SIZE_T segmentSize,
                    BYTE array[], SIZE_T arraySize);
void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len);
BYTE ReadMemoryBYTE(HANDLE hProcess, DWORD_PTR lpBaseAddress);
SIZE_T ReadMemoryShort(HANDLE hProcess, DWORD_PTR lpBaseAddress);
SIZE_T ScanSegments(HANDLE proc, BYTE array[], SIZE_T size);
void SendChatText(HWND hWnd, const wchar_t *t);
void SendKeyBackground(HWND hWnd, WORD wVk);
void SendKeyWithAlt(HWND hWnd, UINT vk);
void SetHotKey(int id, UINT fsModifiers, UINT vk);
BOOL SetPrivilege(HANDLE hToken, LPCTSTR lpszPrivilege, BOOL bEnablePrivilege);

void BackgroundMouseLeftClick(HWND hWnd, int x, int y) {
  PostMessage(hWnd, WM_LBUTTONDOWN, 0, MAKELPARAM(x, y));
  Sleep(100);
  PostMessage(hWnd, WM_LBUTTONUP, 0, MAKELPARAM(x, y));
}
void BackgroundMouseMove(HWND hWnd, int x, int y) {
  PostMessage(hWnd, WM_MOUSEMOVE, 0, MAKELPARAM(x, y));
}
BOOL CheckPixelColor(size_t array[][3], size_t length) {
  HDC h = GetDC(NULL);
  if (h) {
    for (size_t i = 0; i < length; i++) {
      if (GetPixel(h, array[i][0], array[i][1]) != array[i][2]) return FALSE;
    }
    return TRUE;
  }
  return FALSE;
}
void Click(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
  mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}
void ClickDelay(int x, int y, int delay) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
  Sleep(delay);
  mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}
void ClickDouble(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
  Sleep(150);
  mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}
void ClickMap() {
  Click(1096, 105);
  Sleep(1000);
}
void ClickRight(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
  mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
}
void Failed(const char *reason) {
  printf("[Failed]: %s.\n", reason);
  exit(1);
}
SIZE_T GetAddressHealth(HANDLE hProcess) {
  BYTE array[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x50, 0, 0, 0, 0x26, 0, 0, 0, 0x5B};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + 0x80;
}
SIZE_T GetAddressSelectName(HANDLE hProcess) {
  BYTE array[] = {0x6E, 0x30, 0x91, 0x03, 0x15, 0x05, 0x00,
                  0x00, 0x00, 0xF0, 0x83, 0x03, 0x08, 0x00};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + 0x1FCBD9C1 - 0x1FCBD99B;
}
HWND GetHWNDByClassName(const char *className) {
  HWND hWnd = FindWindowA(className, NULL);
  if (!hWnd) Failed("GetHWNDByClassName");
  return hWnd;
}
HANDLE GetProcessHandle(DWORD pid) {
  // https://docs.microsoft.com/en-us/windows/desktop/api/processthreadsapi/nf-processthreadsapi-openprocess
  HANDLE h = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!h) {
    printf("[Failed]: GetProcessHandle %d, Error: %u.\n", pid, GetLastError());
    return NULL;
  }
  return h;
}
DWORD GetProcessIdByName(const wchar_t *processName) {
  DWORD result = 0;
  HANDLE hP = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (hP == INVALID_HANDLE_VALUE) {
    printf("[Failed]: GetProcessIdByName %s, Error: %u.\n", processName,
           GetLastError());
    return result;
  }
  // https://docs.microsoft.com/en-us/windows/desktop/api/tlhelp32/ns-tlhelp32-tagprocessentry32
  // Unicode  PROCESSENTRY32W
  // pe32.szExeFile
  PROCESSENTRY32W pe32;
  pe32.dwSize = sizeof(PROCESSENTRY32W);
  if (!Process32FirstW(hP, &pe32)) {
    printf("[Failed]: GetProcessIdByName %s,Process32First,Error: %u.\n",
           processName, GetLastError());
    CloseHandle(hP);
    return result;
  }
  do {
    // wprintf(L"Process Name: %s %s %d.\n", pe32.szExeFile, processName,
    // _wcsicmp(pe32.szExeFile, processName));
    if (_wcsicmp(pe32.szExeFile, processName) == 0) {
      result = pe32.th32ProcessID;
      return result;
    }
  } while (Process32NextW(hP, &pe32));
  CloseHandle(hP);
  return result;
}
void GetSkillAuto(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1003, 29) == 0xFDFD18 &&
          GetPixel(hdc, 996, 25) == 0x000000 &&
          GetPixel(hdc, 983, 18) == 0xA1D700) {
        break;
      } else {
        SendKeyWithAlt(hWnd, 0x57);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void GetSkillCancelAuto(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1003, 29) == 0xFDFD18 &&
          GetPixel(hdc, 996, 25) == 0x000000 &&
          GetPixel(hdc, 983, 18) == 0xA1D700) {
        SendKeyWithAlt(hWnd, 0x57);
      } else {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void GetSkillCKStealth(HWND hWnd) {
  SendKeyBackground(hWnd, SKILL_CK_STEALTH);
  Sleep(TIME_DELAY);
}
void GetSkillCollect(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 236, 129) == 0x66BBFF &&
          GetPixel(hdc, 241, 132) == 0x55AACC &&
          GetPixel(hdc, 235, 136) == 0x2255AA) {
        break;
      } else {
        SendKeyWithAlt(hWnd, 0x31);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void GetSkillHorse(HWND hWnd, BOOL bDown) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 232, 135) == 0xDDFFFF &&
          GetPixel(hdc, 241, 131) == 0x222222 &&
          GetPixel(hdc, 244, 127) == 0x0011AA) {
        if (bDown) {
          SendKeyWithAlt(hWnd, SKILL_HORSE);
        } else {
          break;
        }
      } else {
        if (bDown) {
          break;
        } else {
          SendKeyWithAlt(hWnd, SKILL_HORSE);
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void GetSkillPsychic(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 232, 126) == 0x88FFFF &&
          GetPixel(hdc, 235, 127) == 0x44FFFF &&
          GetPixel(hdc, 244, 136) == 0xFFFFFF) {
        break;
      } else {
        SendKeyWithAlt(hWnd, 0x32);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
HANDLE GetToken(HANDLE hProcess) {
  HANDLE hToken = NULL;
  if (!OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
    printf("Failed to open acess token.\n");
    exit(1);
  }
  return hToken;
}
void GoBackCity(HWND hWnd) { SendKeyWithAlt(hWnd, SKILL_GO_CITY); }
void GoPosition(HANDLE hProc, DWORD_PTR address, BYTE value[], size_t pos[]) {
  while (1) {
    BYTE buf1[2];
    ReadBuffer(hProc, address - 0xd0, buf1, 2);
    BYTE buf2[2];
    ReadBuffer(hProc, address - 0xcc, buf2, 2);
    if (buf1[0] == value[0] && buf1[1] == value[1] && buf2[0] == value[2] &&
        buf2[1] == value[3]) {
      break;
    } else {
      ClickMap();
      ClickRight(pos[0], pos[1]);
      Sleep(500);
      ClickMap();
    }
    Sleep(3000);
  }
}
void HideOthers(HWND hWnd) {
  SendKeyBackground(hWnd, 0x7a);
  Sleep(1000);
  SendKeyBackground(hWnd, 0x7a);
  Sleep(1000);
  SendKeyBackground(hWnd, 0x7a);
  Sleep(1000);
}
SIZE_T IsArrayMatch(HANDLE proc, SIZE_T address, SIZE_T segmentSize,
                    BYTE array[], SIZE_T arraySize) {
  BYTE *procArray = malloc(segmentSize * sizeof(BYTE));
  if (ReadProcessMemory(proc, (void *)address, procArray, segmentSize, NULL) ==
      0) {
    printf("Failed to read memory: %u.\n", GetLastError());
    free(procArray);
    return 0;
  }
  for (SIZE_T i = 0; i < segmentSize; ++i) {
    if ((array[0] == procArray[i]) && ((i + arraySize) < segmentSize)) {
      if (!memcmp(array, procArray + i, arraySize)) {
        free(procArray);
        return address + i;
      }
    }
  }
  free(procArray);
  return 0;
}
void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len) {
  if (ReadProcessMemory(hProc, (void *)address, buf, len, NULL) == 0) {
    printf("[Failed]: ReadBuffer\n");
  }
}
BYTE ReadMemoryBYTE(HANDLE hProcess, DWORD_PTR lpBaseAddress) {
  // https://msdn.microsoft.com/en-us/library/windows/desktop/ms680553(v=vs.85).aspx
  BYTE result = {0};
  if (ReadProcessMemory(hProcess, (void *)lpBaseAddress, &result,
                        sizeof(result), NULL) == 0) {
    printf("[Failed]:ReadMemoryBYTE, Error: %u.\n", GetLastError());
  }
  return result;
}
SIZE_T ReadMemoryShort(HANDLE hProcess, DWORD_PTR lpBaseAddress) {
  // https://msdn.microsoft.com/en-us/library/windows/desktop/ms680553(v=vs.85).aspx
  BYTE result[2];
  if (ReadProcessMemory(hProcess, (void *)lpBaseAddress, &result,
                        sizeof(result), NULL) == 0) {
    printf("[Failed]:ReadMemoryBYTE, Error: %u.\n", GetLastError());
  }
  //   short s = ((b[1] << 8) | b[0]);
  //   int i = (b[3] << 24) | (b[2] << 16) | (b[1] << 8) | (b[0]);
  return (result[1] << 8) | result[0];
}
SIZE_T ScanSegments(HANDLE proc, BYTE array[], SIZE_T size) {
  MEMORY_BASIC_INFORMATION meminfo;
  LPCVOID addr = 0;
  SIZE_T result = 0;
  if (!proc) return 0;
  while (1) {
    if (VirtualQueryEx(proc, addr, &meminfo, sizeof(meminfo)) == 0) break;
    if ((meminfo.State & MEM_COMMIT) && (meminfo.Type & MEM_PRIVATE) &&
        (meminfo.Protect & PAGE_READWRITE) && !(meminfo.Protect & PAGE_GUARD)) {
      result = IsArrayMatch(proc, (SIZE_T)meminfo.BaseAddress,
                            meminfo.RegionSize, array, size);
      if (result != 0) return result;
    }
    addr = (unsigned char *)meminfo.BaseAddress + meminfo.RegionSize;
  }
  return 0;
}
void SendChatText(HWND hWnd, const wchar_t *t) {
  const wchar_t *tmp = t;
  while (*tmp) {
    wchar_t c = *tmp;
    PostMessageW(hWnd, WM_CHAR, c, 0);
    ++tmp;
  }
  PostMessage(hWnd, WM_KEYDOWN, VK_RETURN, 0);
  Sleep(100);
  PostMessage(hWnd, WM_KEYUP, VK_RETURN, 0);
  Sleep(7000);
}
void SendKeyBackground(HWND hWnd, WORD wVk) {
  PostMessageW(hWnd, WM_KEYDOWN, wVk, 0);
  Sleep(100);
  PostMessageW(hWnd, WM_KEYUP, wVk, 0);
}
void SendKeyWithAlt(HWND hWnd, UINT vk) {
  PostMessage(hWnd, WM_SYSKEYDOWN, 0x12, 0x60380001);
  Sleep(100);
  PostMessage(hWnd, WM_SYSKEYUP, 0x12, 0xC0380001);
  Sleep(100);
  // PostMessage(hWnd, WM_SYSKEYDOWN, 0x12, 0x60380001);
  // Sleep(10);
  PostMessage(hWnd, WM_SYSKEYDOWN, vk, 0);
  Sleep(100);
  PostMessage(hWnd, WM_SYSKEYUP, vk, 0);
  Sleep(100);
  // PostMessage(hWnd, WM_KEYUP, 0x12, 0);
}
void SetHotKey(int id, UINT fsModifiers, UINT vk) {
  // https://docs.microsoft.com/en-us/windows/desktop/api/winuser/nf-winuser-registerhotkey
  if (RegisterHotKey(NULL, id, fsModifiers, vk)) {
    TCHAR c =
        (TCHAR)MapVirtualKeyEx(vk, MAPVK_VK_TO_CHAR, GetKeyboardLayout(0));
    printf("[Success]: Register %c.\n", c);
  } else {
    Failed("SetHotKey");
  }
}
BOOL SetPrivilege(HANDLE hToken, LPCTSTR lpszPrivilege, BOOL bEnablePrivilege) {
  TOKEN_PRIVILEGES tp;
  LUID luid;
  if (!LookupPrivilegeValue(NULL, lpszPrivilege, &luid)) {
    printf("LookupPrivilegeValue error: %u\n", GetLastError());
    return FALSE;
  }
  tp.PrivilegeCount = 1;
  tp.Privileges[0].Luid = luid;
  if (bEnablePrivilege) {
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
  } else {
    tp.Privileges[0].Attributes = 0;
  }
  if (!AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES),
                             (PTOKEN_PRIVILEGES)NULL, (PDWORD)NULL)) {
    printf("AdjustTokenPrivileges error: %u.\n", GetLastError());
    return FALSE;
  }
  if (GetLastError() == ERROR_NOT_ALL_ASSIGNED) {
    printf("The token does not have the specified privilege.\n");
    return FALSE;
  }
  return TRUE;
}
void GetSkillSelectMonster(HWND hWnd) {
  SendKeyBackground(hWnd, 0x9);
  Sleep(TIME_DELAY);
}
//#endif
