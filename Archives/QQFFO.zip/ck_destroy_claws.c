﻿// -lgdi32

#include "shared.h"
#include <math.h>

#define PI 3.14159265

#define CLASS_NAME "QQSwordWinClass"

#define TARGET_HANDLE 0

static BOOL mStatus = FALSE;

void GetSkillHealth(HWND hWnd) {
  SendKeyBackground(hWnd, 0x76);
  Sleep(1000);
}

void GetSkillAttack(HWND hWnd) {
  SendKeyBackground(hWnd, SKILL_EMIT_ENERGY);
  Sleep(TIME_DELAY);
  SendKeyBackground(hWnd, SKILL_EXORCISM);
  Sleep(TIME_DELAY);
  SendKeyBackground(hWnd, SKILL_SHENWEI);
  Sleep(TIME_DELAY);
}
SIZE_T GetAddressSpeed(HANDLE hProcess) {
  BYTE array[] = {0x74, 0x69, 0x70, 0x00, 0x65, 0x62, 0x61,
                  0x72, 0x00, 0x2F, 0x6B, 0x65, 0x79, 0x63,
                  0x68, 0x61, 0x72, 0x2E, 0x67, 0x73, 0x61};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + (0x1ED6B291 - 0x1ED6B268);
}
SIZE_T GetAddressStatus(HANDLE hProc) {
  // GBK 编码的字符串的字节组 0x37, 0x32, 0x34
  // 无祝福术
  BYTE array[] = {0x8F, 0x00, 0x34, 0x38, 0x39, 0x00};
  SIZE_T objectAddress = ScanSegments(hProc, array, sizeof(array));
  if (!objectAddress) {
    BYTE array1[] = {0x8F, 0x00, 0x39, 0x30, 0x35, 0x00};
    objectAddress = ScanSegments(hProc, array1, sizeof(array1));
  }
  if (!objectAddress) {
    printf("[Failed]: GetStatusAddress\n");
    exit(1);
  }
  return objectAddress + 0x2;
}
SIZE_T GetAddressTask(HANDLE hProcess) {
  BYTE array[] = {0x8E, 0xD0, 0xE5, 0x3A, 0x4B, 0x12, 0x00};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + 0x19AFFF09 - 0x19AFFED0;
}
SIZE_T GetAddressLocation(HANDLE hProcess) {
  BYTE array[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                  0x00, 0xB3, 0xF6, 0xD4, 0xC6, 0xB3, 0xC7, 0x00};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + 0x08C0A338 - 0x08C0A32E;
}

void GetSkillExplosionFocus(HWND hWnd) {
  int width = GetSystemMetrics(SM_CXSCREEN) / 2;
  int height = GetSystemMetrics(SM_CYSCREEN) / 2;
  int delay = 500;
  BOOL bLeft = TRUE;
  while (1) {
    if (bLeft) {
      SendKeyBackground(hWnd, 0x74);
      Click(width - 100, height);
      Sleep(delay);
      Click(width - 100, height);
      Sleep(delay);
      Click(width - 100, height);
      Sleep(delay);
      Click(width - 100, height);
      Sleep(delay);
      Click(width - 100, height);
      Sleep(delay);

    } else {
      SendKeyBackground(hWnd, 0x74);
      Click(width + 100, height);
      Sleep(delay);
      Click(width + 100, height);
      Sleep(delay);
      Click(width + 100, height);
      Sleep(delay);
      Click(width + 100, height);
      Sleep(delay);
      Click(width + 100, height);
      Sleep(delay);
    }
    bLeft = !bLeft;
  }
}
void GetSkillExplosion(HWND hWnd) {
  SendKeyBackground(hWnd, 0x74);
  Sleep(1000);
}

void GetSkillExplosionCircle(HWND hWnd) {
  int width = GetSystemMetrics(SM_CXSCREEN);
  int height = GetSystemMetrics(SM_CYSCREEN);
  int count = 0;
  double x, rx, val, ry;

  x = 45.0;
  val = PI / 180.0;
  rx = cos(x * val);

  int hx = width / 2;
  int hy = height / 2;
  int offset = 100;
  int o = rx * offset;
  int delay = 2500;

  while (1) {
    if (count == 0) {
      GetSkillExplosion(hWnd);
      Click(hx + offset, hy);
      Sleep(delay);
    } else if (count == 1) {
      GetSkillExplosion(hWnd);
      Click(hx + o, hy + o);
      Sleep(delay);
    } else if (count == 2) {
      GetSkillExplosion(hWnd);
      Click(hx, hy + offset);
      Sleep(delay);
    } else if (count == 3) {
      GetSkillExplosion(hWnd);
      Click(hx - o, hy + o);
      Sleep(delay);
    } else if (count == 4) {
      GetSkillExplosion(hWnd);
      Click(hx - offset, hy);
      Sleep(delay);
    } else if (count == 5) {
      GetSkillExplosion(hWnd);
      Click(hx - o, hy - o);
      Sleep(delay);
    } else if (count == 6) {
      GetSkillExplosion(hWnd);
      Click(hx, hy - offset);
      Sleep(delay);
    } else if (count == 7) {
      GetSkillExplosion(hWnd);
      Click(hx + o, hy - o);
      Sleep(delay);
    } else {
      count = 0;

      // Click(width / 2 + 250, height / 2);
      // Sleep(3000);
      continue;
    }
    count++;
  }
}
void GoGuardTask() {
  size_t pos[][2] = {{1122, 169}, {1065, 196}, {894, 338}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 533, 233) == 0xFFFFFF &&
          GetPixel(hdc, 524, 241) == 0xFFFFFF) {
        break;
      } else {
        for (int i = 0; i < 3; i++) {
          Click(pos[i][0], pos[i][1]);
          Sleep(1000);
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }

  Click(565, 364);
  Sleep(1000);
}
void GoGuard() {
  size_t pos[][2] = {{1122, 169}, {1065, 196}, {894, 338}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 533, 233) == 0xFFFFFF &&
          GetPixel(hdc, 524, 241) == 0xFFFFFF) {
        break;
      } else {
        for (int i = 0; i < 3; i++) {
          Click(pos[i][0], pos[i][1]);
          Sleep(1000);
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }
  Click(565, 364);
  Sleep(1000);
  Click(565, 364);
  Sleep(1000);
}

void GoDestination(HANDLE hProcess, SIZE_T mapAddress, HWND hWnd) {
  BYTE gbk[] = {0xc7, 0xe0, 0xc5, 0xa3, 0xc9, 0xbd, 0xbd, 0xc5};
  SIZE_T pos[][2] = {{1119, 174}, {1059, 175}, {880, 240}, {444, 469}};
  size_t pos1[][2] = {{534, 365}, {527, 210}, {451, 471}};
  BYTE len = 8;
  while (1) {
    BYTE buf[len];
    ReadBuffer(hProcess, mapAddress, buf, len);
    if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2] &&
        buf[3] == gbk[3] && buf[4] == gbk[4] && buf[5] == gbk[5] &&
        buf[6] == gbk[6] && buf[7] == gbk[7]) {
      break;
    } else {
      HDC hdc = GetDC(NULL);
      if (hdc) {
        if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
            GetPixel(hdc, 541, 232) == 0xFFFFFF &&
            GetPixel(hdc, 569, 233) == 0xFFFFFF) {
          for (int i = 0; i < 3; i++) {
            Click(pos1[i][0], pos1[i][1]);
            Sleep(1000);
          }
          Sleep(2000);
          break;
        } else {
          for (int i = 0; i < 3; i++) {
            Click(pos[i][0], pos[i][1]);
            Sleep(1000);
          }
        }
        ReleaseDC(NULL, hdc);
      }
    }
    Sleep(3000);
  }
  GetSkillCollect(hWnd);
  GetSkillCollect(hWnd);
  printf("%s.\n", "SendKeyBackground");
  SendKeyBackground(hWnd, 0x75);
  Sleep(1000);
  BYTE gbk1[] = {0xd0, 0xde, 0xc2, 0xde, 0xb5, 0xee, 0x31, 0xb2, 0xe3};
  BYTE len1 = 9;
  while (1) {
    BYTE buf[len1];
    ReadBuffer(hProcess, mapAddress, buf, len1);
    if (buf[0] == gbk1[0] && buf[1] == gbk1[1] && buf[2] == gbk1[2] &&
        buf[3] == gbk1[3] && buf[4] == gbk1[4] && buf[5] == gbk1[5] &&
        buf[6] == gbk1[6] && buf[7] == gbk1[7] && buf[8] == gbk1[8]) {
      break;
    } else {
      Click(1059, 270);
      Sleep(1000);
    }
    Sleep(3000);
  }
  SendKeyBackground(hWnd, SKILL_CK_STEALTH);
  Sleep(1000);

  BYTE gbk2[] = {0xd0, 0xde, 0xc2, 0xde, 0xb5, 0xee, 0x33, 0xb2, 0xe3};
  BYTE len2 = 10;
  while (1) {
    BYTE buf[len2];
    ReadBuffer(hProcess, mapAddress, buf, len2);
    if (gbk2[0] == buf[0] && gbk2[1] == buf[1] && gbk2[2] == buf[2] &&
        gbk2[3] == buf[3] && gbk2[4] == buf[4] && gbk2[5] == buf[5] &&
        gbk2[6] == buf[6] && gbk2[7] == buf[7] && gbk2[8] == buf[8]) {
      break;
    } else {
      Click(1122, 174);
      Sleep(1000);
      Click(1066, 214);
      Sleep(1000);
      Click(879, 256);
      Sleep(1000);
    }
    Sleep(3000);
  }
}
void GoBackCity(HWND hWnd, HANDLE hProcess, SIZE_T mapAddress) {
  // 通灵
  GetSkillSmart(hWnd);
  GetSkillCancelAuto(hWnd);
  BYTE gbk[] = {0xb3, 0xf6, 0xd4, 0xc6, 0xb3, 0xc7};
  size_t len = 6;

  while (1) {
    BYTE buf[len];
    ReadBuffer(hProcess, mapAddress, buf, len);

    // printf(
    //     "buf[0]: %d,buf[1]: %d,buf[2]: %d,buf[3]: %d,buf[4]: %d,buf[5]:
    //     %d\n", buf[0], buf[1], buf[2], buf[3], buf[4], buf[5]);
    if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2] &&
        buf[3] == gbk[3] && buf[4] == gbk[4] && buf[5] == gbk[5]) {
      printf("%s.\n", "213");
      break;
    } else {
      SendKeyWithAlt(hWnd, 0x30);
      Sleep(1000);
      // 挂机
      // SendKeyWithAlt(hWnd, 0x57);
      // Sleep(1000);
    }
    Sleep(5000);
  }
}
void HitMonster(HANDLE hProcess, SIZE_T mapAddress, SIZE_T hpAddress,
                HWND hWnd) {
  SendKeyBackground(hWnd, SKILL_CK_STEALTH);
  Sleep(1000);

  ClickMap();
  ClickRight(426, 373);
  Sleep(1000);
  ClickMap();
  Sleep(7000);

  GetSkillAuto(hWnd);

  DWORD threshold = 1700;

  BYTE gbk[] = {0xd2, 0xd1, 0xc9, 0xb1, 0xcb, 0xc0, 0xd6, 0xb8,
                0xb6, 0xa8, 0xb9, 0xd6, 0xce, 0xef, 0xc5, 0xa3,
                0xcd, 0xb7, 0xc3, 0xe6, 0xbe, 0xdf};
  size_t len = 22;
  // SIZE_T taskAddress = GetAddressTask(hProcess);
  // printf("%x.\n", taskAddress);
  int width = GetSystemMetrics(SM_CXSCREEN) / 2;
  int height = GetSystemMetrics(SM_CYSCREEN) / 2;
  int delay = 1500;
  BOOL bLeft = TRUE;

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1131, 266) == 0x00D9FE &&
          GetPixel(hdc, 1072, 265) == 0xFFFFFF) {
        GoBackCity(hWnd, hProcess, mapAddress);
        return;
      }
      ReleaseDC(NULL, hdc);
    }

    // BYTE buf[len];
    // ReadBuffer(hProcess, taskAddress, buf, len);
    // if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2] &&
    //     buf[3] == gbk[3] && buf[4] == gbk[4] && buf[5] == gbk[5] &&
    //     buf[6] == gbk[6] && buf[7] == gbk[7] && buf[8] == gbk[8] &&
    //     buf[9] == gbk[9] && buf[10] == gbk[10] && buf[11] == gbk[11] &&
    //     buf[12] == gbk[12] && buf[13] == gbk[13] && buf[14] == gbk[14] &&
    //     buf[15] == gbk[15] && buf[16] == gbk[16] && buf[17] == gbk[17] &&
    //     buf[18] == gbk[18] && buf[19] == gbk[19] && buf[20] == gbk[20] &&
    //     buf[21] == gbk[21]) {
    //   printf("%s.\n", "GoBackCity");
    //   GoBackCity(hWnd, hProcess, mapAddress);
    //   return;
    // }

    if (ReadMemoryShort(hProcess, hpAddress) < threshold) {
      GetSkillHealth(hWnd);
    }
    SendKeyBackground(hWnd, 0x71);
    Sleep(1000);
    // SendKeyBackground(hWnd, 0x72);
    // Sleep(1000);
  }
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;
  DWORD pid = GetProcessIdByName(L"qqffo.exe");
  HANDLE hProcess = GetProcessHandle(pid);
  DWORD_PTR hpAddress = GetAddressHealth(hProcess);
  printf("[Success]: health value %x.\n", hpAddress);
  SIZE_T mapAddress = GetAddressLocation(hProcess);
  printf("[Success]: map value %x.\n", mapAddress);

  while (1) {
    GoDestination(hProcess, mapAddress, hWnd);
    HitMonster(hProcess, mapAddress, hpAddress, hWnd);
    GoGuardTask();
    ClickMap();
    ClickRight(841, 316);
    Sleep(1000);
    ClickMap();
    GoGuard();
  }

  // DWORD threshold = 1100;
  // int count = 0;

  // while (1) {
  //   if (ReadMemoryShort(hProcess, hpAddress) < threshold) {
  //     GetSkillHealth(hWnd);
  //   } else {
  //     GetSkillAttack(hWnd);
  //     count++;
  //   }
  //   Sleep(1000);
  // }
  return 0;
}

int main() {
  int k1 = 1;
  HWND hWnd;
  if (TARGET_HANDLE)
    hWnd = (HWND)TARGET_HANDLE;
  else
    hWnd = GetHWNDByClassName(CLASS_NAME);

  SetHotKey(k1, MOD_CONTROL, 0x31);

  MSG msg = {0};
  HANDLE hThread = {0};

  DWORD dwThreadIdArray[1];
  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message != WM_HOTKEY) continue;
    if (msg.wParam == k1) {
      // GetSkillCollect(hWnd);
      // return 0;
      if (!hThread) {
        hThread =
            CreateThread(NULL, 0, Strategy, &hWnd, 0, &dwThreadIdArray[0]);
        mStatus = TRUE;
        printf("Create Thread 2.\n");
      } else {
        if (mStatus) {
          SuspendThread(hThread);
          mStatus = FALSE;
          printf("Suspend Thread 2.\n");
        } else {
          ResumeThread(hThread);
          mStatus = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    }
  }
}
