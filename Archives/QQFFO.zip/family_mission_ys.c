// -lgdi32

#include "shared.h"

#define CAREER_YS
#define APP_HWND 0
#define APP_PID 0
// 右上角地图名称内存地址相对偏移值
#define ADDRESS_OFFSET_MAP_NAME 0x10
static BOOL mStatus = FALSE;

// 龙城 GBK 编码字节数组
static BYTE DRAGON_CITY[] = {0xc1, 0xfa, 0xb3, 0xc7, 0};

// 坐标 自动寻路按钮
static size_t POS_AUTO_SEARCH_PATH_BUTTON[] = {1122, 174};
static size_t POS_ORDINARY_NPC[] = {1066, 195};
static size_t POS_ESSENTIAL_NPC[] = {1053, 175};
static size_t POS_DROPDOWN_BUTTON[] = {997, 377};
static size_t POS_MAP[] = {1096, 105};

void GetHealth(HWND hWnd);
HWND GetHWND();
DWORD GetPid();
HANDLE GetProcess(HANDLE hToken, DWORD pid);
void GetStatus(HWND hWnd);
HANDLE GetToken();
void GoDragonCity(HANDLE hProc, DWORD_PTR address, HWND hWnd);
void GoDragonCityGod(HANDLE hProc, DWORD_PTR address, HWND hWnd);
void GoPriest(HANDLE hProc, DWORD_PTR address, HWND hWnd);
void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len);
void TalkDragonCityGod();

void GetSkillSpeed(HWND hwnd, BOOL bFast, BOOL bHorse) {
  SendKeyBackground(hwnd, SKILL_SHIELD);
  Sleep(TIME_DELAY);
  if (bFast) {
    SendKeyWithAlt(hwnd, SKILL_INSTANT);
    Sleep(TIME_DELAY);
    SendKeyWithAlt(hwnd, SKILL_ACCELERATE);
    Sleep(2000);
  } else {
    SendKeyWithAlt(hwnd, SKILL_CONCENTRATED);
    Sleep(TIME_DELAY);
    SendKeyWithAlt(hwnd, SKILL_ACCELERATE);
    Sleep(4600);
  }
  if (bHorse) {
    SendKeyWithAlt(hwnd, SKILL_HORSE);
    Sleep(TIME_DELAY);
  }
}
HWND GetHWND() {
  HWND hWnd;
  if (APP_HWND != 0)
    hWnd = (HWND)APP_HWND;
  else
    hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    printf("[Failed]: GetHWND.\n");
    exit(1);
  }
  return hWnd;
}

HANDLE GetProcess(HANDLE hToken, DWORD pid) {
  if (!SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    exit(1);
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    exit(1);
  }
  return hTargetProc;
}

void GetStatus(HWND hWnd) {
  SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_DEFENSE);
  Sleep(3000);
  SendKeyWithAlt(hWnd, SKILL_BLESSING);
  Sleep(3000);
}

void GoDragonCity(HANDLE hProc, DWORD_PTR address, HWND hWnd) {
  while (1) {
    BYTE buf[5];
    ReadBuffer(hProc, address, buf, 5);
    // printf("buf[0]: %d,buf[1]: %d,buf[2]: %d,buf[3]: %d,buf[4]: %d\n",
    // buf[0],
    //        buf[1], buf[2], buf[3], buf[4]);
    if (buf[0] == DRAGON_CITY[0] && buf[1] == DRAGON_CITY[1] &&
        buf[2] == DRAGON_CITY[2] && buf[3] == DRAGON_CITY[3] &&
        buf[4] == DRAGON_CITY[4]) {
      break;
    } else {
      SendKeyWithAlt(hWnd, SKILL_GO_CITY);
    }
    Sleep(3000);
  }
}

void GoDragonCityGod(HANDLE hProc, DWORD_PTR address, HWND hWnd) {
  // address 0x08B3B040 地图名称在内存中的位置
  BYTE VALUE_POS_DRAGON_CITY_GOD[] = {0x80, 0x23, 0x0E, 0x0C};

  size_t POS_DRAGON_CITY_GOD[] = {683, 330};  //{683, 330};
  while (1) {
    BYTE buf1[2];
    ReadBuffer(hProc, address - 0xd0, buf1, 2);
    printf("%x %x.\n", buf1[0], buf1[1]);
    BYTE buf2[2];
    ReadBuffer(hProc, address - 0xcc, buf2, 2);
    if (buf1[0] == VALUE_POS_DRAGON_CITY_GOD[0] &&
        buf1[1] == VALUE_POS_DRAGON_CITY_GOD[1] &&
        buf2[0] == VALUE_POS_DRAGON_CITY_GOD[2] &&
        buf2[1] == VALUE_POS_DRAGON_CITY_GOD[3]) {
      break;
    } else {
      Click(POS_MAP[0], POS_MAP[1]);
      Sleep(1000);
      ClickRight(POS_DRAGON_CITY_GOD[0], POS_DRAGON_CITY_GOD[1]);
      Sleep(1000);
      Click(POS_MAP[0], POS_MAP[1]);
      Sleep(1000);
    }
    Sleep(3000);
  }
}

void GoPriest(HANDLE hProc, DWORD_PTR address, HWND hWnd) {
  // address 0x08B3B040 地图名称在内存中的位置
  BYTE VALUE[] = {0xBA, 0x08, 0x57, 0x04};
  size_t POS[] = {1117, 66};
  while (1) {
    BYTE buf1[2];
    ReadBuffer(hProc, address - 0xd0, buf1, 2);
    // printf("%x %x %x\n", address, buf1[0], buf1[1]);

    BYTE buf2[2];
    ReadBuffer(hProc, address - 0xcc, buf2, 2);
    if (buf1[0] == VALUE[0] && buf1[1] == VALUE[1] && buf2[0] == VALUE[2] &&
        buf2[1] == VALUE[3]) {
      break;
    } else {
      SendKeyWithAlt(hWnd, 0x30);
      Sleep(2000);
      ClickRight(POS[0], POS[1]);
      Sleep(1000);
    }
    Sleep(3000);
  }
}

void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len) {
  if (ReadProcessMemory(hProc, (void*)address, buf, len, NULL) == 0) {
    printf("[Failed]: ReadBuffer\n");
  }
}

void TalkDragonCityGod() {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      //  检查对话框是否打开
      if (GetPixel(hdc, 480, 234) == 0xFFFFFF &&
          GetPixel(hdc, 505, 288) == 0x0082FF &&
          GetPixel(hdc, 862, 251) == 0xFFFFFF) {
        break;
      } else {
        // 点击NPC
        Click(693, 360);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 点击关于家族屋
  Click(537, 403);
  Sleep(1000);
  // 点击进入家族屋前庭
  Click(554, 367);
  Sleep(2000);
}

void TalkPriest(HWND hWnd) {
  SendKeyWithAlt(hWnd, SKILL_PSYCHIC);
  Sleep(1000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 233) == 0xFFFFFF &&
          GetPixel(hdc, 722, 424) == 0x91EBA0) {
        break;
      } else {
        // 点击NPC
        Click(691, 351);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 点击家族荣誉任务
  Click(547, 419);
  Sleep(1000);
  // 点击开始工作
  Click(545, 364);
  Sleep(2000);
}
void GoIntoDragonCity(HANDLE hProc, DWORD_PTR address, HWND hWnd) {
  while (1) {
    BYTE buf[5];
    ReadBuffer(hProc, address, buf, 5);
    if (buf[0] == DRAGON_CITY[0] && buf[1] == DRAGON_CITY[1] &&
        buf[2] == DRAGON_CITY[2] && buf[3] == DRAGON_CITY[3] &&
        buf[4] == DRAGON_CITY[4]) {
      break;
    } else {
      SendKeyWithAlt(hWnd, SKILL_GO_CITY);
      Sleep(1000);
      ClickRight(1069, 99);
      Sleep(3000);
    }
    Sleep(3000);
  }
}

void OpenTaskDialog(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 457, 137) == 0xFFFFFF &&
          GetPixel(hdc, 490, 145) == 0xFFFFFF) {
        break;
      } else {
        // ALT+N
        SendKeyWithAlt(hWnd, SHORTCUT_TASKLIST);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}

BYTE SelectFamilyTask(HWND hWnd) {
  size_t POS_Y[] = {155, 443};
  size_t POS_X = 446;

  // while (1) {
  HDC hdc = GetDC(NULL);
  if (hdc) {
    if (GetPixel(hdc, 684, 164) == 0xFFFFFF &&
        GetPixel(hdc, 723, 188) == 0xFFFFFF &&
        GetPixel(hdc, 678, 204) == 0xFFFFFF) {
    } else {
      for (int i = POS_Y[0]; i < POS_Y[1]; ++i) {
        if (GetPixel(hdc, POS_X, i) == 0xFFFFFF) {
          if (GetPixel(hdc, POS_X + 9, i) == 0xFFFFFF &&
              GetPixel(hdc, POS_X + 76, i) == 0xFFFFFF) {
            Click(POS_X, i);
            Sleep(1000);
            break;
          }
        }
      }
    }
    ReleaseDC(NULL, hdc);
  }

  BYTE result = -1;

  hdc = GetDC(NULL);
  if (hdc) {
    if (GetPixel(hdc, 668, 231) == 0xFFFFFF &&
        GetPixel(hdc, 669, 235) == 0xFFFFFF &&
        GetPixel(hdc, 668, 239) == 0xFFFFFF) {
      printf("East.\n");
      result = 1;
    }
    if (GetPixel(hdc, 668, 231) == 0xFFFFFF &&
        GetPixel(hdc, 671, 234) == 0xFFFFFF &&
        GetPixel(hdc, 675, 240) == 0xFFFFFF) {
      printf("South.\n");
      result = 2;
    }
    if (GetPixel(hdc, 668, 230) == 0xFFFFFF &&
        GetPixel(hdc, 672, 231) == 0xFFFFFF &&
        GetPixel(hdc, 670, 238) == 0xFFFFFF) {
      printf("West.\n");
      result = 3;
    }
    if (GetPixel(hdc, 668, 233) == 0xFFFFFF &&
        GetPixel(hdc, 678, 237) == 0xFFFFFF &&
        GetPixel(hdc, 668, 239) == 0xFFFFFF) {
      printf("North.\n");
      result = 4;
    }
    ReleaseDC(NULL, hdc);
  }
  // 关闭对话框
  Click(888, 115);
  Sleep(1000);
  return result;
}
void GoDestination(HANDLE hProc, DWORD_PTR address, HWND hWnd, BYTE gbk[],
                   size_t pos[], BYTE mode) {
#ifdef CAREER_YS
  GetSkillSpeed(hWnd, FALSE, TRUE);
#endif
 

  // 寻路龙城西郊
  while (1) {
    BYTE buf[9];
    ReadBuffer(hProc, address, buf, 9);
    if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2] &&
        buf[3] == gbk[3] && buf[4] == gbk[4] && buf[5] == gbk[5] &&
        buf[6] == gbk[6] && buf[7] == gbk[7] && buf[8] == gbk[8]) {
      break;
    } else {
      Click(POS_MAP[0], POS_MAP[1]);
      Sleep(1000);
      ClickRight(pos[0], pos[1]);
      Sleep(1000);
      Click(POS_MAP[0], POS_MAP[1]);
      Sleep(1000);
    }
    Sleep(3000);
  }
  // 寻路洞察使者
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 231) == 0xFFFFFF &&
          GetPixel(hdc, 497, 231) == 0xFFFFFF &&
          GetPixel(hdc, 525, 231) == 0xFFFFFF) {
        break;
      } else {
        Click(POS_AUTO_SEARCH_PATH_BUTTON[0], POS_AUTO_SEARCH_PATH_BUTTON[1]);
        Sleep(1000);
        Click(POS_ESSENTIAL_NPC[0], POS_ESSENTIAL_NPC[1]);
        Sleep(1000);
        if (mode == 1) {
          Click(886, 219);
        } else if (mode == 4) {
          Click(885, 198);
        } else {
          //  点击洞察使者
          Click(875, 177);
        }

        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
  // 点击知道了
  Click(516, 364);
  Sleep(1000);
}

DWORD WINAPI Strategy(LPVOID lpParam) {
  DWORD pid = GetProcessIdByName(L"qqffo.exe");
  HANDLE hToken = GetToken(GetCurrentProcess());
  HANDLE hTargetProc = GetProcess(hToken, pid);

  // BYTE array[] = {0xc1, 0xfa, 0xb3, 0xc7, 0};
  // SIZE_T objectAddress = _ScanSegments(hTargetProc, array, sizeof(array));
  // SIZE_T dcAddress = objectAddress;
  // printf("Dragon City: %x.\n", dcAddress);

  // GoDragonCityGod(hTargetProc, dcAddress, GetHWND());
  // TalkDragonCityGod();

  // return 0;

  // 搜索内存中GBK编码 家族前院 字节
  BYTE array[] = {0x70, 0x77, 0x32, 0x38, 0x31, 0x30, 0x31, 0x00,
                  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                  0xBC, 0xD2, 0xD7, 0xE5, 0xC7, 0xB0, 0xD4, 0xBA};
  SIZE_T objectAddress = ScanSegments(hTargetProc, array, sizeof(array));
  if (!objectAddress) {
    printf("[Failed]: ScanSegments.\n");
    exit(1);
  }
  // 龙城地址
  SIZE_T dcAddress = objectAddress + ADDRESS_OFFSET_MAP_NAME;

  HWND hWnd = GetHWND();

  // GoPriest(hTargetProc, dcAddress, hWnd);

  // return 0;
  while (1) {
    OpenTaskDialog(hWnd);
    BYTE result = SelectFamilyTask(hWnd);
    if (result == -1) return 0;

    GoIntoDragonCity(hTargetProc, dcAddress, hWnd);

    BYTE gbk[9];
    size_t pos[2];
    BYTE mode = -1;
    if (result == 1) {
      gbk[0] = 0xc1;
      gbk[1] = 0xfa;
      gbk[2] = 0xb3;
      gbk[3] = 0xc7;
      gbk[4] = 0xb6;
      gbk[5] = 0xab;
      gbk[6] = 0xbd;
      gbk[7] = 0xbc;
      gbk[8] = 0x0;

      pos[0] = 841;
      pos[1] = 459;
      mode = 1;
    } else if (result == 2) {
      gbk[0] = 0xc1;
      gbk[1] = 0xfa;
      gbk[2] = 0xb3;
      gbk[3] = 0xc7;
      gbk[4] = 0xc4;
      gbk[5] = 0xcf;
      gbk[6] = 0xbd;
      gbk[7] = 0xbc;
      gbk[8] = 0x0;
      pos[0] = 518;
      pos[1] = 469;
      mode = 0;
    } else if (result == 3) {
      gbk[0] = 0xc1;
      gbk[1] = 0xfa;
      gbk[2] = 0xb3;
      gbk[3] = 0xc7;
      gbk[4] = 0xce;
      gbk[5] = 0xf7;
      gbk[6] = 0xbd;
      gbk[7] = 0xbc;
      gbk[8] = 0x0;
      pos[0] = 533;
      pos[1] = 302;
      mode = 0;
    } else if (result == 4) {
      gbk[0] = 0xc1;
      gbk[1] = 0xfa;
      gbk[2] = 0xb3;
      gbk[3] = 0xc7;
      gbk[4] = 0xb1;
      gbk[5] = 0xb1;
      gbk[6] = 0xbd;
      gbk[7] = 0xbc;
      gbk[8] = 0x0;
      pos[0] = 843;
      pos[1] = 294;
      mode = 4;
    } else {
      break;
    }
    // 寻路龙城X郊区
    // hTragetProc 程序进程
    // dcAddress 地图名称在内存中的地址
    // gbk 地图名称gbk编码BYTE数组
    // pos 在龙城中寻路时右键单击的坐标
    // mode 区分洞察使者在寻路菜单中的位置
    GoDestination(hTargetProc, dcAddress, hWnd, gbk, pos, mode);
    // 寻路龙城
    GoDragonCity(hTargetProc, dcAddress, hWnd);
    // 寻路城隍
    GoDragonCityGod(hTargetProc, dcAddress, hWnd);
    // 对话城隍
    TalkDragonCityGod();
    // 寻路祭司
    GoPriest(hTargetProc, dcAddress, hWnd);
    // 交任务
    TalkPriest(hWnd);
    // 接任务
    TalkPriest(hWnd);
  }

  return 0;
}

int main(int argc, char* argv[]) {
  int k1 = 1;

  if (RegisterHotKey(NULL, k1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  } else {
    printf("[Failed]: Register Hotkey [Ctrl+1].\n");
    exit(1);
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        // HWND hWnd = GetHWND();
        // while (1) {
        //   _SendKeyBackground(hWnd, 0x9);
        //   Sleep(1000);
        // }
        // size_t pos[2];

        // pos[0] = 845;
        // pos[1] = 465;
        // Click(POS_MAP[0], POS_MAP[1]);
        // Sleep(1000);
        // ClickRight(pos[0], pos[1]);
        // Sleep(1000);
        // Click(POS_MAP[0], POS_MAP[1]);
        // Sleep(1000);
        // return 0;GetPixel(hdc,)==0x667777

        // size_t POS[] = {841,459};
        // _GoLocationWithMap(POS);
        // return 0;
        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, NULL, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }

  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
// gcc in-bot.c -o m && m

/*

1. 开始位置家族前庭
2. 接家族荣誉任务
3. 背包预留空格
4. 开始时不坐坐骑
5. 充足的回城

*/