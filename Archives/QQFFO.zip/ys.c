﻿// -lgdi32

#include "shared.h"

#define CLASS_NAME "QQSwordWinClass"

#define TARGET_HANDLE 0x000B013E


#define YS

static BOOL mStatus = FALSE;

void GetSkill() {}
void GetSkillHealth(HWND hWnd) {
  SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
}
void GetSkillStatus(HWND hWnd) {
  SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_INSTANT);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_DEFENSE);
  Sleep(2000);
  SendKeyWithAlt(hWnd, SKILL_INSTANT);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_BLESSING);
  Sleep(2000);
}
void GetSkillAttack(HWND hWnd) {
  SendKeyBackground(hWnd, SKILL_EMIT_ENERGY);
  Sleep(TIME_DELAY);
  SendKeyBackground(hWnd, SKILL_EXORCISM);
  Sleep(TIME_DELAY);
  SendKeyBackground(hWnd, SKILL_SHENWEI);
  Sleep(TIME_DELAY);
}
SIZE_T GetAddressSpeed(HANDLE hProcess) {
  BYTE array[] = {0x74, 0x69, 0x70, 0x00, 0x65, 0x62, 0x61,
                  0x72, 0x00, 0x2F, 0x6B, 0x65, 0x79, 0x63,
                  0x68, 0x61, 0x72, 0x2E, 0x67, 0x73, 0x61};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + (0x1ED6B291 - 0x1ED6B268);
}
SIZE_T GetAddressStatus(HANDLE hProc) {
  // GBK 编码的字符串的字节组 0x37, 0x32, 0x34
  // 无祝福术
  BYTE array[] = {0x8F, 0x00, 0x34, 0x38, 0x39, 0x00};
  SIZE_T objectAddress = ScanSegments(hProc, array, sizeof(array));
  if (!objectAddress) {
    BYTE array1[] = {0x8F, 0x00, 0x39, 0x30, 0x35, 0x00};
    objectAddress = ScanSegments(hProc, array1, sizeof(array1));
  }
  if (!objectAddress) {
    printf("[Failed]: GetStatusAddress\n");
    exit(1);
  }
  return objectAddress + 0x2;
}

void GetSkillSpeed(HWND hwnd, BOOL bFast, BOOL bHorse) {
  SendKeyBackground(hwnd, SKILL_SHIELD);
  Sleep(TIME_DELAY);
  if (bFast) {
    SendKeyWithAlt(hwnd, SKILL_INSTANT);
    Sleep(TIME_DELAY);
    SendKeyWithAlt(hwnd, SKILL_ACCELERATE);
    Sleep(2000);
  } else {
    SendKeyWithAlt(hwnd, SKILL_CONCENTRATED);
    Sleep(TIME_DELAY);
    SendKeyWithAlt(hwnd, SKILL_ACCELERATE);
    Sleep(4600);
  }
  if (bHorse) {
    SendKeyWithAlt(hwnd, SKILL_HORSE);
    Sleep(TIME_DELAY);
  }
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;
  DWORD pid = GetProcessIdByName(L"qqffo.exe");
  HANDLE hProcess = GetProcessHandle(pid);
  DWORD_PTR hpAddress = GetAddressHealth(hProcess);
  printf("[Success]: health value %x.\n", hpAddress);
  DWORD_PTR maAddress = GetAddressStatus(hProcess);

  DWORD threshold = 2600;
  int count = 0;
  BYTE gbk[] = {0x34, 0x38, 0x39};

  while (1) {
    if (ReadMemoryShort(hProcess, hpAddress) < threshold) {
      GetSkillHealth(hWnd);
    } else {
      GetSkillAttack(hWnd);
      count++;
      if (count > 10) {
        count = 0;
        BYTE buf[3];
        if (ReadProcessMemory(hProcess, (void *)maAddress, &buf, sizeof(buf),
                              NULL) != 0) {
          if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2]) {
            GetSkillStatus(hWnd);
          }
        }
      }
    }
    Sleep(1000);
  }
  return 0;
}
int main() {
  int k1 = 1, k2 = 2, k3 = 3, k8 = 8, k9 = 9, k11 = 11;
  HWND hWnd;
  if (TARGET_HANDLE)
    hWnd = (HWND)TARGET_HANDLE;
  else
    hWnd = GetHWNDByClassName(CLASS_NAME);

  // SetHotKey(k1, 0, 0x31);
  // SetHotKey(k8, 0, 0x38);
  // SetHotKey(k9, 0, 0x39);
  // SetHotKey(k2, MOD_CONTROL, 0x4A);
  SetHotKey(k11, MOD_CONTROL, 0x4E);

  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];
  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message != WM_HOTKEY) continue;
    if (msg.wParam == k1) {
      GetSkillSpeed(hWnd, TRUE, TRUE);
      //   DWORD pid = GetProcessIdByName(L"qqffo.exe");
      //   HANDLE hProcess = GetProcessHandle(pid);
      //   SIZE_T hpAddress = GetAddressHealth(hProcess);
      //   printf("Health Value: %x.\n", GetAddressSpeed(hProcess));
      /*PostMessage(hWnd, 0x104, 0x12, 0x20380001);
      Sleep(100);

      PostMessage(hWnd, 0x104, 0x43, 0x202E0001);
      Sleep(100);

      PostMessage(hWnd, 0x105, 0x43, 0xE02E0001);

      Sleep(100);
      PostMessage(hWnd, 0x101, 0x12, 0xC0380001);*/
    } else if (msg.wParam == k9) {
      GetSkillStatus(hWnd);
    } else if (msg.wParam == k8) {
      GetSkillSpeed(hWnd, FALSE, FALSE);
    } else if (msg.wParam == k2) {
      if (!hThread) {
        hThread =
            CreateThread(NULL, 0, Strategy, &hWnd, 0, &dwThreadIdArray[0]);
        mStatus = TRUE;
        printf("Create Thread 1.\n");
      } else {
        if (mStatus) {
          SuspendThread(hThread);
          mStatus = FALSE;
          printf("Suspend Thread 1.\n");
        } else {
          ResumeThread(hThread);
          mStatus = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    } else if (msg.wParam == k11) {
      size_t len = 100;
      wchar_t *buf = malloc(sizeof(wchar_t) * len);
      srand(time(NULL));
      int count = 1;
      while (1) {
        memset(buf, 0, len);
      swprintf(buf, len, L"【/C%02d%03d/C00】: ===> 冰凌来进组/C%02d SS ZS",
                 rand() % 20, count++, rand() % 20);
        // if (count % 3 == 0) {
        //   swprintf(buf, len,
        //            L"【/C%02d%03d/C00】: ===> /[23,0] /C%02d"
        //            L" (┬＿┬)",
        //            rand() % 20, count++, rand() % 20);
        // } else if (count % 2 == 0) {
        //   swprintf(buf, len,
        //            L"【/C%02d%03d/C00】: ===> /[23,0] /C%02dJ52 鸟悟领",
        //            rand() % 20, count++, rand() % 20);
        // } else {
        //   swprintf(buf, len,
        //            L"【/C%02d%03d/C00】: ===> /[23,0] /C%02d领悟鸟 25J",
        //            rand() % 20, count++, rand() % 20);
        // }
        wchar_t *tmp = buf;
        while (*tmp) {
          wchar_t c = *tmp;
          PostMessageW(hWnd, WM_CHAR, c, 0);
          ++tmp;
        }
        PostMessage(hWnd, WM_KEYDOWN, VK_RETURN, 0);
        Sleep(100);
        PostMessage(hWnd, WM_KEYUP, VK_RETURN, 0);
        Sleep(6000);
      }
      free(buf);
    }
  }
}
