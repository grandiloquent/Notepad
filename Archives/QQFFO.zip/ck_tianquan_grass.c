﻿// -lgdi32
#include "shared.h"

static BOOL mStatus = FALSE;
#define TARGET_HANDLE 0
#define HAS_HORSE
#define ADDRESS_HEALTH 0x1e22b0a0
#define ADDRESS_MAP 0x8d3af20
#define ADDRESS_SELECT_NAME 0x1fcbd9c1

void CheckHealth(HANDLE hProcess, DWORD_PTR hpAddress, HWND hWnd) {
  if (ReadMemoryShort(hProcess, hpAddress) < 1700) {
    SendKeyBackground(hWnd, 0x76);
    Sleep(1000);
  }
}
void GoDestination(HANDLE hProcess, DWORD_PTR mapAddress, HWND hWnd) {
  GetSkillCKStealth(hWnd);
#ifdef HAS_HORSE
  GetSkillHorse(hWnd, FALSE);
#endif

  BYTE value[] = {0x62, 0x32, 0x19, 0x12};
  SIZE_T pos[] = {858, 400};
  GoPosition(hProcess, mapAddress, value, pos);

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 233) == 0xFFFFFF &&
          GetPixel(hdc, 542, 235) == 0xFFFFFF) {
        printf("2");

        break;
      } else {
        ClickRight(689, 321);
        Sleep(TIME_DELAY);
        Click(689, 321);
        Sleep(TIME_DELAY);
        printf("1");
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  Click(542, 385);
  Sleep(TIME_DELAY);
}
void SaveWarehouse(HWND hWnd) {
  HDC hdc = GetDC(NULL);
  if (hdc) {
    BOOL bSkip = GetPixel(hdc, 707, 683) == 0xFFFFFF &&
                 GetPixel(hdc, 707, 689) == 0xFFFFFF;
    if (!bSkip) {
      ReleaseDC(NULL, hdc);
      return;
    } else {
      ReleaseDC(NULL, hdc);
    }
  }
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 483, 231) == 0xFFFFFF &&
          GetPixel(hdc, 568, 233) == 0xFFFFFF &&
          GetPixel(hdc, 568, 238) == 0xFFFFFF) {
        break;
      } else {
        Click(COORDINATE_AUTOMATIC_PATH_FINDING_X,
              COORDINATE_AUTOMATIC_PATH_FINDING_Y);
        Sleep(TIME_DELAY);
        Click(COORDINATE_AUTOMATIC_PATH_ESSENTIAL_X,
              COORDINATE_AUTOMATIC_PATH_ESSENTIAL_Y);
        Sleep(TIME_DELAY);
        Click(887, 180);
        Sleep(TIME_DELAY);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }
  // 菜单项使用仓库
  Click(518, 385);
  Sleep(TIME_DELAY);
  // 双击任务品
  ClickDouble(1000, 451);
  Sleep(TIME_DELAY);
  //  聚焦仓库对话框
  Click(1105, 45);
  Sleep(TIME_DELAY);
  //  整理仓库
  Click(1154, 337);
  Sleep(TIME_DELAY);
  // 关闭仓库
  Click(1182, 43);
  Sleep(TIME_DELAY);
  // 关闭物品栏
  Click(1177, 265);
  Sleep(TIME_DELAY);
}
SIZE_T GetAddressLocation(HANDLE hProcess) {
  BYTE array[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                  0x00, 0x00, 0xcc, 0xec, 0xb6, 0xbc, 0x00};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + 0x08C0A338 - 0x08C0A32E;
}
void GoCity(HANDLE hProcess, DWORD_PTR mapAddress, HWND hWnd) {
  BYTE gbk[] = {0xcc, 0xec, 0xb6, 0xbc};

  while (1) {
    BYTE buf[4];
    ReadBuffer(hProcess, mapAddress, buf, 4);
    if (gbk[0] == buf[0] && gbk[1] == buf[1] && gbk[2] == buf[2] &&
        gbk[3] == buf[3]) {
      break;
    } else {
      GoBackCity(hWnd);
    }
    Sleep(1000);
  }
}

void GoLocation1(HANDLE hProcess, DWORD_PTR hpAddress, DWORD_PTR address,
                 DWORD_PTR selectName, HWND hWnd) {
  BYTE value[] = {0x05, 0x12, 0xD5, 0x0C};
  SIZE_T pos[] = {630, 420};
  GoPosition(hProcess, address, value, pos);
#ifdef HAS_HORSE
  GetSkillHorse(hWnd, TRUE);
#endif

  CheckHealth(hProcess, hpAddress, hWnd);
  Click(716, 365);
  Sleep(1000);

  BYTE gbk[] = {0xcd, 0xfc, 0xc7, 0xe9, 0xb2, 0xdd};
  char len = 6;

  while (1) {
    BYTE buf[len];
    ReadBuffer(hProcess, selectName, buf, len);
    if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2] &&
        buf[3] == gbk[3] && buf[4] == gbk[4] && buf[5] == gbk[5]) {
      printf("1");
      break;
    } else {
      printf("2");
      GetSkillSelectMonster(hWnd);
    }
    Sleep(1000);
  }

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 393, 39) == 0xAAEEFF &&
          GetPixel(hdc, 385, 29) == 0x000000) {
        SendKeyBackground(hWnd, 0x70);

        Sleep(1000);

        SendKeyBackground(hWnd, 0x71);
        Sleep(1000);

        CheckHealth(hProcess, hpAddress, hWnd);
      } else {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  printf("5");
  GetSkillSelectMonster(hWnd);
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;
  DWORD pid = GetProcessIdByName(L"qqffo.exe");
  HANDLE hProcess = GetProcessHandle(pid);
  DWORD_PTR hpAddress = ADDRESS_HEALTH;
  if (!hProcess) hpAddress = GetAddressHealth(hProcess);
  printf("[Success]: health value %x.\n", hpAddress);
  SIZE_T mapAddress = ADDRESS_MAP;
  if (!mapAddress) {
    mapAddress = GetAddressLocation(hProcess);
  }
  printf("[Success]: map value %x.\n", mapAddress);
  SIZE_T selectName = ADDRESS_SELECT_NAME;
  if (!selectName) {
    selectName = GetAddressSelectName(hProcess);
  }
  printf("[Success]: select name %x.\n", selectName);
  while (1) {
    HideOthers(hWnd);
    SaveWarehouse(hWnd);
    GoDestination(hProcess, mapAddress, hWnd);
    GoLocation1(hProcess, hpAddress, mapAddress, selectName, hWnd);
    // GetSkillCKStealth(hWnd);
    // CheckHealth(hProcess, hpAddress, hWnd);
    // GoLocation2(hProcess, hpAddress, mapAddress, selectName, hWnd);
    GoCity(hProcess, mapAddress, hWnd);
  }
  return 0;
}

void Go(int pos[2]) {
  ClickMap();
  ClickRight(pos[0], pos[1]);
  Sleep(TIME_DELAY);
  ClickMap();
}
int main() {
  int k1 = 1;
  HWND hWnd;
  if (TARGET_HANDLE)
    hWnd = (HWND)TARGET_HANDLE;
  else
    hWnd = GetHWNDByClassName(CLASS_NAME);

  SetHotKey(k1, MOD_CONTROL, 0x31);

  MSG msg = {0};
  HANDLE hThread = {0};

  DWORD dwThreadIdArray[1];
  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message != WM_HOTKEY) continue;
    if (msg.wParam == k1) {
      // int pos[2] ={630,420};
      // Go(pos);
      // return 0;
      if (!hThread) {
        hThread =
            CreateThread(NULL, 0, Strategy, &hWnd, 0, &dwThreadIdArray[0]);
        mStatus = TRUE;
        printf("Create Thread 2.\n");
      } else {
        if (mStatus) {
          SuspendThread(hThread);
          mStatus = FALSE;
          printf("Suspend Thread 2.\n");
        } else {
          ResumeThread(hThread);
          mStatus = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    }
  }
}
