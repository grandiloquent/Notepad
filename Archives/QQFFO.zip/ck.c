﻿// -lgdi32

#include "shared.h"
#include <math.h>

#define PI 3.14159265

#define CLASS_NAME "QQSwordWinClass"

#define TARGET_HANDLE 0

#define YS

static BOOL mStatus = FALSE;
static BOOL mStatus2 = FALSE;
static BOOL mStatus3 = FALSE;
static BOOL mStatus4 = FALSE;

void GetSkill() {}
void GetSkillHealth(HWND hWnd) {
  SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
}
void GetSkillStatus(HWND hWnd) {
  SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_INSTANT);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_DEFENSE);
  Sleep(2000);
  SendKeyWithAlt(hWnd, SKILL_INSTANT);
  Sleep(1000);
  SendKeyWithAlt(hWnd, SKILL_BLESSING);
  Sleep(2000);
}
void GetSkillAttack(HWND hWnd) {
  SendKeyBackground(hWnd, SKILL_EMIT_ENERGY);
  Sleep(TIME_DELAY);
  SendKeyBackground(hWnd, SKILL_EXORCISM);
  Sleep(TIME_DELAY);
  SendKeyBackground(hWnd, SKILL_SHENWEI);
  Sleep(TIME_DELAY);
}
SIZE_T GetAddressSpeed(HANDLE hProcess) {
  BYTE array[] = {0x74, 0x69, 0x70, 0x00, 0x65, 0x62, 0x61,
                  0x72, 0x00, 0x2F, 0x6B, 0x65, 0x79, 0x63,
                  0x68, 0x61, 0x72, 0x2E, 0x67, 0x73, 0x61};
  SIZE_T objectAddress = ScanSegments(hProcess, array, sizeof(array));
  return objectAddress + (0x1ED6B291 - 0x1ED6B268);
}
SIZE_T GetAddressStatus(HANDLE hProc) {
  // GBK 编码的字符串的字节组 0x37, 0x32, 0x34
  // 无祝福术
  BYTE array[] = {0x8F, 0x00, 0x34, 0x38, 0x39, 0x00};
  SIZE_T objectAddress = ScanSegments(hProc, array, sizeof(array));
  if (!objectAddress) {
    BYTE array1[] = {0x8F, 0x00, 0x39, 0x30, 0x35, 0x00};
    objectAddress = ScanSegments(hProc, array1, sizeof(array1));
  }
  if (!objectAddress) {
    printf("[Failed]: GetStatusAddress\n");
    exit(1);
  }
  return objectAddress + 0x2;
}
void GetSkillExplosion(HWND hWnd) {
  SendKeyBackground(hWnd, SKILL_CK_TRAP_BOMB);
  Sleep(1000);
}

void GetSkillExplosionFocus(HWND hWnd) {
  int width = GetSystemMetrics(SM_CXSCREEN) / 2;
  int height = GetSystemMetrics(SM_CYSCREEN) / 2;
  int delay = 1500;
  BOOL bLeft = TRUE;
  while (1) {
    if (bLeft) {
      Click(width + 100, height);
      Sleep(1000);
      SendKeyBackground(hWnd, 0x74);
      Click(width - 100, height);
      Sleep(delay);
      Click(width - 100, height);
      Sleep(1000);

    } else {
      Click(width - 100, height);
      Sleep(1000);
      SendKeyBackground(hWnd, 0x74);
      Click(width + 100, height);
      Sleep(delay);
      Click(width + 100, height);
      Sleep(1000);
    }
    bLeft = !bLeft;
  }
}

void GetSkillExplosionPoint(HWND hWnd) {
  int width = GetSystemMetrics(SM_CXSCREEN) / 2;
  int height = GetSystemMetrics(SM_CYSCREEN) / 2;
  int delay = 2500;
  BOOL bLeft = TRUE;
  size_t offset = 100;
  while (1) {
    // PostMessage(hWnd, WM_MOUSEMOVE,  WM_LBUTTONDOWN, MAKELONG(width + offset,
    // height)); PostMessage(hWnd, WM_MOUSEMOVE,  WM_LBUTTONUP, MAKELONG(width +
    // offset, height));

    // PostMessage(hWnd, WM_LBUTTONDOWN, 0x1, 0);
    // PostMessage(hWnd, WM_LBUTTONUP, 0, 0);
    SendKeyBackground(hWnd, 0x73);
    // Click(width , height);
    Sleep(delay);
    SendKeyBackground(hWnd, 0x74);
    // Click(width , height);
    Sleep(delay);
    // if (bLeft) {
    //   PostMessage(hWnd, WM_MOUSEMOVE, MK_LBUTTON,
    //               MAKELONG(width + offset, height));
    //   PostMessage(hWnd, WM_LBUTTONDOWN, 0x1,
    //               MAKELPARAM(width + offset, height));
    //   PostMessage(hWnd, WM_LBUTTONUP, 0, MAKELPARAM(width + offset, height));
    //   Sleep(1000);
    // } else {
    //   PostMessage(hWnd, WM_MOUSEACTIVATE, 0, 0);
    //   SendMessage(hWnd, WM_MOUSEMOVE, 0, MAKELPARAM(width - offset, height));
    //   Sleep(1000);

    //   SendMessage(hWnd, WM_LBUTTONDOWN, 0x1,
    //               MAKELPARAM(width - offset, height));
    //   Sleep(150);
    //   SendMessage(hWnd, WM_LBUTTONUP, 0, MAKELPARAM(width - offset, height));
    //   Sleep(1000);
    // }
    bLeft = !bLeft;
  }
}
void GetSkillExplosionCircle(HWND hWnd) {
  int width = GetSystemMetrics(SM_CXSCREEN);
  int height = GetSystemMetrics(SM_CYSCREEN);
  int count = 0;
  double x, rx, val, ry;

  x = 45.0;
  val = PI / 180.0;
  rx = cos(x * val);

  int hx = width / 2;
  int hy = height / 2;
  int offset = 100;
  int o = rx * offset;
  int delay = 2500;

  while (1) {
    if (count == 0) {
      GetSkillExplosion(hWnd);
      Click(hx + offset, hy);
      Sleep(delay);
    } else if (count == 1) {
      GetSkillExplosion(hWnd);
      Click(hx + o, hy + o);
      Sleep(delay);
    } else if (count == 2) {
      GetSkillExplosion(hWnd);
      Click(hx, hy + offset);
      Sleep(delay);
    } else if (count == 3) {
      GetSkillExplosion(hWnd);
      Click(hx - o, hy + o);
      Sleep(delay);
    } else if (count == 4) {
      GetSkillExplosion(hWnd);
      Click(hx - offset, hy);
      Sleep(delay);
    } else if (count == 5) {
      GetSkillExplosion(hWnd);
      Click(hx - o, hy - o);
      Sleep(delay);
    } else if (count == 6) {
      GetSkillExplosion(hWnd);
      Click(hx, hy - offset);
      Sleep(delay);
    } else if (count == 7) {
      GetSkillExplosion(hWnd);
      Click(hx + o, hy - o);
      Sleep(delay);
    } else {
      count = 0;

      // Click(width / 2 + 250, height / 2);
      // Sleep(3000);
      continue;
    }
    count++;
  }
}
DWORD WINAPI StrategyExplosion(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;
  // GetSkillExplosionPoint(hWnd);
  GetSkillExplosionFocus(hWnd);
  // int delay = 2500;

  // int width = GetSystemMetrics(SM_CXSCREEN) / 2;
  // int height = GetSystemMetrics(SM_CYSCREEN) / 2;
  // for (int i = 0; i < 8; i++) {
  //   GetSkillExplosion(hWnd);
  //   Click(width + 100, height);
  //   Sleep(delay);
  // }
  // if (count == 0) {
  //   GetSkillExplosion(hWnd);
  //   Click(width / 2 + 100, height / 2);
  //   Sleep(3000);
  // } else if (count == 1) {
  //   GetSkillExplosion(hWnd);
  //   Click(width / 2, height / 2 + 100);
  //   Sleep(3000);
  // } else if (count == 2) {
  //   GetSkillExplosion(hWnd);
  //   Click(width / 2 - 100, height / 2);
  //   Sleep(3000);
  // } else if (count == 3) {
  //   GetSkillExplosion(hWnd);
  //   Click(width / 2, height / 2 - 100);
  //   Sleep(3000);
  // } else {
  //   count = 0;

  //   Click(width / 2 + 250, height / 2);
  //   Sleep(3000);
  //   continue;
  // }
  // count++;
  return 0;
}
DWORD WINAPI StrategySmartExplosion(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;

  int delay = 2000;
  int count = 0;
  int offset = 300;
  int width = GetSystemMetrics(SM_CXSCREEN) - offset;
  int height = GetSystemMetrics(SM_CYSCREEN) / 2;
  int w = GetSystemMetrics(SM_CXSCREEN) / 2;
  printf("%d %d.\n", width, height);

  while (1) {
    if (count == 0) {
      SetCursorPos(w + offset, height);
      GetSkillExplosion(hWnd);
      ClickDelay(width, height, delay);
    } else if (count == 1) {
      SetCursorPos(w - offset, height);
      GetSkillExplosion(hWnd);
      ClickDelay(offset, height, delay);
    } else if (count == 2) {
      SetCursorPos(w - offset, height);
      GetSkillExplosion(hWnd);
      ClickDelay(w, height + offset, delay);
    } else {
      count = 0;
      continue;
    }
    count++;
  }
  return 0;
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;
  DWORD pid = GetProcessIdByName(L"qqffo.exe");
  HANDLE hProcess = GetProcessHandle(pid);
  DWORD_PTR hpAddress = GetAddressHealth(hProcess);
  printf("[Success]: health value %x.\n", hpAddress);
  DWORD_PTR maAddress = GetAddressStatus(hProcess);

  DWORD threshold = 2600;
  int count = 0;
  BYTE gbk[] = {0x34, 0x38, 0x39};

  while (1) {
    if (ReadMemoryShort(hProcess, hpAddress) < threshold) {
      GetSkillHealth(hWnd);
    } else {
      GetSkillAttack(hWnd);
      count++;
      if (count > 10) {
        count = 0;
        BYTE buf[3];
        if (ReadProcessMemory(hProcess, (void *)maAddress, &buf, sizeof(buf),
                              NULL) != 0) {
          if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2]) {
            GetSkillStatus(hWnd);
          }
        }
      }
    }
    Sleep(1000);
  }
  return 0;
}
DWORD WINAPI StrategyContinuousPressKey(LPVOID lpParam) {
  HWND hWnd = *(HWND *)lpParam;
  while (1) {
    SendKeyBackground(hWnd, 0x76);
    Sleep(1000);
  }
  return 0;
}

int main() {
  int k1 = 1, k2 = 2, k3 = 3, k6 = 6, k7 = 7, k8 = 8, k9 = 9, k11 = 11,
      k12 = 12;
  HWND hWnd;
  if (TARGET_HANDLE)
    hWnd = (HWND)TARGET_HANDLE;
  else
    hWnd = GetHWNDByClassName(CLASS_NAME);

  SetHotKey(k1, 0, 0x31);
  SetHotKey(k6, 0, 0x36);
  SetHotKey(k7, 0, 0x37);
  SetHotKey(k8, 0, 0x38);
  SetHotKey(k9, 0, 0x39);
  SetHotKey(k2, MOD_CONTROL, 0x4A);
  SetHotKey(k11, MOD_CONTROL, 0x4D);
  SetHotKey(k12, MOD_CONTROL, 0x4E);

  printf(
      "\n\n=========\n"
      "[6]: Continuous mine release\n"
      "[8]: StrategyExplosion\n"
      "[Ctrl+M]: Post Chat Text\n"
      "[Ctrl+N]: Continuous button\n");
  MSG msg = {0};
  HANDLE hThread = {0};
  HANDLE hThread2 = {0};
  HANDLE hThread3 = {0};
  HANDLE hThread4 = {0};

  DWORD dwThreadIdArray[4];
  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message != WM_HOTKEY) continue;
    if (msg.wParam == k1) {
      GetSkillExplosion(hWnd);
    } else if (msg.wParam == k9) {
      GetSkillStatus(hWnd);
    } else if (msg.wParam == k6) {
      for (int i = 0; i < 6; i++) {
        GetSkillExplosion(hWnd);
        Sleep(2000);
      }
    } else if (msg.wParam == k7) {
      if (!hThread4) {
        hThread4 = CreateThread(NULL, 0, StrategySmartExplosion, &hWnd, 0,
                                &dwThreadIdArray[3]);
        mStatus4 = TRUE;
        printf("Create Thread 4.\n");
      } else {
        if (mStatus4) {
          SuspendThread(hThread4);
          mStatus4 = FALSE;
          printf("Suspend Thread 4.\n");
        } else {
          ResumeThread(hThread4);
          mStatus4 = TRUE;
          printf("Resume Thread 4.\n");
        }
      }
    } else if (msg.wParam == k8) {
      if (!hThread2) {
        hThread2 = CreateThread(NULL, 0, StrategyExplosion, &hWnd, 0,
                                &dwThreadIdArray[1]);
        mStatus2 = TRUE;
        printf("Create Thread 2.\n");
      } else {
        if (mStatus2) {
          SuspendThread(hThread2);
          mStatus2 = FALSE;
          printf("Suspend Thread 2.\n");
        } else {
          ResumeThread(hThread2);
          mStatus2 = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    } else if (msg.wParam == k2) {
      if (!hThread) {
        hThread =
            CreateThread(NULL, 0, Strategy, &hWnd, 0, &dwThreadIdArray[0]);
        mStatus = TRUE;
        printf("Create Thread 1.\n");
      } else {
        if (mStatus) {
          SuspendThread(hThread);
          mStatus = FALSE;
          printf("Suspend Thread 1.\n");
        } else {
          ResumeThread(hThread);
          mStatus = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    } else if (msg.wParam == k11) {
      size_t len = 100;
      wchar_t *buf = malloc(sizeof(wchar_t) * len);
      srand(time(NULL));
      int count = 1;
      while (1) {
        memset(buf, 0, len);
        swprintf(buf, len, L"【/C%02d%03d/C00】: ===> 冰凌来进组/C%02d SS ZS",
                 rand() % 20, count++, rand() % 20);
        // if (count % 3 == 0) {
        //   swprintf(buf, len,
        //            L"【/C%02d%03d/C00】: ===> /[23,0] /C%02d"
        //            L" (┬＿┬)",
        //            rand() % 20, count++, rand() % 20);
        // } else if (count % 2 == 0) {
        //   swprintf(buf, len,
        //            L"【/C%02d%03d/C00】: ===> /[23,0] /C%02dJ52 鸟悟领",
        //            rand() % 20, count++, rand() % 20);
        // } else {
        //   swprintf(buf, len,
        //            L"【/C%02d%03d/C00】: ===> /[23,0] /C%02d领悟鸟 25J",
        //            rand() % 20, count++, rand() % 20);
        // }
        wchar_t *tmp = buf;
        while (*tmp) {
          wchar_t c = *tmp;
          PostMessageW(hWnd, WM_CHAR, c, 0);
          ++tmp;
        }
        PostMessage(hWnd, WM_KEYDOWN, VK_RETURN, 0);
        Sleep(100);
        PostMessage(hWnd, WM_KEYUP, VK_RETURN, 0);
        Sleep(6000);
      }
      free(buf);
    } else if (msg.wParam == k12) {
      if (!hThread3) {
        hThread3 = CreateThread(NULL, 0, StrategyContinuousPressKey, &hWnd, 0,
                                &dwThreadIdArray[2]);
        mStatus3 = TRUE;
        printf("Create Thread 2.\n");
      } else {
        if (mStatus3) {
          SuspendThread(hThread3);
          mStatus3 = FALSE;
          printf("Suspend Thread 2.\n");
        } else {
          ResumeThread(hThread3);
          mStatus3 = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    }
  }
}
