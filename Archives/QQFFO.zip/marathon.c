// -lgdi32

#include "shared.h"

#define APP_HWND 0
#define APP_PID 4356

static BOOL mStatus = FALSE;

///
void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len) {
  if (ReadProcessMemory(hProc, (void*)address, buf, len, NULL) == 0) {
    printf("[Failed]: ReadBuffer\n");
  }
}
HWND GetHWND() {
  HWND hWnd;
  if (APP_HWND != 0)
    hWnd = (HWND)APP_HWND;
  else
    hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    printf("[Failed]: GetHWND.\n");
    exit(1);
  }
  return hWnd;
}

DWORD GetPid() {
  if (APP_PID)
    return APP_PID;
  else
    return GetProcessIdByName(L"qqffo.exe");
}
HANDLE GetProcess(DWORD pid) {
  HANDLE hToken = GetToken(GetCurrentProcess());

  if (!SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    exit(1);
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    exit(1);
  }
  return hTargetProc;
}
SIZE_T GetAddressMap(HANDLE hProcess, BYTE search[], size_t len) {
  SIZE_T address = ScanSegments(hProcess, search, len);
  if (!address) {
    printf("[Failed]: %s.\n", "GetAddressMap");
    exit(1);
  }
  return address + (0x08C1A450 - 0x08C1A446);
}
void GoLocation(HANDLE hProc, DWORD_PTR address, BYTE value[], size_t pos[]) {
  while (1) {
    BYTE buf1[2];
    ReadBuffer(hProc, address - 0xd0, buf1, 2);
    BYTE buf2[2];
    ReadBuffer(hProc, address - 0xcc, buf2, 2);
    if (buf1[0] == value[0] && buf1[1] == value[1] && buf2[0] == value[2] &&
        buf2[1] == value[3]) {
      break;
    } else {
      ClickMap();
      ClickRight(pos[0], pos[1]);
      Sleep(1000);
      ClickMap();
    }
    Sleep(3000);
  }
}
// void GoLocation(HANDLE hProcess, SIZE_T mapAddress, BYTE gbk[], size_t len,
//                 size_t target[2]) {
//   // GetPixel(hdc,917,391)==0x77AABB
//   BYTE gbk2[] = {0xcc, 0xec, 0xbf, 0xd5, 0xd6, 0xae,
//                  0xc8, 0xaa, 0xc8, 0xfd, 0xb2, 0xe3};
//   size_t pos[] = {711, 381};
//   while (1) {
//     BYTE buf[len];
//     ReadBuffer(hProcess, mapAddress, buf, len);
//     BOOL bBreak = TRUE;

//     for (int i = 0; i < len; i++) {
//       if (gbk[i] != buf[i]) {
//         bBreak = FALSE;
//         break;
//       }
//     }
//     if (bBreak) {
//       break;
//     } else {
//       ClickMap();
//       ClickRight(target[0], target[1]);
//       Sleep(1000);
//       ClickMap();
//     }
//     Sleep(1000);
//   }
// }
///
void GoChangleVillageFromDragonCity(HANDLE hProcess, SIZE_T mapAddress) {
  BYTE address1[] = {0xE0, 0x3B, 0x69, 0x12};
  size_t pos1[] = {917, 391};

  GoLocation(hProcess, mapAddress, address1, pos1);

  size_t pos2[][2] = {//  自动寻路
                      {1120, 172},
                      // 关键NPC
                      {1066, 174},
                      // 龙城飞
                      {872, 220}};

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 831, 258) == 0xFFFFFF &&
          GetPixel(hdc, 504, 259) == 0xFFFFFF) {
        break;
      } else {
        for (int i = 0; i < 3; ++i) {
          Click(pos2[i][0], pos2[i][1]);
          Sleep(1000);
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  size_t pos3[][2] = {// [?]: 我想使用传送服务 菜单列表中第三位
                      {548, 403},
                      {500, 240},
                      {458, 469}};
  for (int i = 0; i < 3; ++i) {
    Click(pos3[i][0], pos3[i][1]);
    Sleep(1000);
  }
}
void GoYinSongGuWest(HANDLE hProcess, SIZE_T mapAddress) {
  BYTE gbk[] = {0xd2, 0xf7, 0xcb, 0xc9, 0xb9, 0xc8, 0xce, 0xf7};

  size_t pos2[][2] = {//  自动寻路
                      {1120, 172},
                      // 地图
                      {1068, 212},
                      // 吟松谷西
                      {872, 220}};
  while (1) {
    BYTE buf[8];
    ReadBuffer(hProcess, mapAddress, buf, 8);
    if (buf[0] == gbk[0] && buf[1] == gbk[1] && buf[2] == gbk[2] &&
        buf[3] == gbk[3] && buf[4] == gbk[4] && buf[5] == gbk[5] &&
        buf[6] == gbk[6] && buf[7] == gbk[7]) {
      break;

    } else {
    }
  }
}
///
DWORD WINAPI Strategy(LPVOID lpParam) {
  size_t pos[2] = {0};
  BOOL bFound = FALSE;
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 871, 203) == 0x1188DD &&
          GetPixel(hdc, 903, 201) == 0x001155 &&
          GetPixel(hdc, 479, 353) == 0x99EEFF) {
        Click(510, 365);
        Sleep(2000);
      }
      for (int x = 907; x < 1168; x++) {
        for (int y = 260; y < 302; y++) {
          if (GetPixel(hdc, x, y) == 0x00D9FE &&
              GetPixel(hdc, x + 7, y) == 0x00D9FE &&
              GetPixel(hdc, x, y + 3) == 0x00D9FE) {
            pos[0] = x;
            pos[1] = y;
            bFound = TRUE;
            break;
          }
        }
        if (bFound) {
          Click(pos[0], pos[1]);
          bFound = FALSE;
          break;
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }

  //   DWORD pid = GetPid();
  //   HANDLE hProcess = GetProcess(pid);

  //   //[?]:刺客
  //   BYTE searchArray[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  //                         0x00, 0x00, 0xC1, 0xFA, 0xB3, 0xC7, 0x00};
  //   SIZE_T mapAddress = GetAddressMap(hProcess, searchArray,
  //   sizeof(searchArray)); printf("%x.\n", mapAddress);
  //   GoChangleVillageFromDragonCity(hProcess, mapAddress);
}

int main() {
  int k1 = 1, k2 = 2, k3 = 3, k11 = 11;
  HWND hWnd = GetHWND();

  SetHotKey(k1, MOD_CONTROL, 0x31);

  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];
  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message != WM_HOTKEY) continue;
    if (msg.wParam == k1) {
      //   GoLocation();
      //   return 0;

      if (!hThread) {
        hThread =
            CreateThread(NULL, 0, Strategy, &hWnd, 0, &dwThreadIdArray[0]);
        mStatus = TRUE;
        printf("Create Thread 1.\n");
      } else {
        if (mStatus) {
          SuspendThread(hThread);
          mStatus = FALSE;
          printf("Suspend Thread 1.\n");
        } else {
          ResumeThread(hThread);
          mStatus = TRUE;
          printf("Resume Thread 1.\n");
        }
      }
    }
  }
}
