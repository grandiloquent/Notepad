#ifndef FFO_H
#define FFO_H

#include <Windows.h>
#include "key.h"

#define LEVEL 45

#define DEFAULT_DELAY 1000
#define HAS_HORSE_PET 1
// 技能[技能栏位置 药师]
// 坐骑[宠物]
#define POS_SKILL_HORSE_X 631
#define POS_SKILL_HORSE_Y 675
#define POS_SKILL_SHIELD_X 399
#define POS_SKILL_SHIELD_Y 715
#define POS_SKILL_DEFENSE_X 507
#define POS_SKILL_DEFENSE_Y 679
#define POS_SKILL_BLESSING_X 546
#define POS_SKILL_BLESSING_Y 678

// 技能[药师]
// F1 光弹
#define KEY_1_SKILL_LIGHT_BOMB 0x70
// F2 治愈
#define KEY_1_SKILL_HEAL 0x71
// F3 光盾术
#define KEY_1_SKILL_SHIELD 0x72
// F4 释能
#define KEY_1_SKILL_INJECTION_ENERGY 0x73
// F5 驱魔
#define KEY_1_SKILL_EXORCISM 0x74
// F6 定身
#define KEY_1_SKILL_SET_UP 0x75
// F7 圣光
#define KEY_1_SKILL_HOLY_LIGHT 0x79

// ALT+3 集中
#define KEY_1_SKILL_FOCUS 0x33

// ALT+4 瞬发
#define KEY_1_SKILL_INSTANTS 0x34
// ALT+5 加速
#define KEY_1_SKILL_ACCELERATE 0x35
// ALT+6 防御
#define KEY_1_SKILL_DEFENSE 0x36
// ALT+7 祝福
#define KEY_1_SKILL_BLESSING 0x37
// ALT+8 净化
#define KEY_1_SKILL_PURIFICATION 0x38

// 技能[宠物]
// ALT+1 收集
#define KEY_1_SKILL_COLLECT 0x31
// ALT+2 灵通
#define KEY_1_SKILL_PSYCHIC 0x32
// ALT+9 坐骑
#define KEY_1_SKILL_HORSE 0x39

// 消耗品
// ALT+0 回城
#define KEY_1_SKILL_GO_CITY 0x30

// 快捷键
// ALT+N
#define KEY_SHORTCUT_TASKLIST 0x4E

void _Attack(HWND hWnd);
BOOL _CheckSelectedMonster(HDC hdc);
void _GetHorse(HWND hWnd);
void _GetStatus(HWND hWnd);
void _GetStatusAccelerate(HWND hWnd);
void _GoLocationWithMap(size_t pos[]);
void _GoLocation(int x, int y, int delay, int array[][3], size_t len);
void _GoLocationThen(BOOL (*predict)(HDC), void (*f)());
void _RefreshStrength(HWND hWnd, HDC hdc);
void _SelectMonster(HWND hWnd);

void _Attack(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x70);
  Sleep(1000);
}
BOOL _CheckSelectedMonster(HDC hdc) {
  return ((GetPixel(hdc, 395, 37) == 0xAAEEFF &&
           GetPixel(hdc, 394, 21) == 0x336688) &&
          !(GetPixel(hdc, 375, 34) == 0xB3B3BD &&
            GetPixel(hdc, 376, 40) == 0xB3B3BD) &&
          !(GetPixel(hdc, 447, 526) == 0x5A5AFF &&
            GetPixel(hdc, 246, 516) == 0x5A5AFF) &&
          !(GetPixel(hdc, 432, 27) == 0x00D9FE &&
            GetPixel(hdc, 454, 34) == 0x00D9FE));
}
void _GetHorse(HWND hWnd) {
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_HORSE);
  Sleep(1000);
}
void _GetStatus(HWND hWnd) {
  _SendKeyBackground(hWnd, KEY_1_SKILL_SHIELD);
  Sleep(DEFAULT_DELAY);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_FOCUS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_DEFENSE);
  Sleep(3000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_FOCUS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_BLESSING);
  Sleep(3000);
}
void _GetStatusAccelerate(HWND hWnd) {
  _SendKeyBackground(hWnd, KEY_1_SKILL_SHIELD);
  Sleep(DEFAULT_DELAY);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_FOCUS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_ACCELERATE);
  Sleep(4000);
}
void _GoLocationWithMap(size_t pos[]) {
  _Click(1096, 105);
  Sleep(500);
  _ClickRight(pos[0], pos[1]);
  Sleep(500);
  _Click(1096, 105);
  Sleep(500);
}
void _GoLocation(int x, int y, int delay, int array[][3], size_t len) {
  // array[][3] {x坐标,y,color 十六进制颜色值 Little}
  // len array的长度
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      BOOL skip = TRUE;
      for (size_t i = 0; i < len; i++) {
        if (GetPixel(hdc, array[i][0], array[i][1]) != array[i][2]) {
          skip = FALSE;
          break;
        }
      }
      if (skip) break;
      _Click(1106, 108);
      Sleep(delay);
      _ClickRight(x, y);
      Sleep(delay);
      _Click(1106, 108);
      Sleep(delay);
      ReleaseDC(NULL, hdc);
    }
  }
}
void _GoLocationThen(BOOL (*predict)(HDC), void (*f)()) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      f();
      ReleaseDC(NULL, hdc);
    }
  }
}
void _RefreshStrength(HWND hWnd, HDC hdc) {
  if (GetPixel(hdc, 324, 41) != 0x22AA11) {
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x71);
    Sleep(1000);
  }
}
void _SelectMonster(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x9);
  Sleep(1000);
}
#endif
