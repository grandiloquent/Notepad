
// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#include <tchar.h>
#include "key.h"
#include "ffo.h"

#define POS_ALT_F1_X 703
#define POS_ALT_F1_Y 684
#define POS_AUTO_LEFT_X 404
#define POS_AUTO_LEFT_Y 378
#define POS_AUTO_RIGHT_X 954
#define APP_HWND 0

static BOOL mStatus = FALSE;
static BOOL mStatus2 = FALSE;

DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  int count = 0;
  int offset = 350;
  while (1) {
    _SendKeyWithAlt(hWnd, 0x39);
    Sleep(1000);
  }

  // _SendKeyBackground(hWnd, 0x71);
  // Sleep(1000);
  // _SendKeyBackground(hWnd, 0x72);
  // Sleep(1000);
  // _SendKeyBackground(hWnd, 0x74);
  // Sleep(5000);
  // if (count > 50) {
  //   count = 0;
  //   _GetStatus(hWnd);
  // }
  // count++;

  return 0;
}

DWORD WINAPI StrategyContinuousPress(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  while (1) {
    _ClickDouble(POS_ALT_F1_X, POS_ALT_F1_Y);
    Sleep(1000);
  }
  return 0;
}

void ContinuousBroadcast(HWND hWnd, const wchar_t* buf) {
  // const wchar_t* buf = L"你是一个大笨蛋";
  srand(time(NULL));  // Seed init, should only be called once.
  size_t count = 0;
  while (1) {
    count++;
    // const wchar_t* tmp = buf;
    size_t len = 50;
    wchar_t* str = malloc(sizeof(wchar_t) * len);
    // memset(tmp, 0, len);
    int r1 = rand() % 20;
    int r2 = rand() % 20;
    int r3 = rand() % 20;
    int r4 = rand() % 20;
    int r5 = rand() % 20;
    int r6 = rand() % 20;
    // swprintf(str, len,
    // L"/C%02d走/C%02d过/C%02d路/C%02d过/C%02d不/C%02d要错过",
    //          r6, r5, r1, r2, r3, r4);
    swprintf(str, len, L"/C%02d%d/C%02d 你的/C%02d保卫/C%02d战士OR/C%02d剑客/C%02d进组",
             r6, count, r5, r1, r2, r3, r4);
    wchar_t* tmp = str;
    while (*tmp) {
      // UINT u_code = (UINT)_tcstol(tmp + 2, NULL, 16);
      // wchar_t wc1, wc2;
      // if (u_code >= 0x10000) {
      //   // Supplementary characters are encoded as UTF-16 and split into two
      //   // messages.
      //   u_code -= 0x10000;
      //   wc1 = 0xd800 + ((u_code >> 10) & 0x3ff);
      //   wc2 = 0xdc00 + (u_code & 0x3ff);
      // } else {
      //   wc1 = (wchar_t)u_code;
      //   wc2 = 0;
      // }
      // PostMessageW(hWnd, WM_CHAR, wc1, 0);
      // if (wc2) PostMessageW(hWnd, WM_CHAR, wc2, 0);
      // _SendUnicodeChar(*tmp);
      wchar_t ch = *tmp;
      PostMessageW(hWnd, WM_CHAR, ch, 0);

      ++tmp;
    }
    free(str);
    // printf("%s.\n", "123");

    _SendKeyBackground(hWnd, 0xd);
    Sleep(5000);
  }
}
int main() {
  // (HWND)0x00080170;  //
  HWND hWnd;
  if (APP_HWND) {
    printf("%s.\n", "1");
    hWnd = (HWND)APP_HWND;
  } else {
    hWnd = FindWindow("QQSwordWinClass", NULL);
  }
  // HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  } else {
    printf("Window Handle %p.\n", hWnd);
  }

  //===
  int k1 = 1;
  int k2 = 2;
  int k3 = 3;
  int k5 = 5;
  int k6 = 6;
  int k7 = 7;
  int k8 = 8;
  int k9 = 9;
  int k10 = 10;

  if (RegisterHotKey(NULL, k1, 0, 0x31)) {
    printf("Register Hotkey: [1] Success.\n");
  }
  if (RegisterHotKey(NULL, k7, 0, 0x38)) {
    printf("Register Hotkey: [8] Success. [accelerate and horse]\n");
  }
  if (RegisterHotKey(NULL, k9, 0, 0x37)) {
    printf("Register Hotkey: [7] Success. [accelerate]\n");
  }
  if (RegisterHotKey(NULL, k10, 0, 0x33)) {
    printf("Register Hotkey: [3] Success.[Set up]\n");
  }
  if (RegisterHotKey(NULL, k3, 0, 0x39)) {
    printf("Register Hotkey: [9] Success.[status]\n");
  }
  if (RegisterHotKey(NULL, k6, 0, 0x79)) {
    printf("Register Hotkey: [F10] Success.[Continuous press]\n");
  }
  if (RegisterHotKey(NULL, k5, 0, 0x32)) {
    printf("Register Hotkey: [2] Success.[Strong blow]\n");
  }
  if (RegisterHotKey(NULL, k8, MOD_CONTROL, 0x4D)) {
    printf("Register Hotkey: [Ctrl+M] Success.[Keep speaking]\n");
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  HANDLE hThread1 = {0};
  HANDLE hThread2 = {0};

  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        _SendKeyWithAlt(hWnd, 0x39);

        printf("%s.\n", "1");
        // return 0;
        // if (!hThread) {
        //   hThread =
        //       CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[0]);
        //   mStatus = TRUE;
        //   printf("Create Thread 1.\n");
        // } else {
        //   if (mStatus) {
        //     SuspendThread(hThread);
        //     mStatus = FALSE;
        //     printf("Suspend Thread 1.\n");
        //   } else {
        //     ResumeThread(hThread);
        //     mStatus = TRUE;
        //     printf("Resume Thread 1.\n");
        //   }
        // }
      } else if (msg.wParam == k6) {
        if (!hThread2) {
          hThread2 = CreateThread(NULL, 0, StrategyContinuousPress, hWnd, 0,
                                  &dwThreadIdArray[2]);
          mStatus2 = TRUE;
          printf("Create Thread 3.\n");
        } else {
          if (mStatus2) {
            SuspendThread(hThread2);
            mStatus2 = FALSE;
            printf("Suspend Thread 3.\n");
          } else {
            ResumeThread(hThread2);
            mStatus2 = TRUE;
            printf("Resume Thread 3.\n");
          }
        }
      } else if (msg.wParam == k7) {
        // printf("Release skills: accelerate & horse.\n");

        while (1) {
          HDC hdc = GetDC(NULL);
          if (hdc) {
            if (GetPixel(hdc, 233, 137) == 0xFFFFFF &&
                GetPixel(hdc, 240, 131) == 0x222222) {
              // rintf("%s.\n", "Detect Horse");
              _GetHorse(hWnd);
            } else {
              // printf("%s.\n", "Detect not Horse");
              break;
            }
            ReleaseDC(NULL, hdc);
          }
          Sleep(1000);
        }

        _GetStatusAccelerate(hWnd);
        _GetHorse(hWnd);
        //_GetStatusAccelerate(hWnd);

      } else if (msg.wParam == k9) {
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
        Sleep(1000);
        _SendKeyWithAlt(hWnd, KEY_1_SKILL_ACCELERATE);
        Sleep(4000);
      } else if (msg.wParam == k3) {
        _GetStatus(hWnd);
      } else if (msg.wParam == 10) {
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyWithAlt(hWnd, 0x33);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x75);
        Sleep(1000);

      } else if (msg.wParam == k8) {
        ContinuousBroadcast(hWnd, L"");
      } else if (msg.wParam == k5) {
        // _SendKeyBackground(hWnd, KEY_1_SKILL_LIGHT_BOMB);
        // Sleep(1000);
        _SendKeyBackground(hWnd, KEY_1_SKILL_INJECTION_ENERGY);
        Sleep(1000);
        _SendKeyBackground(hWnd, KEY_1_SKILL_EXORCISM);
        Sleep(1000);
      }
    }
  }
  return 0;
}
// gcc -lgdi32  miscellaneous.c -o m && m