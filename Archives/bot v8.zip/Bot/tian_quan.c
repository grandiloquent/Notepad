// -lgdi32

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "key.h"
#include "ffo.h"

#define CAREER_YS
#define APP_HWND 0
#define APP_PID 0

static BOOL mStatus = FALSE;

void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len) {
  if (ReadProcessMemory(hProc, (void*)address, buf, len, NULL) == 0) {
    printf("[Failed]: ReadBuffer\n");
  }
}
void GetHealth(HANDLE hProc, DWORD_PTR hpAddress, HWND hWnd) {
  if (_ReadDword(hProc, hpAddress) < 3000) {
    _SendKeyBackground(hWnd, 0x71);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
  }
}

HWND GetHWND() {
  HWND hWnd;
  if (APP_HWND != 0)
    hWnd = (HWND)APP_HWND;
  else
    hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    printf("[Failed]: GetHWND.\n");
    exit(1);
  }
  return hWnd;
}

DWORD GetPid() {
  DWORD pid;
  if (APP_PID != 0)
    pid = APP_PID;
  else
    pid = _GetProcessIdByName("qqffo.exe");
  if (!pid) {
    printf("Failed get target process id.\n");
    exit(1);
  }
}

HANDLE GetProcess(HANDLE hToken, DWORD pid) {
  if (!_SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    exit(1);
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    exit(1);
  }
  return hTargetProc;
}

void GetStatus(HANDLE hProc, DWORD_PTR maAddress, HWND hWnd) {
  BYTE magicAttackValue[3] = {0x37, 0x32, 0x34};

  BYTE buf[3];
  ReadBuffer(hProc, maAddress, buf, 3);
  // printf("%d %d %d.\n", buf[0], buf[1], buf[2]);
  if (buf[0] == magicAttackValue[0] && buf[1] == magicAttackValue[1] &&
      buf[2] == magicAttackValue[2]) {
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
    _SendKeyWithAlt(hWnd, KEY_1_SKILL_DEFENSE);
    Sleep(3000);
    _SendKeyWithAlt(hWnd, KEY_1_SKILL_BLESSING);
    Sleep(3000);
  }
}

void GetStatusFast(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_DEFENSE);
  Sleep(2000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_BLESSING);
  Sleep(2000);
}

HANDLE GetToken() {
  HANDLE hProc = GetCurrentProcess();
  HANDLE hToken = NULL;
  if (!OpenProcessToken(hProc, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
    printf("Failed to open acess token.\n");
    exit(1);
  }
  return hToken;
}
void ClickMap() {
  _Click(1096, 105);
  Sleep(500);
}

SIZE_T GetHealthAddress(HANDLE hProc) {
  BYTE array[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x50, 0, 0, 0, 0x26, 0, 0, 0, 0x5B};
  SIZE_T objectAddress = _ScanSegments(hProc, array, sizeof(array));
  if (!objectAddress) {
    printf("[Failed]: GetLocationAddress\n");
    exit(1);
  }
  return objectAddress + 0x80;
}
SIZE_T GetLocationAddress(HANDLE hProc, BYTE pattern[], size_t len) {
  SIZE_T objectAddress = _ScanSegments(hProc, pattern, len);
  if (!objectAddress) {
    printf("[Failed]: GetLocationAddress\n");
    exit(1);
  }
  return objectAddress + 0x10;
}
SIZE_T GetStatusAddress(HANDLE hProc) {
  BYTE array[] = {0xFE, 0x72, 0xF1, 0x47, 0x00, 0x00, 0x00, 0x8F, 0x00};
  SIZE_T objectAddress = _ScanSegments(hProc, array, sizeof(array));
  if (!objectAddress) {
    printf("[Failed]: GetStatusAddress\n");
    exit(1);
  }
  return objectAddress + 0x9;
}
/////////////////
void GoLocation(HANDLE hProc, DWORD_PTR address, BYTE value[], size_t pos[]) {
  while (1) {
    BYTE buf1[2];
    ReadBuffer(hProc, address - 0xd0, buf1, 2);
    BYTE buf2[2];
    ReadBuffer(hProc, address - 0xcc, buf2, 2);
    if (buf1[0] == value[0] && buf1[1] == value[1] && buf2[0] == value[2] &&
        buf2[1] == value[3]) {
      break;
    } else {
      ClickMap();
      _ClickRight(pos[0], pos[1]);
      Sleep(500);
      ClickMap();
    }
    Sleep(3000);
  }
}
void GetSpeed(HWND hWnd, BOOL isFast) {
  _SendKeyBackground(hWnd, KEY_1_SKILL_SHIELD);
  Sleep(1000);
  if (isFast) {
    _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
    Sleep(1000);
  } else {
    _SendKeyWithAlt(hWnd, KEY_1_SKILL_FOCUS);
    Sleep(1000);
  }
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_ACCELERATE);
  Sleep(4000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_HORSE);
  Sleep(1000);
}
void HitMonster(HANDLE hProc, DWORD_PTR hpAddress, DWORD_PTR dcAddress,
                DWORD_PTR maAddress, HWND hWnd, BYTE coordinates[],
                size_t pos[], size_t count) {
  GetHealth(hProc, hpAddress, hWnd);
  GetStatus(hProc, maAddress, hWnd);

  GoLocation(hProc, dcAddress, coordinates, pos);

  // 净化
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_PURIFICATION);
  Sleep(1000);
  GetHealth(hProc, hpAddress, hWnd);

  SetCursorPos(608, 384);

  for (int i = 0; i < count; ++i) {
    GetHealth(hProc, hpAddress, hWnd);
    _SendKeyBackground(hWnd, 0x73);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x74);
    Sleep(1000);
    GetHealth(hProc, hpAddress, hWnd);
    _SendKeyBackground(hWnd, 0x75);
    Sleep(1000);
  }
  GetStatusFast(hWnd);
}
void HitSecond(HWND hTargetProc, DWORD_PTR hpAddress, DWORD_PTR dcAddress,
               DWORD_PTR maAddress, HWND hWnd) {
  BYTE coordinates1[] = {0x4D, 0x15, 0x41, 0x01};
  size_t coord1[] = {680, 242};
  HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd, coordinates1,
             coord1, 9);

  // BYTE coordinates2[] = {0x5C, 0x25, 0x38, 0x09};
  // size_t coord2[] = {926, 364};
  // HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd,
  // coordinates2,
  //            coord2, 7);

  _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_ACCELERATE);
  Sleep(4000);

  BYTE coordinates3[] = {0xB2, 0x18, 0x72, 0x11};
  size_t coord3[] = {732, 490};
  HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd, coordinates3,
             coord3, 7);

  BYTE coordinates4[] = {0x1F, 0x0E, 0xB3, 0x0B};
  size_t coord4[] = {570, 402};
  HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd, coordinates4,
             coord4, 7);

  // BYTE coordinates5[] = {0x60, 0x1E, 0x38, 0x09};
  // size_t coord5[] = {819, 364};
  // HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd,
  // coordinates5,
  //            coord5, 7);

  _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_ACCELERATE);
  Sleep(4000);

  BYTE coordinates6[] = {0x79, 0x10, 0x11, 0x0A};
  size_t coord6[] = {606, 377};
  HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd, coordinates6,
             coord6, 7);
}
void HitThird(HWND hTargetProc, DWORD_PTR hpAddress, DWORD_PTR dcAddress,
              DWORD_PTR maAddress, HWND hWnd) {
  BYTE coordinates1[] = {0x5C, 0x22, 0x9C, 0x06};
  size_t coord1[] = {880, 324};
  HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd, coordinates1,
             coord1, 9);

  BYTE coordinates2[] = {0x4E, 0x18, 0xA8, 0x0A};
  size_t coord2[] = {726, 386};
  HitMonster(hTargetProc, hpAddress, dcAddress, maAddress, hWnd, coordinates2,
             coord2, 9);
}
void GoThird(HANDLE hTargetProc, DWORD_PTR dcAddress) {
  BYTE gbk2[] = {0xcc, 0xec, 0xbf, 0xd5, 0xd6, 0xae,
                 0xc8, 0xaa, 0xc8, 0xfd, 0xb2, 0xe3};
  size_t pos[] = {711, 381};
  while (1) {
    BYTE buf1[12];
    ReadBuffer(hTargetProc, dcAddress, buf1, 12);
    if (gbk2[0] == buf1[0] && gbk2[1] == buf1[1] && gbk2[2] == buf1[2] &&
        gbk2[3] == buf1[3] && gbk2[4] == buf1[4] && gbk2[5] == buf1[5] &&
        gbk2[6] == buf1[6] && gbk2[7] == buf1[7] && gbk2[8] == buf1[8] &&
        gbk2[9] == buf1[9] && gbk2[10] == buf1[10] && gbk2[11] == buf1[11]) {
      break;
    } else {
      ClickMap();
      _ClickRight(pos[0], pos[1]);
      Sleep(500);
      ClickMap();
      Sleep(10000);
    }
    Sleep(1000);
  }
}
/////////////////
DWORD WINAPI Strategy(LPVOID lpParam) {
  DWORD pid = GetPid();
  HANDLE hToken = GetToken();
  HANDLE hTargetProc = GetProcess(hToken, pid);
  // // 搜索地图名称在内存中的基础地址
  BYTE loactionPattern[] = {0x71, 0x77, 0x30, 0x30, 0x33, 0x32, 0x00,
                            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                            0x00, 0x00, 0xCC, 0xEC, 0xB6, 0xBC, 0x00};

  // BYTE loactionPattern[] = {0x70, 0x77, 0x32, 0x30, 0x38, 0x30, 0x32, 0x00,
  //                           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  //                           0xCC, 0xEC, 0xBF, 0xD5, 0xD6, 0xAE, 0xC8, 0xAA,
  //                           0xB6, 0xFE, 0xB2, 0xE3, 0x00};
  // 地址
  SIZE_T dcAddress =
      GetLocationAddress(hTargetProc, loactionPattern, sizeof(loactionPattern));
  printf("%s: %x.\n", "Map Name Address", dcAddress);
  SIZE_T hpAddress = GetHealthAddress(hTargetProc);
  printf("%s: %x.\n", "Health Value Address", hpAddress);
  SIZE_T maAddress = GetStatusAddress(hTargetProc);
  printf("%s: %x.\n", "Magic Value Address", maAddress);
  HWND hWnd = GetHWND();

  GetSpeed(hWnd, TRUE);

  // 寻址杨戬二郎神
  BYTE p1[] = {0x62, 0x32, 0x19, 0x12};
  size_t pos1[] = {858, 400};
  GoLocation(hTargetProc, dcAddress, p1, pos1);

  // 对话杨戬二郎神
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 233) == 0xFFFFFF &&
          GetPixel(hdc, 658, 272) == 0xFFFFFF) {
        break;
      } else {
        _Click(694, 333);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  // 进入天空之泉

  _Click(545, 399);
  Sleep(1000);

  //下马
  _SendKeyBackground(hWnd, KEY_1_SKILL_SHIELD);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_HORSE);
  Sleep(1000);

  // 加速
  GetSpeed(hWnd, FALSE);

  // 进入天空之泉二层
  BYTE gbk2[] = {0xcc, 0xec, 0xbf, 0xd5, 0xd6, 0xae,
                 0xc8, 0xaa, 0xb6, 0xfe, 0xb2, 0xe3};

  while (1) {
    BYTE buf1[12];
    ReadBuffer(hTargetProc, dcAddress, buf1, 12);
    if (gbk2[0] == buf1[0] && gbk2[1] == buf1[1] && gbk2[2] == buf1[2] &&
        gbk2[3] == buf1[3] && gbk2[4] == buf1[4] && gbk2[5] == buf1[5] &&
        gbk2[6] == buf1[6] && gbk2[7] == buf1[7] && gbk2[8] == buf1[8] &&
        gbk2[9] == buf1[9] && gbk2[10] == buf1[10] && gbk2[11] == buf1[11]) {
      break;
    } else {
      ClickMap();
      _ClickRight(529, 438);
      Sleep(500);
      ClickMap();
      Sleep(10000);
    }
    Sleep(1000);
  }

  // 净化
  _SendKeyBackground(hWnd, 0x71);
  Sleep(3000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_HORSE);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_PURIFICATION);
  Sleep(1000);
  _GetStatus(hWnd);

  // 加血
  if (_ReadDword(hTargetProc, hpAddress) < 3000) {
    _SendKeyBackground(hWnd, 0x71);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
  }

  HitSecond(hTargetProc, hpAddress, dcAddress, maAddress, hWnd);
  GoThird(hTargetProc, dcAddress);
  HitThird(hTargetProc, hpAddress, dcAddress, maAddress, hWnd);

  return 0;
}

int main(int argc, char* argv[]) {
  int k1 = 1;

  if (RegisterHotKey(NULL, k1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  } else {
    printf("[Failed]: Register Hotkey [Ctrl+1].\n");
    exit(1);
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        // size_t pos[] = {726, 386};
        // ClickMap();
        // _ClickRight(pos[0], pos[1]);
        // Sleep(500);
        // ClickMap();
        // return 0;

        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, NULL, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }

  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
