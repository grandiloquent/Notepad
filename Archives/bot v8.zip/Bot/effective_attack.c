// -lgdi32

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "key.h"
#include "ffo.h"

#define POS_AUTO_LEFT_X 404
#define POS_AUTO_LEFT_Y 378
#define POS_AUTO_RIGHT_X 954

#define APP_HWND 0
#define APP_PID 0

static BOOL mStatus = FALSE;

DWORD GetPid() {
  DWORD pid;
  if (APP_PID != 0)
    pid = APP_PID;
  else
    pid = _GetProcessIdByName("qqffo.exe");
  if (!pid) {
    printf("Failed get target process id.\n");
    exit(1);
  }
}
HANDLE GetToken() {
  HANDLE hProc = GetCurrentProcess();
  HANDLE hToken = NULL;
  if (!OpenProcessToken(hProc, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
    printf("Failed to open acess token.\n");
    exit(1);
  }
  return hToken;
}
HANDLE GetProcess(HANDLE hToken, DWORD pid) {
  if (!_SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    exit(1);
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    exit(1);
  }
  return hTargetProc;
}
void ReadBuffer(HANDLE hProc, DWORD_PTR address, BYTE buf[], size_t len) {
  if (ReadProcessMemory(hProc, (void*)address, buf, len, NULL) == 0) {
    printf("[Failed]: ReadBuffer\n");
  }
}
HWND GetHWND() {
  HWND hWnd;
  if (APP_HWND != 0)
    hWnd = (HWND)APP_HWND;
  else
    hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    printf("[Failed]: GetHWND.\n");
    exit(1);
  }
  return hWnd;
}
void GetStatus(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x72);
  Sleep(500);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
  Sleep(500);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_DEFENSE);
  Sleep(500);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_INSTANTS);
  Sleep(500);
  _SendKeyWithAlt(hWnd, KEY_1_SKILL_BLESSING);
  Sleep(500);
}
void GetHealth(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  DWORD pid = GetPid();
  HANDLE hToken = GetToken();
  HANDLE hTargetProc = GetProcess(hToken, pid);

  BYTE array[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x50, 0, 0, 0, 0x26, 0, 0, 0, 0x5B};
  SIZE_T objectAddress = _ScanSegments(hTargetProc, array, sizeof(array));

  // 血量值
  SIZE_T HEALTH_VALUE = 3000;
  SIZE_T hpAddress = objectAddress + 0x80;
  printf("Health Value: %x.\n", hpAddress);

  // 魔攻值
  BYTE arrayMagic[] = {0xB5, 0x59, 0x98, 0x68, 0x04, 0x50, 0x8F, 0x00,
                       0x28, 0x00, 0x23, 0x28, 0x28, 0xA2, 0xD6, 0x1C};
  objectAddress = _ScanSegments(hTargetProc, arrayMagic, sizeof(arrayMagic));

  SIZE_T maAddress = objectAddress + 0x2a0;
  BYTE MAGIC_ATTACK_VALUE[2] = {0x89, 0x02};
  printf("Magic Attack Value: %x.\n", maAddress);

  HWND hWnd = GetHWND();

  if (!hpAddress || !maAddress) {
    return 0;
  }
  int count = 0;
  while (1) {
    count++;

    DWORD result = _ReadDword(hTargetProc, hpAddress);
    if (result < 3000) {
      GetHealth(hWnd);
    } else {
      if (count % 30 == 0) {
        _SendKeyBackground(hWnd, 0x73);
        Sleep(500);
      }
      if (count % 4 == 0) {
        _SendKeyBackground(hWnd, 0x74);
        Sleep(500);
      }
      if (count % 15 == 0) {
        _SendKeyBackground(hWnd, 0x75);
        Sleep(500);
      }
      // _SendKeyBackground(hWnd, 0x75);
      // Sleep(1000);

      if (count > 10) {
        count = 0;
        BYTE buf[2];
        ReadBuffer(hTargetProc, maAddress, buf, 2);
        printf("%x %x.\n",buf[0],buf[1]);
        // printf("%d %d %d.\n", buf[0], buf[1], buf[2]);
        if (buf[0] == MAGIC_ATTACK_VALUE[0] &&
            buf[1] == MAGIC_ATTACK_VALUE[1]) {
          GetStatus(hWnd);
        }
      }
    }

    Sleep(1000);
  }
  return 0;
}
int main(int argc, char* argv[]) {
  int k1 = 1;

  if (RegisterHotKey(NULL, k1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  } else {
    printf("[Failed]: Register Hotkey [Ctrl+1].\n");
    exit(1);
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        // HWND hWnd = GetHWND();
        // while (1) {
        //   _SendKeyBackground(hWnd, 0x9);
        //   Sleep(1000);
        // }
        // return 0;
        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, NULL, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }

  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
// gcc in-bot.c -o m && m