#ifndef KEY_H
#define KEY_H

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>

#define SCREEN_WIDTH 1366
#define SCREEN_HEIGHT 768

typedef struct {
  BYTE r;
  BYTE g;
  BYTE b;
} tagColor, Color;

char *_GetPixelUnderMouse();
void _Click(int x, int y);
void _ClickDouble(int x, int y);
void _ClickRight(int x, int y);
void _ClipboardSetText(const char *c);
DWORD _GetProcessIdByName(const char *processName);
SIZE_T _IsArrayMatch(HANDLE proc, SIZE_T address, SIZE_T segmentSize,
                     BYTE array[], SIZE_T arraySize);
void _MouseClick(int x, int y, BOOL isRightButton, BOOL isDoubleClick);
void _PixelColor(Color *color, int x, int y);
void _PixelSearchColor(POINT *p, int left, int top, int right, int bottom,
                       BYTE r, BYTE g, BYTE b);
void _PrintMousePosition();
void _PrintPixelColor(int x, int y);
DWORD _ReadDword(HANDLE hProc, DWORD_PTR address);
SIZE_T _ScanSegments(HANDLE proc, BYTE array[], SIZE_T size);
void _SendKeyBackground(HWND hWnd, WORD wVk);
void _SendKeyWithAlt(HWND hWnd, UINT vk);
void _SendUnicodeChar(wchar_t ch);
void _SendUnicodeCharBackground(HWND hWnd, const wchar_t *buf);
BOOL _SetPrivilege(HANDLE hToken, LPCTSTR lpszPrivilege, BOOL bEnablePrivilege);

char *_GetPixelUnderMouse() {
  POINT point;
  if (GetCursorPos(&point)) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      COLORREF cr = GetPixel(hdc, point.x, point.y);
      char *buf = malloc(sizeof(char) * 1024);
      sprintf(
          buf,
          "%d,%d\nint x=%d;\nint y=%d;\nBYTE r=%d;\nBYTE g=%d;\n BYTE b=%d;",
          point.x, point.y, point.x, point.y, GetRValue(cr), GetGValue(cr),
          GetBValue(cr));
      ReleaseDC(NULL, hdc);
      return buf;
    }
  }
  return NULL;
}

void _Click(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
  mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}

void _ClickDouble(int x, int y) {
  _Click(x, y);
  Sleep(50);
  _Click(x, y);
}

void _ClickRight(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
  mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
}

void _ClipboardSetText(const char *c) {
  if (OpenClipboard(NULL)) {
    const size_t len = strlen(c) + 1;
    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len);
    memcpy(GlobalLock(hMem), c, len);
    GlobalUnlock(hMem);
    EmptyClipboard();
    SetClipboardData(CF_TEXT, hMem);
    CloseClipboard();
  }
}

DWORD _GetProcessIdByName(const char *processName) {
  HANDLE hPs;
  DWORD result = 0;
  hPs = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (hPs == INVALID_HANDLE_VALUE) {
    return result;
  }
  PROCESSENTRY32 pe32;
  pe32.dwSize = sizeof(PROCESSENTRY32);
  if (!Process32First(hPs, &pe32)) {
    return result;
  }
  do {
    if (strcmp(pe32.szExeFile, processName) == 0) result = pe32.th32ProcessID;
  } while (Process32Next(hPs, &pe32));
  CloseHandle(hPs);
  return result;
}
SIZE_T _IsArrayMatch(HANDLE proc, SIZE_T address, SIZE_T segmentSize,
                     BYTE array[], SIZE_T arraySize) {
  BYTE *procArray = malloc(segmentSize * sizeof(BYTE));
  if (ReadProcessMemory(proc, (void *)address, procArray, segmentSize, NULL) ==
      0) {
    printf("Failed to read memory: %u.\n", GetLastError());
    free(procArray);
    return 0;
  }
  for (SIZE_T i = 0; i < segmentSize; ++i) {
    if ((array[0] == procArray[i]) && ((i + arraySize) < segmentSize)) {
      if (!memcmp(array, procArray + i, arraySize)) {
        free(procArray);
        return address + i;
      }
    }
  }
  free(procArray);
  return 0;
}

void _MouseClick(int x, int y, BOOL isRightButton, BOOL isDoubleClick) {
  INPUT buffer[1];
  buffer->type = INPUT_MOUSE;
  buffer->mi.dx = (0 * (0xFFFF / SCREEN_WIDTH));
  buffer->mi.dy = (0 * (0xFFFF / SCREEN_HEIGHT));
  buffer->mi.mouseData = 0;
  buffer->mi.dwFlags = MOUSEEVENTF_ABSOLUTE;
  buffer->mi.time = 0;
  buffer->mi.dwExtraInfo = 0;
  buffer->mi.dx = (x * (0xFFFF / SCREEN_WIDTH));
  buffer->mi.dy = (y * (0xFFFF / SCREEN_HEIGHT));
  buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE);
  SendInput(1, buffer, sizeof(INPUT));
  // Click
  if (isRightButton)
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTDOWN);
  else
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN);
  SendInput(1, buffer, sizeof(INPUT));
  Sleep(10);
  if (isRightButton)
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTUP);
  else
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP);
  SendInput(1, buffer, sizeof(INPUT));
  Sleep(10);
  if (isDoubleClick) {
    // Click
    if (isRightButton)
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTDOWN);
    else
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN);
    SendInput(1, buffer, sizeof(INPUT));
    Sleep(10);
    if (isRightButton)
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTUP);
    else
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP);
    SendInput(1, buffer, sizeof(INPUT));
  }
}

void _PixelColor(Color *color, int x, int y) {
  HDC hdc = GetDC(NULL);
  if (!hdc) {
    printf("Can't get dc");
    return;
  }
  COLORREF c = GetPixel(hdc, x, y);
  color->r = GetRValue(c);
  color->g = GetGValue(c);
  color->b = GetBValue(c);
  ReleaseDC(NULL, hdc);
}

void _PixelSearchColor(POINT *p, int left, int top, int right, int bottom,
                       BYTE r, BYTE g, BYTE b) {
  //
  HDC hdc = GetDC(NULL);
  if (!hdc) {
    printf("Can't get dc");
    return;
  }
  for (int x = left; x <= right; x++) {
    for (int y = top; y <= bottom; y++) {
      COLORREF c = GetPixel(hdc, x, y);
      if (GetRValue(c) == r && GetGValue(c) == g && GetBValue(c) == b) {
        p->x = x;
        p->y = y;
        return;
      }
    }
  }
  ReleaseDC(NULL, hdc);
}

void _PrintMousePosition() {
  POINT point;
  if (GetCursorPos(&point)) {
    char buf[50];
    sprintf(buf, "%d,%d", point.x, point.y);
    _ClipboardSetText(buf);
  }
}

void _PrintPixelColor(int x, int y) {
  HDC hdc = GetDC(NULL);
  if (hdc) {
    COLORREF cr = GetPixel(hdc, x, y);
    printf("x: %d,y: %d: 0x%x\n", x, y, cr);
    ReleaseDC(NULL, hdc);
  }
}

DWORD _ReadDword(HANDLE hProc, DWORD_PTR address) {
  DWORD result = 0;
  if (ReadProcessMemory(hProc, (void *)address, &result, sizeof(result),
                        NULL) == 0) {
    printf("Failed to read memory: %u.\n", GetLastError());
  }
  return result;
}

SIZE_T _ScanSegments(HANDLE proc, BYTE array[], SIZE_T size) {
  MEMORY_BASIC_INFORMATION meminfo;
  LPCVOID addr = 0;
  SIZE_T result = 0;
  if (!proc) return 0;
  while (1) {
    if (VirtualQueryEx(proc, addr, &meminfo, sizeof(meminfo)) == 0) break;
    if ((meminfo.State & MEM_COMMIT) && (meminfo.Type & MEM_PRIVATE) &&
        (meminfo.Protect & PAGE_READWRITE) && !(meminfo.Protect & PAGE_GUARD)) {
      result = _IsArrayMatch(proc, (SIZE_T)meminfo.BaseAddress,
                            meminfo.RegionSize, array, size);
      if (result != 0) return result;
    }
    addr = (unsigned char *)meminfo.BaseAddress + meminfo.RegionSize;
  }
  return 0;
}

void _SendKeyBackground(HWND hWnd, WORD wVk) {
  PostMessageW(hWnd, WM_KEYDOWN, wVk, 0);
  Sleep(100);
  PostMessageW(hWnd, WM_KEYUP, wVk, 0);
}

void _SendKeyWithAlt(HWND hWnd, UINT vk) {
  PostMessage(hWnd, WM_SYSKEYDOWN, 0x12, 0x60380001);
  Sleep(10);
  PostMessage(hWnd, WM_SYSKEYUP, 0x12, 0xC0380001);
  Sleep(10);
  // PostMessage(hWnd, WM_SYSKEYDOWN, 0x12, 0x60380001);
  // Sleep(10);
  PostMessage(hWnd, WM_SYSKEYDOWN, vk, 0);
  Sleep(10);
  PostMessage(hWnd, WM_SYSKEYUP, vk, 0);
  Sleep(10);
  // PostMessage(hWnd, WM_KEYUP, 0x12, 0);
}

void _SendUnicodeChar(wchar_t ch) {
  INPUT input[2];
  input[0].type = INPUT_KEYBOARD;
  input[0].ki.wVk = 0;
  input[0].ki.wScan = ch;
  input[0].ki.dwFlags = KEYEVENTF_UNICODE;
  input[0].ki.time = 0;
  input[0].ki.dwExtraInfo = 0;
  input[1].type = INPUT_KEYBOARD;
  input[1].ki.wVk = 0;
  input[1].ki.wScan = ch;
  input[1].ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
  input[1].ki.time = 0;
  input[0].ki.dwExtraInfo = 0;
  SendInput(2, input, sizeof(INPUT));
}

void _SendUnicodeCharBackground(HWND hWnd, const wchar_t *buf) {
  const wchar_t *tmp = buf;
  while (*tmp) {
    wchar_t ch = *tmp;
    PostMessageW(hWnd, WM_CHAR, ch, 0);
    tmp++;
  }
}

BOOL _SetPrivilege(HANDLE hToken, LPCTSTR lpszPrivilege,
                   BOOL bEnablePrivilege) {
  TOKEN_PRIVILEGES tp;
  LUID luid;
  if (!LookupPrivilegeValue(NULL, lpszPrivilege, &luid)) {
    printf("LookupPrivilegeValue error: %u\n", GetLastError());
    return FALSE;
  }
  tp.PrivilegeCount = 1;
  tp.Privileges[0].Luid = luid;
  if (bEnablePrivilege) {
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
  } else {
    tp.Privileges[0].Attributes = 0;
  }
  if (!AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(TOKEN_PRIVILEGES),
                             (PTOKEN_PRIVILEGES)NULL, (PDWORD)NULL)) {
    printf("AdjustTokenPrivileges error: %u.\n", GetLastError());
    return FALSE;
  }
  if (GetLastError() == ERROR_NOT_ALL_ASSIGNED) {
    printf("The token does not have the specified privilege.\n");
    return FALSE;
  }
  return TRUE;
}
#endif  // KEY_H
