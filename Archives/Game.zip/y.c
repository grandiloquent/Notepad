#include <Windows.h>
#include <stdio.h>
typedef enum { KEYDOWN, KEYUP, KEYDOWNANDUP } KeyEventTypes;

void KeyEvent(KeyEventTypes aEventType, UCHAR aVK, USHORT aSC,
              HWND aTargetWindow, BOOL aDoKeyDelay) {
  BYTE state[256];
  GetKeyboardState((PBYTE)&state);
  if (aEventType == KEYDOWN)
    state[aVK] |= 0x80;
  else if (aEventType == KEYUP)
    state[aVK] &= ~0x80;
  switch (aVK) {
    case VK_LCONTROL:
    case VK_RCONTROL:
      if ((state[VK_LCONTROL] & 0x80) || (state[VK_RCONTROL] & 0x80))
        state[VK_CONTROL] |= 0x80;
      else
        state[VK_CONTROL] &= ~0x80;
      break;
    case VK_LSHIFT:
    case VK_RSHIFT:
      if ((state[VK_LSHIFT] & 0x80) || (state[VK_RSHIFT] & 0x80))
        state[VK_SHIFT] |= 0x80;
      else
        state[VK_SHIFT] &= ~0x80;
      break;
    case VK_LMENU:
    case VK_RMENU:
      if ((state[VK_LMENU] & 0x80) || (state[VK_RMENU] & 0x80))
        state[VK_MENU] |= 0x80;
      else
        state[VK_MENU] &= ~0x80;
      break;
  }

  SetKeyboardState((PBYTE)&state);

  // lowest 16 bits: repeat count: always 1 for up events, probably 1 for down
  // in our case. highest order bits: 11000000 (0xC0) for keyup, usually
  // 00000000 (0x00) for keydown.
  LPARAM lParam = (LPARAM)(aSC << 16);
  if (aEventType != KEYUP)  // i.e. always do it for KEYDOWNANDUP
    PostMessage(aTargetWindow, WM_KEYDOWN, aVK, lParam | 0x00000001);
  // The press-duration delay is done only when this is a down-and-up because
  // otherwise, the normal g->KeyDelay will be in effect.  In other words, it
  // seems undesirable in most cases to do both delays for only "one half" of a
  // keystroke:
  if (aDoKeyDelay && aEventType == KEYDOWNANDUP)
    Sleep(10);                // Since aTargetWindow!=NULL,
                              // sSendMode!=SM_PLAY, so no need for to ever
                              // use the SendPlay press-duration.
  if (aEventType != KEYDOWN)  // i.e. always do it for KEYDOWNANDUP
    PostMessage(aTargetWindow, WM_KEYUP, aVK, lParam | 0xC0000001);
}
int main(int argc, char* argv[]) {
  HWND hWnd = (HWND)0x004C0020;
  if (!hWnd) {
    printf("%s.\n", "Failed");
    return 0;
  } else {
  }
  KeyEvent(KEYUP, VK_LMENU, 0, NULL, FALSE);
  KeyEvent(KEYDOWNANDUP, 0x57, 0, hWnd, FALSE);
  KeyEvent(KEYDOWN, VK_LMENU, 0, NULL, FALSE);
}