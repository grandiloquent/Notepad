// -lgdi32

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "key.h"

BOOL GetMainThreadTeb(DWORD dwPid, PTEB pTeb) {
  LPVOID tebAddress = NtCurrentTeb();
  printf("TEB = %p\n", tebAddress);
  HANDLE hProcess = OpenProcess(PROCESS_VM_READ, FALSE, dwPid);
  if (hProcess == NULL) {
    return FALSE;
  }
  if (ReadProcessMemory(hProcess, tebAddress, pTeb, sizeof(TEB), NULL) ==
      FALSE) {
    CloseHandle(hProcess);
    return FALSE;
  }
  CloseHandle(hProcess);
  return TRUE;
}

int main(int argc, char* argv[]) {
  DWORD pid = _GetProcessIdByName("qqffo.exe");
  if (!pid) {
    printf("Failed get target process id.\n");
    return 1;
  }
  HANDLE hProc = GetCurrentProcess();
  HANDLE hToken = NULL;
  if (!OpenProcessToken(hProc, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
    printf("Failed to open acess token.\n");
    return 1;
  }
  if (!_SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    return 1;
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    return 1;
  }
  BYTE array[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x50, 0, 0, 0, 0x26, 0, 0, 0, 0x5B};
  SIZE_T objectAddress = _ScanSegments(hTargetProc, array, sizeof(array));
  SIZE_T hpAddress = objectAddress + 0x80;

  printf("Find Memory %x.\n", hpAddress);
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }
  if (!hpAddress) {
    return 0;
  }

  while (1) {
    DWORD result = _ReadDword(hTargetProc, hpAddress);
    if (result < 1700) {
      _SendKeyBackground(hWnd, 0x71);
      Sleep(1000);
      _SendKeyBackground(hWnd, 0x72);

    } else {
      _SendKeyBackground(hWnd, 0x74);
    }

    Sleep(2000);
  }
  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
// gcc in-bot.c -o m && m