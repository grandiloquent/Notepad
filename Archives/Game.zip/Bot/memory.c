// -lgdi32

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "key.h"
#include "ffo.h"

#define APP_HWND 0
#define APP_PID 0

static BOOL mStatus = FALSE;

int main(int argc, char *argv[]) {
  int k1 = 1;

  if (RegisterHotKey(NULL, k1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        DWORD pid;
        if (APP_PID != 0)
          pid = APP_PID;
        else
          pid = _GetProcessIdByName("qqffo.exe");
        if (!pid) {
          printf("Failed get target process id.\n");
          return 1;
        }
        HANDLE hProc = GetCurrentProcess();
        HANDLE hToken = NULL;
        if (!OpenProcessToken(hProc, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
          printf("Failed to open acess token.\n");
          return 1;
        }
        if (!_SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
          printf("Failed to set debug privilege.\n");
          return 1;
        }
        HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
        if (!hTargetProc) {
          printf("Failed to open process: %u.\n", GetLastError());
          return 1;
        }
        size_t segmentSize = 255;
        int address = 0x16DD9D81;//0x08BEAEC0;
        BYTE *procArray = malloc(segmentSize * sizeof(BYTE));
        memset(procArray, 0, segmentSize);
        if (ReadProcessMemory(hTargetProc, (void *)address, procArray,
                              segmentSize, NULL) == 0) {
          printf("Failed to read memory: %u.\n", GetLastError());
          for (int i = 0; i < segmentSize; ++i) {
            printf("%d.\n", procArray[i]);
          }
          free(procArray);
          return 0;
        } else {
          for (int i = 0; i < segmentSize; ++i) {
            printf("%d.\n", procArray[i]);
          }
          free(procArray);
        }

        // DWORD result = _ReadDword(hTargetProc, 146714224);
      }
    }
  }

  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
// gcc in-bot.c -o m && m