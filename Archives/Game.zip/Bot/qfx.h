#ifndef QFX_H
#define QFX_H

#include <Windows.h>
#include "key.h"

void AskFamilyHonorMission(HWND hWnd);
void BackFamilyPriest(HWND hWnd);
void CloseMap();
void CompleteFamilyHonorMission();
void CompleteHonorMission(HWND hWnd);
void OpenMap();
void OpenMapMenu();
void LaunchAssistiveSkills(HWND hWnd);

void LaunchAssistiveSkills(HWND hWnd) {
  Sleep(1000);
  // 防御术 0 2
  _SendKeyWithAlt(hWnd, 0x36);
  Sleep(2500);
  // 祝福术 0 2.5
  _SendKeyWithAlt(hWnd, 0x37);
  Sleep(2500);
}
void AskFamilyHonorMission(HWND hWnd) {
  //   //点击家族祭祀
  //   _ClickRight(1138, 68);
  //   Sleep(1000);
  //   int coordinates3[2][3] = {{647, 256, 0X00FF00}, {647, 257, 0X000000}};
  //   while (1) {
  //     HDC hdc = GetDC(NULL);
  //     if (hdc) {
  //       // printf("%x\n",GetPixel(hdc, coordinates2[0][0],
  //       coordinates2[0][1]));
  //       // 0xbbggrr
  //       if (coordinates3[0][2] ==
  //               GetPixel(hdc, coordinates3[0][0], coordinates3[0][1]) &&
  //           coordinates3[1][2] ==
  //               GetPixel(hdc, coordinates3[1][0], coordinates3[1][1])) {
  //         break;
  //       }
  //       ReleaseDC(NULL, hdc);
  //     }
  //     Sleep(1000);
  //   }
  // 点击家族祭司
  _Click(657, 311);
  Sleep(1000);
  _Click(602, 419);
  Sleep(1000);
  _Click(618, 367);
  Sleep(1000);
  _ClickRight(1056, 122);
  Sleep(1000);
}
void BackFamilyPriest(HWND hWnd) {
  // 回主城
  _Click(669, 676);
  Sleep(50);
  _Click(669, 676);
  Sleep(1000);
  // 隐藏其他玩家
  _SendKeyBackground(hWnd, 0x7A);
  Sleep(1000);
  // 隐藏其他玩家
  _SendKeyBackground(hWnd, 0x7A);
  Sleep(1000);
  // 打开地图
  _Click(1102, 103);
  Sleep(1000);
  // 标记地图
  _ClickRight(683, 330);
  Sleep(1000);
  // 关闭地图
  _Click(1102, 103);
  Sleep(1000);
  // 坐标是相对于坐标的
  int coordinates2[2][3] = {{653, 270, 0X00FF00}, {654, 271, 0X000000}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // printf("%x\n",GetPixel(hdc, coordinates2[0][0], coordinates2[0][1]));
      // 0xbbggrr
      if (coordinates2[0][2] ==
              GetPixel(hdc, coordinates2[0][0], coordinates2[0][1]) &&
          coordinates2[1][2] ==
              GetPixel(hdc, coordinates2[1][0], coordinates2[1][1])) {
        // 点击自动寻路图标
        _Click(664, 352);
        Sleep(1000);
        // 点击 NPC
        _Click(596, 204);
        Sleep(1000);
        // 关于家族屋
        _Click(583, 420);
        Sleep(1000);
        //进入家族前院
        _Click(576, 364);
        Sleep(2000);
        //点击家族祭祀
        _ClickRight(1138, 68);
        Sleep(1000);
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void CloseMap() {
  // 关闭地图
  _Click(1102, 103);
  Sleep(1000);
}
void CompleteFamilyHonorMission() {
  // 完成荣誉任务
  _Click(620, 420);
  Sleep(1000);
  _Click(622, 366);
  Sleep(1000);
}
void CompleteHonorMission(HWND hWnd) {
  BackFamilyPriest(hWnd);
  int coordinates3[2][3] = {{647, 256, 0X00FF00}, {647, 257, 0X000000}};
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // printf("%x\n",GetPixel(hdc, coordinates2[0][0], coordinates2[0][1]));
      // 0xbbggrr
      if (coordinates3[0][2] ==
              GetPixel(hdc, coordinates3[0][0], coordinates3[0][1]) &&
          coordinates3[1][2] ==
              GetPixel(hdc, coordinates3[1][0], coordinates3[1][1])) {
        // 点击NPC
        _Click(660, 325);
        Sleep(1000);
        CompleteFamilyHonorMission();
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void OpenMap() {
  // 打开地图
  _Click(1102, 103);
  Sleep(1000);
}
void OpenMapMenu() {
  // 点击自动寻路图标
  _Click(1121, 171);
  Sleep(1000);
  // 点击地图菜单项
  _Click(1064, 216);
  Sleep(1000);
}
#endif  // KEY_H