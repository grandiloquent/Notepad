// -lgdi32

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "key.h"
#include "ffo.h"

#define POS_MAP_MENU_DRAGON_CITY_X 884
#define POS_MAP_MENU_DRAGON_CITY_Y 220
#define POS_MAP_MENU_X 1121
#define POS_MAP_MENU_Y 172
#define POS_MAP_NPC_X 1067
#define POS_MAP_NPC_Y 174
#define POS_TRANSMITTER_USE_X 520
#define POS_TRANSMITTER_USE_Y 367
#define POS_TRANSMITTER_HUASHAN_X 523
#define POS_TRANSMITTER_HUASHAN_Y 267
#define POS_TRANSMITTER_OK_X 450
#define POS_TRANSMITTER_OK_Y 468
#define POS_MENU_MOYU_X 872
#define POS_MENU_MOYU_Y 178
#define POS_MOYU_USE_X 562
#define POS_MOYU_USE_Y 367
#define POS_L1_X 687
#define POS_L1_Y 290

static BOOL mStatus = FALSE;
void Attack(HWND hWnd);
HWND GetGameHandle();
void GoHuashan();
void GoLocation1(HWND hWnd);
void GoLocation2(HWND hWnd);
void GoLocation3(HWND hWnd);
void GoLocation4(HWND hWnd);
void GoMoyu();
void GoTransmitter();
void HitBoss(HWND hWnd, int array[][3], size_t len);
SIZE_T
SearchHealthAddress();
DWORD WINAPI Strategy(LPVOID lpParam);

SIZE_T
SearchHealthAddress() {
  DWORD pid = _GetProcessIdByName("qqffo.exe");
  if (!pid) {
    printf("Failed get target process id.\n");
    return 0;
  }
  HANDLE hProc = GetCurrentProcess();
  HANDLE hToken = NULL;
  if (!OpenProcessToken(hProc, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
    printf("Failed to open acess token.\n");
    return 0;
  }
  if (!_SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    return 0;
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    return 0;
  }
  BYTE array[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x50, 0, 0, 0, 0x26, 0, 0, 0, 0x5B};
  SIZE_T objectAddress = _ScanSegments(hTargetProc, array, sizeof(array));
  SIZE_T hpAddress = objectAddress + 0x80;
  return hpAddress;
}

void Attack(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x70);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x74);
  Sleep(3500);
}

HWND GetGameHandle() {
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }
  return hWnd;
}

void GoHuashan() {
  _Click(POS_TRANSMITTER_USE_X, POS_TRANSMITTER_USE_Y);
  Sleep(1000);
  _Click(POS_TRANSMITTER_HUASHAN_X, POS_TRANSMITTER_HUASHAN_Y);
  Sleep(1000);
  _Click(POS_TRANSMITTER_OK_X, POS_TRANSMITTER_OK_Y);
  Sleep(2000);
}

void GoLocation1(HWND hWnd) {
  _GetStatus(hWnd);
  //_GetStatusAccelerate(hWnd);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1090, 46) == 0xFFFFFF &&
          GetPixel(hdc, 1093, 51) == 0x426192 &&
          GetPixel(hdc, 1105, 52) == 0xFFFFFF &&
          GetPixel(hdc, 1113, 46) == 0xFFFFFF &&
          GetPixel(hdc, 1121, 52) == 0xFFFFFF) {
        break;
      }
      _Click(1106, 108);
      Sleep(1000);
      _ClickRight(POS_L1_X, POS_L1_Y);
      Sleep(1000);
      _Click(1106, 108);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
  _SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  SetCursorPos(650, 379);
  for (int i = 0; i < 7; ++i) {
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x74);
    Sleep(3500);
  }
  _Click(650, 379);
  Sleep(1000);
  int array[][3] = {{460, 30, 0xB3B3BD}, {427, 24, 0xB3B3BD}};
  HitBoss(hWnd, array, 2);
}

void GoLocation2(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1090, 46) == 0xFFFFFF &&
          GetPixel(hdc, 1099, 45) == 0xFFFFFF &&
          GetPixel(hdc, 1122, 48) == 0xFFFFFF &&
          GetPixel(hdc, 1119, 45) == 0x3C6A97) {
        break;
      }
      _Click(1106, 108);
      Sleep(1000);
      _ClickRight(703, 435);
      Sleep(1000);
      _Click(1106, 108);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  SetCursorPos(740, 324);
  for (int i = 0; i < 5; ++i) {
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x74);
    Sleep(3500);
  }
}

void GoLocation3(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1087, 46) == 0xFFFFFF &&
          GetPixel(hdc, 1095, 45) == 0xFFFFFF &&
          GetPixel(hdc, 1120, 48) == 0x465F7E) {
        break;
      }
      _Click(1106, 108);
      Sleep(1000);
      _ClickRight(675, 528);
      Sleep(1000);
      _Click(1106, 108);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
  _Click(650, 379);
  Sleep(1000);
  int count = 0;
  while (1) {
    HDC hdc = GetDC(NULL);
    count++;
    if (hdc) {
      if (GetPixel(hdc, 402, 25) == 0xB3B3BD &&
          GetPixel(hdc, 466, 34) == 0xB3B3BD &&
          GetPixel(hdc, 480, 25) == 0xB3B3BD) {
        _SendKeyBackground(hWnd, 0x70);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x74);
        Sleep(3500);
      } else {
        _SendKeyBackground(hWnd, 0x9);
        Sleep(1000);
        if (count > 3) {
          break;
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}

void GoLocation4(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1091, 44) == 0x0F1212 &&
          GetPixel(hdc, 1098, 45) == 0xFFFFFF &&
          GetPixel(hdc, 1123, 51) == 0xFFFFFF) {
        break;
      }
      _Click(1106, 108);
      Sleep(1000);
      _ClickRight(681, 358);
      Sleep(1000);
      _Click(1106, 108);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
  SetCursorPos(683, 415);
  for (int i = 0; i < 5; ++i) {
    _SendKeyBackground(hWnd, 0x72);
    Sleep(1000);
    _SendKeyBackground(hWnd, 0x74);
    Sleep(3500);
  }
  _Click(650, 379);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x9);
  Sleep(1000);
  int count = 0;
  while (1) {
    count++;
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 484, 26) == 0xB3B3BD &&
          GetPixel(hdc, 454, 28) == 0xB3B3BD) {
        _SendKeyBackground(hWnd, 0x70);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x74);
        Sleep(3500);
      } else {
        _SendKeyBackground(hWnd, 0x9);
        Sleep(1000);
        if (count > 3) {
          break;
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}

void GoMoyu() {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 231) == 0xFFFFFF &&
          GetPixel(hdc, 862, 258) == 0xFFFFFF) {
        break;
      }
      _Click(POS_MAP_MENU_X, POS_MAP_MENU_Y);
      Sleep(1000);
      _Click(POS_MAP_NPC_X, POS_MAP_NPC_Y);
      Sleep(1000);
      _Click(POS_MENU_MOYU_X, POS_MENU_MOYU_Y);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
  _Click(POS_MOYU_USE_X, POS_MOYU_USE_Y);
  Sleep(2000);
}
void GoTransmitter() {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 498, 424) == 0xFFFFFF &&
          GetPixel(hdc, 831, 258) == 0xFFFFFF) {
        break;
      }
      _Click(POS_MAP_MENU_X, POS_MAP_MENU_Y);
      Sleep(1000);
      _Click(POS_MAP_NPC_X, POS_MAP_NPC_Y);
      Sleep(1000);
      _Click(POS_MAP_MENU_DRAGON_CITY_X, POS_MAP_MENU_DRAGON_CITY_Y);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(2000);
  }
}
void GobackDragonCity(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1098, 7) == 0x10CFFF &&
          GetPixel(hdc, 1111, 5) == 0x10CFFF &&
          GetPixel(hdc, 1106, 10) == 0x10CFFF) {
        break;
      }
      _SendKeyWithAlt(hWnd, 0x30);
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }
}
void HitBoss(HWND hWnd, int array[][3], size_t len) {
  int count = 0;
  while (1) {
    HDC hdc = GetDC(NULL);
    count++;
    if (hdc) {
      BOOL bHit = TRUE;
      for (size_t i = 0; i < len; i++) {
        if (GetPixel(hdc, array[i][0], array[i][1]) != array[i][2]) {
          bHit = FALSE;
          break;
        }
      }
      if (bHit) {
        Attack(hWnd);
      } else {
        _SendKeyBackground(hWnd, 0x9);
        Sleep(1000);
        if (count > 3) {
          break;
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}

DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = GetGameHandle();

  while (1) {
    _GetStatusAccelerate(hWnd);
    GoTransmitter();
    GoHuashan();
    GoMoyu();
    GoLocation1(hWnd);
    GoLocation2(hWnd);
    GoLocation3(hWnd);
    GoLocation4(hWnd);
    GobackDragonCity(hWnd);
  }
  return 0;
}
int main(int argc, char* argv[]) {
  int k1 = 1;

  if (RegisterHotKey(NULL, k1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        // GoTransmitter();

        // int array[][3] = {{460, 30, 0xB3B3BD}, {427, 24, 0xB3B3BD}};
        // HitBoss(hWnd, array, 2);
        // return 0;

        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, NULL, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }

  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
// gcc in-bot.c -o m && m