// -lgdi32

#include <Windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <stdio.h>
#include "key.h"
#include "ffo.h"

#define POS_AUTO_LEFT_X 404
#define POS_AUTO_LEFT_Y 378
#define POS_AUTO_RIGHT_X 954

#define APP_HWND 0
#define APP_PID 0

static BOOL mStatus = FALSE;

DWORD WINAPI Strategy(LPVOID lpParam) {
  DWORD pid;
  if (APP_PID != 0)
    pid = APP_PID;
  else
    pid = _GetProcessIdByName("qqffo.exe");
  if (!pid) {
    printf("Failed get target process id.\n");
    return 1;
  }
  HANDLE hProc = GetCurrentProcess();
  HANDLE hToken = NULL;
  if (!OpenProcessToken(hProc, TOKEN_ADJUST_PRIVILEGES, &hToken)) {
    printf("Failed to open acess token.\n");
    return 1;
  }
  if (!_SetPrivilege(hToken, SE_DEBUG_NAME, TRUE)) {
    printf("Failed to set debug privilege.\n");
    return 1;
  }
  HANDLE hTargetProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
  if (!hTargetProc) {
    printf("Failed to open process: %u.\n", GetLastError());
    return 1;
  }
  BYTE array[] = {0xFF, 0xFF, 0xFF, 0xFF, 0x50, 0, 0, 0, 0x26, 0, 0, 0, 0x5B};
  SIZE_T objectAddress = _ScanSegments(hTargetProc, array, sizeof(array));
  SIZE_T hpAddress = objectAddress + 0x80;

  printf("Find Memory %x.\n", hpAddress);
  HWND hWnd;
  if (APP_HWND != 0)
    hWnd = (HWND)APP_HWND;
  else
    hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }
  if (!hpAddress) {
    return 0;
  }
  int count = 0;
  while (1) {
    count++;

    DWORD result = _ReadDword(hTargetProc, hpAddress);
    if (result < 3000) {
      _SendKeyBackground(hWnd, 0x71);
      Sleep(1000);
      _SendKeyBackground(hWnd, 0x72);
      Sleep(1000);

    } else {
      if (count % 30 == 0) {
        _SendKeyBackground(hWnd, 0x73);
        Sleep(500);
      }
      if (count % 4 == 0) {
        _SendKeyBackground(hWnd, 0x74);
        Sleep(500);
      }
      if (count % 15 == 0) {
        _SendKeyBackground(hWnd, 0x75);
        Sleep(500);
      }
      // _SendKeyBackground(hWnd, 0x75);
      // Sleep(1000);

      if (count > 150) {
        count = 0;
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyWithAlt(hWnd, KEY_1_SKILL_DEFENSE);
        Sleep(3000);
        _SendKeyWithAlt(hWnd, KEY_1_SKILL_BLESSING);
        Sleep(3000);
      }
    }

    Sleep(1000);
  }
  return 0;
}
int main(int argc, char* argv[]) {
  int k1 = 1;

  if (RegisterHotKey(NULL, k1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  MSG msg = {0};
  HANDLE hThread = {0};
  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == k1) {
        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, NULL, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }

  // TEB teb;
  // if (!GetMainThreadTeb(pid, &teb)) {
  //   printf("Failed to get TEB.\n");
  // }
  // printf("PEB = %p StackBase = %p.\n", teb.ProcessEnvironmentBlock,
  //        teb.Reserved1[1]);
  return 0;
}
// gcc in-bot.c -o m && m