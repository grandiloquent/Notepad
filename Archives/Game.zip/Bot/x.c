
// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"
#include "ffo.h"

static BOOL mStatus = FALSE;

void GoEightImmortals() {
  // 去华山
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 831, 257) == 0xFFFFFF) {
        break;
      }
      _Click(1120, 173);
      Sleep(1000);
      _Click(1061, 175);
      Sleep(1000);
      _Click(918, 218);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }

  _Click(564, 365);
  Sleep(1000);
  _Click(521, 264);
  Sleep(1000);
  _Click(452, 470);
  Sleep(1000);

  // 八仙
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 231) == 0xFFFFFF &&
          GetPixel(hdc, 662, 274) == 0xFFFFFF) {
        break;
      }
      _Click(1120, 173);
      Sleep(1000);
      _Click(1061, 175);
      Sleep(1000);
      _Click(891, 177);
      Sleep(1000);
      ReleaseDC(NULL, hdc);
    }
    Sleep(3000);
  }

  _Click(549, 366);
  Sleep(3000);
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;

  BOOL isSearching = FALSE;
  int hit = 0;
  int count = 0;
  _GetStatusAccelerate();
  GoEightImmortals();
  _GetStatus();
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      _RefreshStrength(hWnd, hdc);
      if (_CheckSelectedMonster(hdc)) {
        hit--;
        if (hit < 0) hit = 0;
        _SendKeyBackground(hWnd, 0x70);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x74);
        Sleep(1000);
      } else {
        if (hit > 2) {
          if (count > 300) {
            _GetStatus();
            count = 0;
          }
          _GoLocation(950, 373, 1000);
          Sleep(3000);

          _Click(654, 322);
          Sleep(1000);
          hit = 0;
        } else {
          _SelectMonster(hWnd);
          hit++;
        }
      }
      // 如果到达目的地回城
      if (GetPixel(hdc, 1089, 47) == 0xFFFFFF &&
          GetPixel(hdc, 1102, 46) == 0xFFFFFF &&
          GetPixel(hdc, 1113, 46) == 0xFFFFFF) {
        _ClickDouble(671, 677);
        Sleep(1000);
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    count++;
    Sleep(1000);
  }
  return 0;
}

int main() {
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  //===
  int keyId = 1;

  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }

  MSG msg = {0};
  HANDLE hThread = {0};

  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        // _GoLocation(950, 373, 1000);
        // Sleep(1000);
        // while (1) {
        //   HDC hdc = GetDC(NULL);
        //   if (hdc) {
        //     if (GetPixel(hdc, 1089, 47) == 0xFFFFFF &&
        //         GetPixel(hdc, 1102, 46) == 0xFFFFFF &&
        //         GetPixel(hdc, 1113, 46) == 0xFFFFFF) {
        //       _ClickDouble(671, 677);
        //       Sleep(1000);
        //       break;
        //     }
        //     ReleaseDC(NULL, hdc);
        //   }
        //   Sleep(1000);
        // }

        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }
  return 0;
}