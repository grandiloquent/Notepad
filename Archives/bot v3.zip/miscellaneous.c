
// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"

static BOOL mStatus = FALSE;

DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  while (1) {
    // _SendKeyBackground(hWnd, 0x70);
    // Sleep(1000);

    // _SendKeyBackground(hWnd, 0x74);
    // Sleep(1000);
    // _SendKeyBackground(hWnd, 0x73);
    // Sleep(1000);

    // _SendKeyBackground(hWnd, 0x72);
    // Sleep(1000);
    // _SendKeyBackground(hWnd, 0x73);
    // Sleep(1000);
    // _SendKeyBackground(hWnd, 0x72);
    // Sleep(1000);

    _SendKeyBackground(hWnd, 0x71);
    Sleep(500);
  }
  return 0;
}
int main() {
  HWND hWnd = (HWND)0x00020316;//FindWindow("QQSwordWinClass", NULL);
  // if (!hWnd) {
  //   return 0;
  // }

  int hotkey1 = 1;
  int hotkey2 = 2;
  int hotkey3 = 3;
  int hotkey4 = 4;
  int hotkey5 = 5;

  if (RegisterHotKey(NULL, hotkey1, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success. [Strong blow]\n");
  }
  if (RegisterHotKey(NULL, hotkey4, MOD_CONTROL, 0x51)) {
    printf("Register Hotkey: [Ctrl+Q] Success. [Start state skill]\n");
  }
  if (RegisterHotKey(NULL, hotkey3, 0, 0x70)) {
    printf("Register Hotkey: [F1] Success. [Sequence strike]\n");
  }
  if (RegisterHotKey(NULL, hotkey5, 0, 0x75)) {
    printf("Register Hotkey: [F6] Success. [Accelerate]\n");
  }
  if (RegisterHotKey(NULL, hotkey2, MOD_CONTROL, 0x5A)) {
    printf("Register Hotkey: [Ctrl+Z] Success. [Open task dialog]\n");
  }

  //===

  MSG msg = {0};
  HANDLE hThread1 = {0};

  DWORD dwThreadIdArray[3];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == hotkey1) {
        if (!hThread1) {
          hThread1 =
              CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread1);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread1);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      } else if (msg.wParam == hotkey2) {
        _Click(879, 720);
        Sleep(1000);
        _Click(859, 678);
        Sleep(1000);
        _Click(849, 141);
        Sleep(500);

      } else if (msg.wParam == hotkey3) {
        _SendKeyBackground(hWnd, 0x70);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x74);
        Sleep(1000);
         

        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
      } else if (msg.wParam == hotkey4) {
        // 盾
        _SendKeyBackground(hWnd, 0x72);
        Sleep(100);
        // 盾
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        // 防御
        _ClickDouble(513, 679);
        Sleep(3000);
        // 祝福
        _ClickDouble(553, 679);
        Sleep(3000);
        // 加速
        _ClickDouble(472, 685);
        Sleep(1000);
      } else if (msg.wParam == hotkey5) {
        _Click(402, 716);
        Sleep(50);
        _Click(402, 716);
        Sleep(1000);
        _Click(402, 716);
        Sleep(50);
        _Click(402, 716);
        Sleep(1000);
        _Click(471, 677);
        Sleep(50);
        _Click(471, 677);
      }
    }
  }
  return 0;
}