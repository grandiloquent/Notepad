
// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"

static BOOL mStatus = FALSE;
void SearchMonster() {
  _Click(1112, 99);
  Sleep(1000);
  _ClickRight(511, 368);
  Sleep(1000);
  _Click(1112, 99);
  Sleep(500);
  _Click(687, 391);
  Sleep(1000);
}
void GetStatus() {
  _ClickDouble(505, 677);
  Sleep(3000);
  _ClickDouble(552, 676);
  Sleep(3000);
}
void GetHealth(HWND hWnd) {
  _SendKeyBackground(hWnd, 0x71);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x72);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0x76);
  Sleep(1000);
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  int hitMonster = 0;
  int countBarrier = 0;
  int countStatus = 0;
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // 加血
      if (GetPixel(hdc, 334, 42) != 0x22AA11) {
        GetHealth(hWnd);
        continue;
      }
      // 检查怪物
      if (GetPixel(hdc, 397, 37) == 0x6699CC &&
          GetPixel(hdc, 394, 37) == 0x112244) {
        hitMonster--;
        if (hitMonster < 0) hitMonster = 0;
        if (GetPixel(hdc, 490, 43) == 0x55DD44) {
          countBarrier++;
        } else {
          countBarrier = 0;
        }
        if (countBarrier > 2) {
          hitMonster++;
          if (hitMonster < 2) {
            _SendKeyBackground(hWnd, 0x9);
            Sleep(1000);
          } else {
            SearchMonster();
          }
          hitMonster = 0;
          countBarrier = 0;
          continue;
        }

        _SendKeyBackground(hWnd, 0x70);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x73);
        Sleep(1000);
      } else {
        hitMonster++;
        if (hitMonster < 2) {
          _SendKeyBackground(hWnd, 0x9);
          Sleep(1000);
        } else {
          if (countStatus > 50) {
            GetStatus();
            countStatus = 0;
          }
          SearchMonster();
          hitMonster = 0;
        }
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
    countStatus++;
  }
  return 0;
}

int main() {
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  //===
  int keyId = 1;

  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }

  MSG msg = {0};
  HANDLE hThread = {0};

  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }
  return 0;
}