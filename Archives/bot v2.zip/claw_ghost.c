// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"
static BOOL mStatus = FALSE;

void Accelerate() {
  _Click(468, 676);
  Sleep(50);
  _Click(468, 676);
  Sleep(4000);
}

void GoTransmitter() {
  _Click(1120, 173);
  Sleep(1000);
  _Click(1059, 179);
  Sleep(1000);
  _Click(861, 239);
  Sleep(1000);

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 430, 344) == 0x00FF00 &&
          GetPixel(hdc, 436, 351) == 0x00FF00) {
        break;
      }
      //  else {
      //   GoTransmitter();
      // }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 516, 381) == 0x00D9FE) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  _Click(575, 365);
  Sleep(1000);
  _Click(521, 210);
  Sleep(1000);
  _Click(442, 467);
  Sleep(1000);
}
void GoTaskPublisher() {
  printf("GoTaskPublisher\n");

  //接任务
  _Click(1120, 172);
  Sleep(1000);
  _Click(1062, 193);
  Sleep(1000);
  _Click(882, 335);
  Sleep(1000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 382, 84) == 0x00FF00 &&
          GetPixel(hdc, 386, 87) == 0x00FF00) {
        printf("Reaching the destination. [GoTaskPublisher]\n");
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void AskTask() {
  printf("AskTask\n");
  GoTaskPublisher();
  // 阻塞
  // 检查是否到达目的地

  while (1) {
    HDC hdc = GetDC(NULL);

    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 665, 249) == 0xFFFFFF) {
        printf("Reaching the destination. [AskTask]\n");
        break;
      } else {
        _Click(632, 603);
        Sleep(1000);
        GoTaskPublisher();
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  _Click(539, 363);
  Sleep(1000);
  _Click(539, 363);
  Sleep(1000);
}
void GoMonster(HWND hWnd) {
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1003, 265) == 0xFFFFFF &&
          GetPixel(hdc, 1041, 265) == 0x00D9FE) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }

  Accelerate();
  GoTransmitter();
  Accelerate();

  // 收集
  _Click(320, 674);
  Sleep(50);
  _Click(320, 674);
  Sleep(1000);
  // 盾
  _Click(400, 719);
  Sleep(50);
  _Click(400, 719);
  Sleep(1000);

  //防御
  _Click(510, 675);
  Sleep(50);
  _Click(510, 675);
  Sleep(3000);

  // 祝福
  _Click(551, 676);
  Sleep(50);
  _Click(551, 676);
  Sleep(3500);

  _Click(1014, 273);
  Sleep(1000);
  // 修罗1层
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1083, 9) == 0x10CFFF &&
          GetPixel(hdc, 1120, 8) == 0x10CFFF &&
          GetPixel(hdc, 1134, 15) == 0x10CFFF) {
        break;
      }
      ReleaseDC(NULL, hdc);
      _Click(1014, 273);
      Sleep(1000);
    }
    Sleep(1000);
  }
  // 寻路2层
  _Click(1121, 173);
  Sleep(1000);
  _Click(1079, 216);
  Sleep(1000);
  _Click(890, 237);
  Sleep(3000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1119, 9) == 0x10CFFF &&
          GetPixel(hdc, 1122, 7) == 0x10CFFF &&
          GetPixel(hdc, 1123, 14) == 0x10CFFF) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
}
void GoFight(HWND hWnd) {
  printf("GoFight\n");
  // 盾
  _Click(400, 719);
  Sleep(50);
  _Click(400, 719);
  Sleep(1000);

  // 寻路挂机地点
  _Click(1099, 109);
  Sleep(1000);
  _ClickRight(699,504);
  Sleep(1000);
  _Click(1099, 109);
  Sleep(10000);
  _SendKeyWithAlt(hWnd, 0x57);
  Sleep(1000);
  // 移开鼠标指针
  SetCursorPos(1,1);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 958, 268) == 0xFFFFFF &&
          GetPixel(hdc, 1088, 276) == 0x00D9FE) {
        _SendKeyBackground(hWnd, 0x73);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x71);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x72);
        Sleep(3000);

      } else {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
  }
  // 停止挂机
  _SendKeyWithAlt(hWnd, 0x57);
  Sleep(1000);
  // 通灵
  _Click(354, 682);
  Sleep(50);
  _Click(354, 682);
  Sleep(1000);
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 1093, 6) == 0x10CFFF &&
          GetPixel(hdc, 1126, 15) == 0x10CFFF) {
        break;
      }
      ReleaseDC(NULL, hdc);
      // 回城
      _Click(667, 681);
      Sleep(50);
      _Click(667, 681);
      Sleep(2000);
    }
    Sleep(1000);
  }

  GoTaskPublisher();
  while (1) {
    HDC hdc = GetDC(NULL);

    if (hdc) {
      if (GetPixel(hdc, 480, 231) == 0xFFFFFF &&
          GetPixel(hdc, 665, 249) == 0xFFFFFF) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  _Click(539, 363);
  Sleep(1000);
  _Click(602, 585);
  Sleep(1000);
}
DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  // _SendKeyBackground(hWnd, 0x73);
  // Sleep(1000);
  // _Click(628, 367);
  // Sleep(2000);
  // GoMonster(hWnd);

  while (1) {
    AskTask();
    GoMonster(hWnd);
    GoFight(hWnd);
  }

  return 0;
}

int main(int argc, char* argv[]) {
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  int keyId = 1;
  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  MSG msg = {0};
  HANDLE hThread = {0};

  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        if (!hThread) {
          hThread =
              CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      }
    }
  }
}