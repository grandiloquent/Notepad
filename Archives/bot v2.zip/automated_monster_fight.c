
// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"

static BOOL mStatus = FALSE;


DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;
  
  return 0;
}

int main() {
  
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  
  int keyId = 1;
  

  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId1, MOD_CONTROL, 0x32)) {
    printf("Register Hotkey: [Ctrl+2] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId2, MOD_CONTROL, 0x33)) {
    printf("Register Hotkey: [Ctrl+3] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId3, 0x0, 0x74)) {
    printf("Register Hotkey: [F5] Success.\n");
  }
  if (RegisterHotKey(NULL, keyId4, MOD_CONTROL, 0x4D)) {
    printf("Register Hotkey: [Ctrl+M] Success.\n");
  }
  //===

  MSG msg = {0};
  HANDLE hThread = {0};
  HANDLE hThread1 = {0};
  HANDLE hThread2 = {0};

  DWORD dwThreadIdArray[3];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        if (!hThread) {
          hThread = CreateThread(NULL, 0, StrategyAutoFight, hWnd, 0,
                                 &dwThreadIdArray[0]);
          mStatus = TRUE;
          printf("Create Thread 1.\n");
        } else {
          if (mStatus) {
            SuspendThread(hThread);
            mStatus = FALSE;
            printf("Suspend Thread 1.\n");
          } else {
            ResumeThread(hThread);
            mStatus = TRUE;
            printf("Resume Thread 1.\n");
          }
        }
      } else if (msg.wParam == keyId1) {
        if (!hThread1) {
          hThread1 = CreateThread(NULL, 0, StrategyHardly, hWnd, 0,
                                  &dwThreadIdArray[1]);
          mStatus1 = TRUE;
          printf("Create Thread 2.\n");
        } else {
          if (mStatus1) {
            SuspendThread(hThread1);
            mStatus1 = FALSE;
            printf("Suspend Thread 2.\n");
          } else {
            ResumeThread(hThread1);
            mStatus1 = TRUE;
            printf("Resume Thread 2.\n");
          }
        }
      } else if (msg.wParam == keyId2) {
        if (!hThread2) {
          hThread2 =
              CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[2]);
          mStatus2 = TRUE;
          printf("Create Thread 3.\n");
        } else {
          if (mStatus2) {
            SuspendThread(hThread2);
            mStatus2 = FALSE;
            printf("Suspend Thread 3.\n");
          } else {
            ResumeThread(hThread2);
            mStatus2 = TRUE;
            printf("Resume Thread 3.\n");
          }
        }
      } else if (msg.wParam == keyId3) {
        _PrintMousePosition();
      } else if (msg.wParam == keyId4) {
      }
    }
  }
  return 0;
}
