// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"

void Accelerate() {
  _ClickDouble(468, 679);
  Sleep(4300);
}
int AnalyzingDestination(HWND hWnd) {
  //东南西北
  int direction = -1;
  int nc[3][3] = {
      {674, 230, 0xFFFFFF}, {671, 230, 0xFFFFFF}, {668, 239, 0xFFFFFF}};
  int sc[3][3] = {
      {673, 233, 0xFFFFFF}, {674, 236, 0xFFFFFF}, {669, 233, 0xFFFFFF}};
  int ec[3][3] = {
      {669, 235, 0xFFFFFF}, {678, 231, 0xFFFFFF}, {668, 239, 0xFFFFFF}};
  int count = 0;
  while (1) {
    _Click(872, 719);
    Sleep(1000);
    _Click(859, 681);
    Sleep(1000);
    HDC hdc = GetDC(NULL);
    if (hdc) {
      //   if (GetPixel(hdc, nc[0][0], nc[0][1]) == nc[0][2] ||
      //       GetPixel(hdc, nc[1][0], nc[1][1]) == nc[1][2] ||
      //       GetPixel(hdc, nc[2][0], nc[2][1]) == nc[2][2]) {
      //     printf("%s\n", "north");
      //   }
      //   if (GetPixel(hdc, sc[0][0], sc[0][1]) == sc[0][2] ||
      //       GetPixel(hdc, sc[1][0], sc[1][1]) == sc[1][2] ||
      //       GetPixel(hdc, sc[2][0], sc[2][1]) == sc[2][2]) {
      //     printf("%s %x\n", "south", GetPixel(hdc, sc[0][0], sc[0][1]));
      //   }

      if (GetPixel(hdc, 672, 232) == 0xFFFFFF) {
        BOOL c = TRUE;
        for (int i = 668; i < 679; ++i) {
          if (GetPixel(hdc, i, 231) != 0xFFFFFF) {
            c = FALSE;
            break;
          }
        }
        if (c) {
          printf("%s\n", "east");
          // 关闭任务框
          _Click(891, 115);
          Sleep(1000);
          return 0;
        }
      }
      if (GetPixel(hdc, 671, 234) == 0xFFFFFF) {
        BOOL c = TRUE;
        for (int i = 233; i < 241; ++i) {
          if (GetPixel(hdc, 669, i) != 0xFFFFFF) {
            c = FALSE;
            break;
          }
        }
        if (c) {
          printf("%s\n", "sourth");
          // 关闭任务框
          _Click(891, 115);
          Sleep(1000);
          return 1;
        }
      }
      if (GetPixel(hdc, 672, 236) == 0xFFFFFF) {
        BOOL c = TRUE;
        for (int i = 231; i < 236; ++i) {
          if (GetPixel(hdc, 672, i) != 0xFFFFFF) {
            c = FALSE;
            break;
          }
        }
        if (c) {
          printf("%s\n", "west");
          // 关闭任务框
          _Click(891, 115);
          Sleep(1000);
          return 2;
        }
      }
      if (GetPixel(hdc, 678, 237) == 0xFFFFFF) {
        BOOL c = TRUE;
        for (int i = 230; i < 241; ++i) {
          if (GetPixel(hdc, 671, i) != 0xFFFFFF) {
            c = FALSE;
            break;
          }
        }
        if (c) {
          printf("%s\n", "north");
          // 关闭任务框
          _Click(891, 115);
          Sleep(1000);
          return 3;
        }
      }
      break;
      ReleaseDC(NULL, hdc);
      count++;
      if (count > 5) break;
    }
  }
  return -1;
}
void HandoverTask() {
  // 阻塞
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 231) == 0xFFFFFF &&
          GetPixel(hdc, 497, 379) == 0xFFFFFF &&
          GetPixel(hdc, 537, 387) == 0x000000) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 确定完成任务
  _Click(540, 366);
  Sleep(1000);
}
void GoCity(HWND hWnd) {
  // 点击回城
  _Click(668, 681);
  Sleep(50);
  _Click(668, 681);
  Sleep(1000);

  Accelerate();
  // 隐藏所有玩家
  _SendKeyBackground(hWnd, 0X7A);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0X7A);
  Sleep(1000);
  _SendKeyBackground(hWnd, 0X7A);
  Sleep(1000);

  _Click(1106, 108);
  Sleep(1000);
  _ClickRight(682, 330);
  Sleep(1000);
  _Click(1106, 108);
  Sleep(1000);

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 548, 75) == 0x00FF00 &&
          GetPixel(hdc, 1136, 421) == 0x00FF00) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
  }
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 481, 235) == 0xFFFFFF &&
          GetPixel(hdc, 519, 293) == 0x0082FF) {
        break;
      } else {
        _Click(717, 341);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
      Sleep(1000);
    }
  }

  // 关于家族屋
  _Click(548, 422);
  Sleep(1000);
  // 进入家族屋
  _Click(538, 365);
  Sleep(1000);
}
void GoPriest() {
  // 寻路家族祭司
  _ClickRight(1138, 68);
  Sleep(1000);

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 643, 256) == 0x00FF00) {
        break;
      }
      ReleaseDC(NULL, hdc);
    }
  }

  // 打开对话框
  _Click(664, 321);
  Sleep(1000);

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 233) == 0xFFFFFF &&
          GetPixel(hdc, 499, 379) == 0x91EBA0) {
        break;
      } else {
        _Click(664, 321);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
      Sleep(1000);
    }
  }
  // 打开对话框
  _Click(664, 321);
  Sleep(1000);
  _Click(588, 422);
  Sleep(1000);
  _Click(581, 362);
  Sleep(1000);

  // 打开对话框
  _Click(664, 321);
  Sleep(1000);

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      if (GetPixel(hdc, 480, 233) == 0xFFFFFF &&
          GetPixel(hdc, 499, 379) == 0x91EBA0) {
        break;
      } else {
        _Click(664, 321);
        Sleep(1000);
      }
      ReleaseDC(NULL, hdc);
      Sleep(1000);
    }
  }

  _Click(588, 422);
  Sleep(1000);
  _Click(581, 362);
  Sleep(1000);
}
void GoEast(HWND hWnd) {
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // 地图
  _Click(1068, 217);
  Sleep(1000);
  // 下拉
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  // 寻址
  _Click(900, 397);
  Sleep(1000);
  // 阻塞
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      BOOL c = TRUE;
      for (int i = 1110; i < 1120; ++i) {
        if (GetPixel(hdc, i, 6) != 0x10CFFF) {
          c = FALSE;
          break;
        }
      }
      if (c) break;
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // NPC
  _Click(1055, 174);
  Sleep(1000);
  // 洞
  _Click(896, 216);
  Sleep(1000);
  HandoverTask();
  GoCity(hWnd);
  GoPriest();
}
void GoSouth(HWND hWnd) {
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // 地图
  _Click(1068, 217);
  Sleep(1000);
  // 下拉
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  // 寻址
  _Click(900, 397);
  Sleep(1000);
  // 阻塞
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      BOOL c = TRUE;
      for (int i = 8; i < 16; ++i) {
        if (GetPixel(hdc, 1111, i) != 0x10CFFF) {
          c = FALSE;
          break;
        }
      }
      if (c) break;
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // NPC
  _Click(1055, 174);
  Sleep(1000);
  // 洞
  _Click(914, 177);
  Sleep(1000);

  HandoverTask();
  GoCity(hWnd);
  GoPriest();
}
void GoWest(HWND hWnd) {
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // 地图
  _Click(1068, 217);
  Sleep(1000);
  // 下拉
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  // 寻址
  _Click(900, 397);
  Sleep(1000);
  // 阻塞
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      BOOL c = TRUE;
      for (int i = 8; i < 16; ++i) {
        if (GetPixel(hdc, 1111, i) != 0x10CFFF) {
          c = FALSE;
          break;
        }
      }
      if (c) break;
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // NPC
  _Click(1055, 174);
  Sleep(1000);
  // 洞
  _Click(914, 177);
  Sleep(1000);

  HandoverTask();
  GoCity(hWnd);
  GoPriest();
}
void GoNorth(HWND hWnd) {
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // 地图
  _Click(1068, 217);
  Sleep(1000);
  // 下拉
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);
  _Click(1000, 399);
  Sleep(1000);

  // 寻址
  _Click(900, 397);
  Sleep(1000);
  // 阻塞
  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      BOOL c = TRUE;
      for (int i = 5; i < 16; ++i) {
        if (GetPixel(hdc, 1113, i) != 0x10CFFF) {
          c = FALSE;
          break;
        }
      }
      if (c) break;
      ReleaseDC(NULL, hdc);
    }
    Sleep(1000);
  }
  // 寻路路标
  _Click(1122, 174);
  Sleep(1000);
  // NPC
  _Click(1055, 174);
  Sleep(1000);
  // 洞
  _Click(916, 200);
  Sleep(1000);

  HandoverTask();
  GoCity(hWnd);
  GoPriest();
}
int main(int argc, char* argv[]) {
  // 获取程序句柄
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }
  // 注册热键
  int keyId = 1;
  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  // 捕获消息队列
  MSG msg = {0};

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
        for (int i = 0; i < 20; ++i) {
          // 在家族内部点击回城
          _Click(668, 681);
          Sleep(50);
          _Click(668, 681);
          Sleep(1000);
          // 进龙城
          _ClickRight(1069, 98);
          Sleep(5000);

          Accelerate();
          int r = AnalyzingDestination(hWnd);

          if (r == 0) {
            GoEast(hWnd);
          } else if (r == 1) {
            GoSouth(hWnd);
          } else if (r == 2) {
            GoWest(hWnd);
          } else if (r == 3) {
            GoNorth(hWnd);
          } else {
            break;
          }
        }
      }
    }
  }
  return 0;
}