// -lgdi32

#include <Windows.h>
#include <stdio.h>
#include "key.h"
#include "qfx.h"
static BOOL mStatus = FALSE;

DWORD WINAPI Strategy(LPVOID lpParam) {
  HWND hWnd = (HWND)lpParam;

  BOOL isStopAuto = FALSE;
  BOOL getTrans = FALSE;
  BOOL isAuto = FALSE;

  int count = 0;
  int coordsTask[3][3] = {
      {984, 266, 0xFFFFFF}, {1041, 265, 0x00D9FE}, {1097, 5, 0x10CFFF}};
  int coordsTransmitter[2][3] = {{480, 231, 0xFFFFFF}, {504, 251, 0xFFFFFF}};
  int coordsTaskPublisher[2][3] = {{480, 231, 0xFFFFFF}, {508, 249, 0xFFFFFF}};

  int coordsCow[3][3] = {
      {1078, 265, 0xFFFFFF}, {1137, 265, 0x00D9FE}, {1100, 6, 0x10CFFF}};

  while (1) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      // 0xbbggrr
      if (!isAuto &&
          GetPixel(hdc, coordsTask[2][0], coordsTask[2][1]) ==
              coordsTask[2][2] &&
          GetPixel(hdc, coordsTask[0][0], coordsTask[0][1]) ==
              coordsTask[0][2] &&
          GetPixel(hdc, coordsTask[1][0], coordsTask[1][1]) ==
              coordsTask[1][2]) {
        if (!getTrans) {
          //  打开寻路菜单
          _Click(1121, 171);
          Sleep(1000);
          // 点击关键NPC
          _Click(1073, 177);
          Sleep(1000);
          // 寻路传送员
          _Click(895, 237);
          Sleep(1000);
          getTrans = TRUE;
          isStopAuto = FALSE;
        }

        if (GetPixel(hdc, coordsTransmitter[0][0], coordsTransmitter[0][1]) ==
                coordsTransmitter[0][2] &&
            GetPixel(hdc, coordsTransmitter[1][0], coordsTransmitter[1][1]) ==
                coordsTransmitter[1][2]) {
          // 点击我想使用传送服务
          _Click(574, 385);
          Sleep(1000);
          // 青牛山脚
          _Click(519, 213);
          Sleep(1000);
          // 点击确定传送
          _Click(452, 468);
          Sleep(1000);
          // 挂机前设定收集技能
          _SendKeyWithAlt(hWnd, 0x31);
          Sleep(1000);
          /// 移动到挂机地点
          OpenMap();
          _ClickRight(692, 410);
          Sleep(15000);
          CloseMap();
          // 自动挂机
          _SendKeyWithAlt(hWnd, 0x57);
          Sleep(1000);
          isAuto = TRUE;
        }
      }
      // 检查是否完成任务
      if (GetPixel(hdc, coordsCow[0][0], coordsCow[0][1]) == coordsCow[0][2] &&
          GetPixel(hdc, coordsCow[1][0], coordsCow[1][1]) == coordsCow[1][2]) {
        isAuto = FALSE;
        getTrans = FALSE;
        if (!isStopAuto) {
          // 取消自动挂机
          _SendKeyWithAlt(hWnd, 0x57);
          Sleep(1000);
          // 如果在青牛山回城
          // 完成任务前 设定通灵技能
          _SendKeyWithAlt(hWnd, 0x31);
          Sleep(1000);
          _SendKeyWithAlt(hWnd, 0x32);
          Sleep(1000);
          isStopAuto = TRUE;
        }

        if (GetPixel(hdc, coordsCow[2][0], coordsCow[2][1]) ==
            coordsCow[2][2]) {
          _SendKeyWithAlt(hWnd, 0x30);
          Sleep(1000);
        } else if (GetPixel(hdc, coordsTaskPublisher[0][0],
                            coordsTaskPublisher[0][1]) ==
                       coordsTaskPublisher[0][2] &&
                   GetPixel(hdc, coordsTaskPublisher[1][0],
                            coordsTaskPublisher[1][1]) ==
                       coordsTaskPublisher[1][2]) {
          _Click(615, 370);
          Sleep(1000);
          // _Click(665, 337);
          // Sleep(1000);
          // _Click(612, 363);
          // Sleep(1000);
          // _Click(612, 363);
          // Sleep(1000);
          // 移动位置以便打开对话框
          _Click(554, 451);
          Sleep(1000);
          _Click(554, 451);
          Sleep(2000);
          //  打开寻路菜单
          _Click(1121, 171);
          Sleep(1000);
          // 点击关键NPC
          _Click(1072, 197);
          Sleep(1000);
          // 巡卫阿吉
          _Click(883, 340);
          Sleep(2000);
          _Click(562, 365);
          Sleep(1000);
          _Click(562, 365);
          Sleep(1000);

        } else {
          _Click(1101, 270);
          Sleep(1000);
        }
      }
      ReleaseDC(NULL, hdc);
    }

    if (isAuto) {
      count++;
      if (count % 5 == 0) {
        _SendKeyBackground(hWnd, 0x71);
        Sleep(1000);
        _SendKeyBackground(hWnd, 0x72);
        Sleep(1000);
      }
      if (count > 300) {
        LaunchAssistiveSkills(hWnd);
        count = 0;
      }
    }
  }
  return 0;
}

int main(int argc, char* argv[]) {
  HWND hWnd = FindWindow("QQSwordWinClass", NULL);
  if (!hWnd) {
    return 0;
  }

  int keyId = 1;
  if (RegisterHotKey(NULL, keyId, MOD_CONTROL, 0x31)) {
    printf("Register Hotkey: [Ctrl+1] Success.\n");
  }
  MSG msg = {0};
  HANDLE hThread = {0};

  DWORD dwThreadIdArray[1];

  while (GetMessage(&msg, NULL, 0, 0) != 0) {
    if (msg.message == WM_HOTKEY) {
      if (msg.wParam == keyId) {
         _Click(554, 451);
          Sleep(1000);
          _Click(554, 451);
          Sleep(2000);
          //  打开寻路菜单
          _Click(1121, 171);
          Sleep(1000);
          // 点击关键NPC
          _Click(1072, 197);
          Sleep(1000);
          // 巡卫阿吉
          _Click(883, 340);
          Sleep(2000);
          _Click(562, 365);
          Sleep(1000);
          _Click(562, 365);
          Sleep(1000);
        // if (!hThread) {
        //   hThread =
        //       CreateThread(NULL, 0, Strategy, hWnd, 0, &dwThreadIdArray[0]);
        //   mStatus = TRUE;
        //   printf("Create Thread 1.\n");
        // } else {
        //   if (mStatus) {
        //     SuspendThread(hThread);
        //     mStatus = FALSE;
        //     printf("Suspend Thread 1.\n");
        //   } else {
        //     ResumeThread(hThread);
        //     mStatus = TRUE;
        //     printf("Resume Thread 1.\n");
        //   }
        // }
      }
    }
  }
}