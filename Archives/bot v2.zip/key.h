#ifndef KEY_H
#define KEY_H

#include <Windows.h>

#define SCREEN_WIDTH 1366
#define SCREEN_HEIGHT 768

typedef struct {
  BYTE r;
  BYTE g;
  BYTE b;
} tagColor, Color;

void _ClipboardSetText(const char *c);
char *_GetPixelUnderMouse();
void _MouseClick(int x, int y, BOOL isRightButton, BOOL isDoubleClick);
void _PixelColor(Color *color, int x, int y);
void _PixelSearchColor(POINT *p, int left, int top, int right, int bottom,
                       BYTE r, BYTE g, BYTE b);
void _SendKeyBackground(HWND hWnd, WORD wVk);
void _SendKeyWithAlt(HWND hWnd, UINT vk);
void _PrintPixelColor(int x, int y);
void _PrintMousePosition();
void _Click(int x, int y);
void _ClickRight(int x, int y);
void _ClickDouble(int x, int y);

void _ClickDouble(int x, int y){
  _Click(x,y);
  Sleep(50);
  _Click(x,y);
}
void _Click(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
  mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
}

void _ClickRight(int x, int y) {
  SetCursorPos(x, y);
  mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
  mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
}
void _PrintMousePosition() {
  POINT point;
  if (GetCursorPos(&point)) {
    char buf[50];
    sprintf(buf, "%d,%d", point.x, point.y);
    _ClipboardSetText(buf);
  }
}
void _PrintPixelColor(int x, int y) {
  HDC hdc = GetDC(NULL);
  if (hdc) {
    COLORREF cr = GetPixel(hdc, x, y);
    printf("x: %d,y: %d: 0x%x\n", x, y, cr);
    ReleaseDC(NULL, hdc);
  }
}
void _ClipboardSetText(const char *c) {
  if (OpenClipboard(NULL)) {
    const size_t len = strlen(c) + 1;
    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len);
    memcpy(GlobalLock(hMem), c, len);
    GlobalUnlock(hMem);
    EmptyClipboard();
    SetClipboardData(CF_TEXT, hMem);
    CloseClipboard();
  }
}

char *_GetPixelUnderMouse() {
  POINT point;
  if (GetCursorPos(&point)) {
    HDC hdc = GetDC(NULL);
    if (hdc) {
      COLORREF cr = GetPixel(hdc, point.x, point.y);
      char *buf = malloc(sizeof(char) * 1024);
      sprintf(
          buf,
          "%d,%d\nint x=%d;\nint y=%d;\nBYTE r=%d;\nBYTE g=%d;\n BYTE b=%d;",
          point.x, point.y, point.x, point.y, GetRValue(cr), GetGValue(cr),
          GetBValue(cr));
      ReleaseDC(NULL, hdc);

      return buf;
    }
  }
  return NULL;
}

void _MouseClick(int x, int y, BOOL isRightButton, BOOL isDoubleClick) {
  INPUT buffer[1];
  buffer->type = INPUT_MOUSE;
  buffer->mi.dx = (0 * (0xFFFF / SCREEN_WIDTH));
  buffer->mi.dy = (0 * (0xFFFF / SCREEN_HEIGHT));
  buffer->mi.mouseData = 0;
  buffer->mi.dwFlags = MOUSEEVENTF_ABSOLUTE;
  buffer->mi.time = 0;
  buffer->mi.dwExtraInfo = 0;
  buffer->mi.dx = (x * (0xFFFF / SCREEN_WIDTH));
  buffer->mi.dy = (y * (0xFFFF / SCREEN_HEIGHT));
  buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE);
  SendInput(1, buffer, sizeof(INPUT));
  // Click
  if (isRightButton)
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTDOWN);
  else
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN);

  SendInput(1, buffer, sizeof(INPUT));
  Sleep(10);
  if (isRightButton)
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTUP);
  else
    buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP);
  SendInput(1, buffer, sizeof(INPUT));
  Sleep(10);
  if (isDoubleClick) {
    // Click
    if (isRightButton)
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTDOWN);
    else
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN);
    SendInput(1, buffer, sizeof(INPUT));
    Sleep(10);
    if (isRightButton)
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTUP);
    else
      buffer->mi.dwFlags = (MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP);
    SendInput(1, buffer, sizeof(INPUT));
  }
}

void _PixelColor(Color *color, int x, int y) {
  HDC hdc = GetDC(NULL);
  if (!hdc) {
    printf("Can't get dc");
    return;
  }
  COLORREF c = GetPixel(hdc, x, y);
  color->r = GetRValue(c);
  color->g = GetGValue(c);
  color->b = GetBValue(c);
  ReleaseDC(NULL, hdc);
}

void _PixelSearchColor(POINT *p, int left, int top, int right, int bottom,
                       BYTE r, BYTE g, BYTE b) {
  //
  HDC hdc = GetDC(NULL);
  if (!hdc) {
    printf("Can't get dc");
    return;
  }
  for (int x = left; x <= right; x++) {
    for (int y = top; y <= bottom; y++) {
      COLORREF c = GetPixel(hdc, x, y);
      if (GetRValue(c) == r && GetGValue(c) == g && GetBValue(c) == b) {
        p->x = x;
        p->y = y;
        return;
      }
    }
  }
  ReleaseDC(NULL, hdc);
}

void _SendKeyBackground(HWND hWnd, WORD wVk) {
  PostMessageW(hWnd, WM_KEYDOWN, wVk, 0);
  Sleep(100);
  PostMessageW(hWnd, WM_KEYUP, wVk, 0);
}
void _SendKeyWithAlt(HWND hWnd, UINT vk) {
  PostMessage(hWnd, WM_SYSKEYDOWN, 0x12, 0x60380001);
  PostMessage(hWnd, WM_SYSKEYUP, 0x12, 0xC0380001);
  PostMessage(hWnd, WM_SYSKEYDOWN, 0x12, 0x60380001);
  PostMessage(hWnd, WM_SYSKEYDOWN, vk, 0);
  Sleep(50);
  PostMessage(hWnd, WM_SYSKEYUP, vk, 0);
  PostMessage(hWnd, WM_SYSKEYUP, 0x12, 0xC0380001);
}
#endif  // KEY_H
