﻿namespace Helpers
{
    partial class mainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.程序 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.保存 = new System.Windows.Forms.ToolStripMenuItem();
            this.翻译ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.代码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.标题2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.粘贴为代码块ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.格式化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新建 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.置顶Button = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.顶端 = new System.Windows.Forms.ToolStripButton();
            this.底端 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.findBox = new System.Windows.Forms.ToolStripComboBox();
            this.replaceBox = new System.Windows.Forms.ToolStripComboBox();
            this.查找 = new System.Windows.Forms.ToolStripSplitButton();
            this.保留正则表达式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.保留行正则表达式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.刷选行正则表达式ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.替换所选内容ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.中文 = new System.Windows.Forms.ToolStripButton();
            this.翻译 = new System.Windows.Forms.ToolStripButton();
            this.删除 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.格式化 = new System.Windows.Forms.ToolStripSplitButton();
            this.换行符ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.排序ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.插入元数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.插入元数据 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.UL = new System.Windows.Forms.ToolStripButton();
            this.图片 = new System.Windows.Forms.ToolStripButton();
            this.斜体 = new System.Windows.Forms.ToolStripButton();
            this.标题 = new System.Windows.Forms.ToolStripButton();
            this.粗体 = new System.Windows.Forms.ToolStripButton();
            this.代码 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.Markdowns = new System.Windows.Forms.ToolStripButton();
            this.HTMLS = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.StringBuilderButton = new System.Windows.Forms.ToolStripSplitButton();
            this.文件到数组ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.格式化成一行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.随机字符串ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.字符串到数组ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.字符串到字节数组多行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.字符串到数组简单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.其他 = new System.Windows.Forms.ToolStripSplitButton();
            this.执行命令无窗口ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.文件SHA1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.格式化C代码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.JavaScript = new System.Windows.Forms.ToolStripSplitButton();
            this.逃逸JavaScriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.逃逸JavaScript数组ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩JavaScriptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.javaScript模板ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩HTMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSplitButton3 = new System.Windows.Forms.ToolStripSplitButton();
            this.排序ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.listBox = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.导出全部ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导入文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导出文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseBox = new System.Windows.Forms.ComboBox();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.压缩 = new System.Windows.Forms.ToolStripSplitButton();
            this.压缩目录加密ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩子目录加密ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.解压子目录加密ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.压缩CSharp目录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩子目录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩单个文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.压缩IntellijAndroidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.模拟 = new System.Windows.Forms.ToolStripSplitButton();
            this.获取当前鼠标坐标ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.获取当前鼠标窗口句柄ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.模拟上传百度云ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.图片Button = new System.Windows.Forms.ToolStripSplitButton();
            this.qRDecoderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Safari = new System.Windows.Forms.ToolStripSplitButton();
            this.创建文件夹ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.创建目录ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.离线文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.转换成HTM文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.下载图片ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成未下载文件列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成未下载文件列表imagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.创建EpubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.整理Epub文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.整理Mobi文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pdfToTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.服务器 = new System.Windows.Forms.ToolStripSplitButton();
            this.插入新文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.更新文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.textBox = new System.Windows.Forms.TextBox();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.复制ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.剪切ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.复制表格ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.粘贴ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.粘贴代码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.粘贴格式化源代码ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.h1Button = new System.Windows.Forms.ToolStripButton();
            this.H2 = new System.Windows.Forms.ToolStripButton();
            this.H3 = new System.Windows.Forms.ToolStripButton();
            this.H4 = new System.Windows.Forms.ToolStripButton();
            this.目录 = new System.Windows.Forms.ToolStripButton();
            this.置顶 = new System.Windows.Forms.ToolStripSeparator();
            this.formatButton = new System.Windows.Forms.ToolStripButton();
            this.粘贴格式 = new System.Windows.Forms.ToolStripButton();
            this.粘贴代码 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.CookBook = new System.Windows.Forms.ToolStripSplitButton();
            this.programmingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSplitButton2 = new System.Windows.Forms.ToolStripSplitButton();
            this.提取链接列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.词典 = new System.Windows.Forms.ToolStripSplitButton();
            this.导入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.检查词典数据库完整性ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导入文件夹ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导入文件夹MerriamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.转化为Kindle字典ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.转化为Kindle字典MerriamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.codeSplitButton = new System.Windows.Forms.ToolStripSplitButton();
            this.删除偶数行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.contextMenuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.程序,
            this.toolStripSplitButton1,
            this.新建,
            this.toolStripSeparator9,
            this.置顶Button,
            this.toolStripSeparator10,
            this.顶端,
            this.底端});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1460, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // 程序
            // 
            this.程序.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.程序.Image = ((System.Drawing.Image)(resources.GetObject("程序.Image")));
            this.程序.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.程序.Name = "程序";
            this.程序.Size = new System.Drawing.Size(23, 22);
            this.程序.Text = "程序";
            this.程序.Click += new System.EventHandler(this.程序_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.保存,
            this.翻译ToolStripMenuItem,
            this.删除ToolStripMenuItem,
            this.代码ToolStripMenuItem,
            this.标题2ToolStripMenuItem,
            this.粘贴为代码块ToolStripMenuItem,
            this.格式化ToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            // 
            // 保存
            // 
            this.保存.Name = "保存";
            this.保存.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.保存.Size = new System.Drawing.Size(169, 22);
            this.保存.Text = "保存";
            this.保存.Click += new System.EventHandler(this.保存_Click);
            // 
            // 翻译ToolStripMenuItem
            // 
            this.翻译ToolStripMenuItem.Name = "翻译ToolStripMenuItem";
            this.翻译ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.翻译ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.翻译ToolStripMenuItem.Text = "翻译";
            this.翻译ToolStripMenuItem.Click += new System.EventHandler(this.翻译_Click);
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.删除ToolStripMenuItem.Text = "删除";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除_Click);
            // 
            // 代码ToolStripMenuItem
            // 
            this.代码ToolStripMenuItem.Name = "代码ToolStripMenuItem";
            this.代码ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
            this.代码ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.代码ToolStripMenuItem.Text = "代码";
            this.代码ToolStripMenuItem.Click += new System.EventHandler(this.代码_Click);
            // 
            // 标题2ToolStripMenuItem
            // 
            this.标题2ToolStripMenuItem.Name = "标题2ToolStripMenuItem";
            this.标题2ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.标题2ToolStripMenuItem.Text = "标题2";
            this.标题2ToolStripMenuItem.Click += new System.EventHandler(this.标题2ToolStripMenuItem_Click);
            // 
            // 粘贴为代码块ToolStripMenuItem
            // 
            this.粘贴为代码块ToolStripMenuItem.Name = "粘贴为代码块ToolStripMenuItem";
            this.粘贴为代码块ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.粘贴为代码块ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.粘贴为代码块ToolStripMenuItem.Text = "粘贴为代码块";
            this.粘贴为代码块ToolStripMenuItem.Click += new System.EventHandler(this.粘贴为代码块ToolStripMenuItem_Click);
            // 
            // 格式化ToolStripMenuItem
            // 
            this.格式化ToolStripMenuItem.Name = "格式化ToolStripMenuItem";
            this.格式化ToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.格式化ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.格式化ToolStripMenuItem.Text = "格式化";
            this.格式化ToolStripMenuItem.Click += new System.EventHandler(this.格式化ToolStripMenuItem_Click);
            // 
            // 新建
            // 
            this.新建.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.新建.Image = ((System.Drawing.Image)(resources.GetObject("新建.Image")));
            this.新建.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.新建.Name = "新建";
            this.新建.Size = new System.Drawing.Size(36, 22);
            this.新建.Text = "新建";
            this.新建.Click += new System.EventHandler(this.新建_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // 置顶Button
            // 
            this.置顶Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.置顶Button.Image = ((System.Drawing.Image)(resources.GetObject("置顶Button.Image")));
            this.置顶Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.置顶Button.Name = "置顶Button";
            this.置顶Button.Size = new System.Drawing.Size(36, 22);
            this.置顶Button.Text = "置顶";
            this.置顶Button.Click += new System.EventHandler(this.置顶Button_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // 顶端
            // 
            this.顶端.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.顶端.Image = ((System.Drawing.Image)(resources.GetObject("顶端.Image")));
            this.顶端.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.顶端.Name = "顶端";
            this.顶端.Size = new System.Drawing.Size(36, 22);
            this.顶端.Text = "顶端";
            this.顶端.Click += new System.EventHandler(this.顶端_Click);
            // 
            // 底端
            // 
            this.底端.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.底端.Image = ((System.Drawing.Image)(resources.GetObject("底端.Image")));
            this.底端.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.底端.Name = "底端";
            this.底端.Size = new System.Drawing.Size(36, 22);
            this.底端.Text = "底端";
            this.底端.Click += new System.EventHandler(this.底端_Click);
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findBox,
            this.replaceBox,
            this.查找,
            this.toolStripSeparator1,
            this.中文,
            this.翻译,
            this.删除,
            this.toolStripSeparator6,
            this.格式化,
            this.插入元数据,
            this.toolStripSeparator2,
            this.UL,
            this.图片,
            this.斜体,
            this.标题,
            this.粗体,
            this.代码,
            this.toolStripSeparator3,
            this.Markdowns,
            this.HTMLS,
            this.toolStripSeparator4,
            this.StringBuilderButton,
            this.其他,
            this.JavaScript,
            this.toolStripSplitButton3});
            this.toolStrip2.Location = new System.Drawing.Point(0, 25);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(1460, 25);
            this.toolStrip2.TabIndex = 1;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // findBox
            // 
            this.findBox.Items.AddRange(new object[] {
            "public static [a-zA-Z0-9]+ [a-zA-Z0-9]+\\([^\\)]*?\\)",
            "(?<=public[^=(]*?)\\((?!this)",
            "([\\u4e00-\\u9fa5]+)",
            "(●[^\\n]*?)\\r?\\n"});
            this.findBox.Name = "findBox";
            this.findBox.Size = new System.Drawing.Size(250, 25);
            // 
            // replaceBox
            // 
            this.replaceBox.Items.AddRange(new object[] {
            "【$1】，",
            "**$1**\\n"});
            this.replaceBox.Name = "replaceBox";
            this.replaceBox.Size = new System.Drawing.Size(250, 25);
            // 
            // 查找
            // 
            this.查找.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.查找.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.保留正则表达式ToolStripMenuItem,
            this.保留行正则表达式ToolStripMenuItem,
            this.刷选行正则表达式ToolStripMenuItem,
            this.toolStripSeparator7,
            this.替换所选内容ToolStripMenuItem});
            this.查找.Image = ((System.Drawing.Image)(resources.GetObject("查找.Image")));
            this.查找.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.查找.Name = "查找";
            this.查找.Size = new System.Drawing.Size(48, 22);
            this.查找.Text = "查找";
            this.查找.ButtonClick += new System.EventHandler(this.查找_ButtonClick);
            // 
            // 保留正则表达式ToolStripMenuItem
            // 
            this.保留正则表达式ToolStripMenuItem.Name = "保留正则表达式ToolStripMenuItem";
            this.保留正则表达式ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.保留正则表达式ToolStripMenuItem.Text = "保留（正则表达式）";
            this.保留正则表达式ToolStripMenuItem.Click += new System.EventHandler(this.保留正则表达式ToolStripMenuItem_Click);
            // 
            // 保留行正则表达式ToolStripMenuItem
            // 
            this.保留行正则表达式ToolStripMenuItem.Name = "保留行正则表达式ToolStripMenuItem";
            this.保留行正则表达式ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.保留行正则表达式ToolStripMenuItem.Text = "保留行（正则表达式）";
            this.保留行正则表达式ToolStripMenuItem.Click += new System.EventHandler(this.保留行正则表达式ToolStripMenuItem_Click);
            // 
            // 刷选行正则表达式ToolStripMenuItem
            // 
            this.刷选行正则表达式ToolStripMenuItem.Name = "刷选行正则表达式ToolStripMenuItem";
            this.刷选行正则表达式ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.刷选行正则表达式ToolStripMenuItem.Text = "刷选行（正则表达式）";
            this.刷选行正则表达式ToolStripMenuItem.Click += new System.EventHandler(this.刷选行正则表达式ToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(193, 6);
            // 
            // 替换所选内容ToolStripMenuItem
            // 
            this.替换所选内容ToolStripMenuItem.Name = "替换所选内容ToolStripMenuItem";
            this.替换所选内容ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.替换所选内容ToolStripMenuItem.Text = "替换所选内容";
            this.替换所选内容ToolStripMenuItem.Click += new System.EventHandler(this.替换所选内容ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // 中文
            // 
            this.中文.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.中文.Image = ((System.Drawing.Image)(resources.GetObject("中文.Image")));
            this.中文.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.中文.Name = "中文";
            this.中文.Size = new System.Drawing.Size(36, 22);
            this.中文.Text = "中文";
            this.中文.Click += new System.EventHandler(this.中文_Click);
            // 
            // 翻译
            // 
            this.翻译.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.翻译.Image = ((System.Drawing.Image)(resources.GetObject("翻译.Image")));
            this.翻译.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.翻译.Name = "翻译";
            this.翻译.Size = new System.Drawing.Size(36, 22);
            this.翻译.Text = "翻译";
            this.翻译.Click += new System.EventHandler(this.翻译_Click);
            // 
            // 删除
            // 
            this.删除.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.删除.Image = ((System.Drawing.Image)(resources.GetObject("删除.Image")));
            this.删除.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.删除.Name = "删除";
            this.删除.Size = new System.Drawing.Size(36, 22);
            this.删除.Text = "删除";
            this.删除.Click += new System.EventHandler(this.删除_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // 格式化
            // 
            this.格式化.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.格式化.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.换行符ToolStripMenuItem,
            this.排序ToolStripMenuItem,
            this.插入元数据ToolStripMenuItem});
            this.格式化.Image = ((System.Drawing.Image)(resources.GetObject("格式化.Image")));
            this.格式化.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.格式化.Name = "格式化";
            this.格式化.Size = new System.Drawing.Size(60, 22);
            this.格式化.Text = "格式化";
            this.格式化.ButtonClick += new System.EventHandler(this.格式化_ButtonClick);
            // 
            // 换行符ToolStripMenuItem
            // 
            this.换行符ToolStripMenuItem.Name = "换行符ToolStripMenuItem";
            this.换行符ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.换行符ToolStripMenuItem.Text = "换行符";
            this.换行符ToolStripMenuItem.Click += new System.EventHandler(this.格式化换行符ToolStripMenuItem_Click);
            // 
            // 排序ToolStripMenuItem
            // 
            this.排序ToolStripMenuItem.Name = "排序ToolStripMenuItem";
            this.排序ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.排序ToolStripMenuItem.Text = "排序";
            this.排序ToolStripMenuItem.Click += new System.EventHandler(this.排序ToolStripMenuItem_Click);
            // 
            // 插入元数据ToolStripMenuItem
            // 
            this.插入元数据ToolStripMenuItem.Name = "插入元数据ToolStripMenuItem";
            this.插入元数据ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.插入元数据ToolStripMenuItem.Text = "插入元数据";
            this.插入元数据ToolStripMenuItem.Click += new System.EventHandler(this.插入元数据ToolStripMenuItem_Click);
            // 
            // 插入元数据
            // 
            this.插入元数据.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.插入元数据.Image = ((System.Drawing.Image)(resources.GetObject("插入元数据.Image")));
            this.插入元数据.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.插入元数据.Name = "插入元数据";
            this.插入元数据.Size = new System.Drawing.Size(72, 22);
            this.插入元数据.Text = "插入元数据";
            this.插入元数据.Click += new System.EventHandler(this.插入元数据ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // UL
            // 
            this.UL.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.UL.Image = ((System.Drawing.Image)(resources.GetObject("UL.Image")));
            this.UL.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.UL.Name = "UL";
            this.UL.Size = new System.Drawing.Size(27, 22);
            this.UL.Text = "UL";
            this.UL.Click += new System.EventHandler(this.UL_Click);
            // 
            // 图片
            // 
            this.图片.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.图片.Image = ((System.Drawing.Image)(resources.GetObject("图片.Image")));
            this.图片.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.图片.Name = "图片";
            this.图片.Size = new System.Drawing.Size(36, 22);
            this.图片.Text = "图片";
            this.图片.Click += new System.EventHandler(this.图片_Click);
            // 
            // 斜体
            // 
            this.斜体.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.斜体.Image = ((System.Drawing.Image)(resources.GetObject("斜体.Image")));
            this.斜体.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.斜体.Name = "斜体";
            this.斜体.Size = new System.Drawing.Size(36, 22);
            this.斜体.Text = "斜体";
            this.斜体.Click += new System.EventHandler(this.斜体_Click);
            // 
            // 标题
            // 
            this.标题.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.标题.Image = ((System.Drawing.Image)(resources.GetObject("标题.Image")));
            this.标题.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.标题.Name = "标题";
            this.标题.Size = new System.Drawing.Size(36, 22);
            this.标题.Text = "标题";
            this.标题.Click += new System.EventHandler(this.标题_Click);
            // 
            // 粗体
            // 
            this.粗体.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.粗体.Image = ((System.Drawing.Image)(resources.GetObject("粗体.Image")));
            this.粗体.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.粗体.Name = "粗体";
            this.粗体.Size = new System.Drawing.Size(36, 22);
            this.粗体.Text = "粗体";
            this.粗体.Click += new System.EventHandler(this.粗体_Click);
            // 
            // 代码
            // 
            this.代码.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.代码.Image = ((System.Drawing.Image)(resources.GetObject("代码.Image")));
            this.代码.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.代码.Name = "代码";
            this.代码.Size = new System.Drawing.Size(36, 22);
            this.代码.Text = "代码";
            this.代码.Click += new System.EventHandler(this.代码_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // Markdowns
            // 
            this.Markdowns.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Markdowns.Image = ((System.Drawing.Image)(resources.GetObject("Markdowns.Image")));
            this.Markdowns.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Markdowns.Name = "Markdowns";
            this.Markdowns.Size = new System.Drawing.Size(81, 22);
            this.Markdowns.Text = "Markdowns";
            this.Markdowns.Click += new System.EventHandler(this.Markdowns_Click);
            // 
            // HTMLS
            // 
            this.HTMLS.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.HTMLS.Image = ((System.Drawing.Image)(resources.GetObject("HTMLS.Image")));
            this.HTMLS.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.HTMLS.Name = "HTMLS";
            this.HTMLS.Size = new System.Drawing.Size(53, 22);
            this.HTMLS.Text = "HTMLS";
            this.HTMLS.Click += new System.EventHandler(this.HTMLS_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // StringBuilderButton
            // 
            this.StringBuilderButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StringBuilderButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件到数组ToolStripMenuItem,
            this.格式化成一行ToolStripMenuItem,
            this.随机字符串ToolStripMenuItem,
            this.字符串到数组ToolStripMenuItem,
            this.字符串到字节数组多行ToolStripMenuItem,
            this.字符串到数组简单ToolStripMenuItem});
            this.StringBuilderButton.Image = ((System.Drawing.Image)(resources.GetObject("StringBuilderButton.Image")));
            this.StringBuilderButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StringBuilderButton.Name = "StringBuilderButton";
            this.StringBuilderButton.Size = new System.Drawing.Size(99, 22);
            this.StringBuilderButton.Text = "StringBuilder";
            this.StringBuilderButton.ButtonClick += new System.EventHandler(this.StringBuilderButton_ButtonClick);
            // 
            // 文件到数组ToolStripMenuItem
            // 
            this.文件到数组ToolStripMenuItem.Name = "文件到数组ToolStripMenuItem";
            this.文件到数组ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.文件到数组ToolStripMenuItem.Text = "文件到数组";
            this.文件到数组ToolStripMenuItem.Click += new System.EventHandler(this.文件到数组ToolStripMenuItem_Click);
            // 
            // 格式化成一行ToolStripMenuItem
            // 
            this.格式化成一行ToolStripMenuItem.Name = "格式化成一行ToolStripMenuItem";
            this.格式化成一行ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.格式化成一行ToolStripMenuItem.Text = "格式化成一行";
            this.格式化成一行ToolStripMenuItem.Click += new System.EventHandler(this.格式化成一行ToolStripMenuItem_Click);
            // 
            // 随机字符串ToolStripMenuItem
            // 
            this.随机字符串ToolStripMenuItem.Name = "随机字符串ToolStripMenuItem";
            this.随机字符串ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.随机字符串ToolStripMenuItem.Text = "随机字符串";
            this.随机字符串ToolStripMenuItem.Click += new System.EventHandler(this.随机字符串ToolStripMenuItem_Click);
            // 
            // 字符串到数组ToolStripMenuItem
            // 
            this.字符串到数组ToolStripMenuItem.Name = "字符串到数组ToolStripMenuItem";
            this.字符串到数组ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.字符串到数组ToolStripMenuItem.Text = "字符串到字节数组";
            this.字符串到数组ToolStripMenuItem.Click += new System.EventHandler(this.字符串到数组ToolStripMenuItem_Click);
            // 
            // 字符串到字节数组多行ToolStripMenuItem
            // 
            this.字符串到字节数组多行ToolStripMenuItem.Name = "字符串到字节数组多行ToolStripMenuItem";
            this.字符串到字节数组多行ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.字符串到字节数组多行ToolStripMenuItem.Text = "字符串到字节数组（多行）";
            this.字符串到字节数组多行ToolStripMenuItem.Click += new System.EventHandler(this.字符串到字节数组多行ToolStripMenuItem_Click);
            // 
            // 字符串到数组简单ToolStripMenuItem
            // 
            this.字符串到数组简单ToolStripMenuItem.Name = "字符串到数组简单ToolStripMenuItem";
            this.字符串到数组简单ToolStripMenuItem.Size = new System.Drawing.Size(232, 22);
            this.字符串到数组简单ToolStripMenuItem.Text = "到数组（换行符，移除空行）";
            this.字符串到数组简单ToolStripMenuItem.Click += new System.EventHandler(this.字符串到数组简单ToolStripMenuItem_Click);
            // 
            // 其他
            // 
            this.其他.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.其他.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.执行命令无窗口ToolStripMenuItem,
            this.文件SHA1ToolStripMenuItem,
            this.格式化C代码ToolStripMenuItem});
            this.其他.Image = ((System.Drawing.Image)(resources.GetObject("其他.Image")));
            this.其他.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.其他.Name = "其他";
            this.其他.Size = new System.Drawing.Size(48, 22);
            this.其他.Text = "其他";
            // 
            // 执行命令无窗口ToolStripMenuItem
            // 
            this.执行命令无窗口ToolStripMenuItem.Name = "执行命令无窗口ToolStripMenuItem";
            this.执行命令无窗口ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.执行命令无窗口ToolStripMenuItem.Text = "执行命令(无窗口)";
            this.执行命令无窗口ToolStripMenuItem.Click += new System.EventHandler(this.执行命令无窗口ToolStripMenuItem_Click);
            // 
            // 文件SHA1ToolStripMenuItem
            // 
            this.文件SHA1ToolStripMenuItem.Name = "文件SHA1ToolStripMenuItem";
            this.文件SHA1ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.文件SHA1ToolStripMenuItem.Text = "文件SHA1";
            this.文件SHA1ToolStripMenuItem.Click += new System.EventHandler(this.文件SHA1ToolStripMenuItem_Click);
            // 
            // 格式化C代码ToolStripMenuItem
            // 
            this.格式化C代码ToolStripMenuItem.Name = "格式化C代码ToolStripMenuItem";
            this.格式化C代码ToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.格式化C代码ToolStripMenuItem.Text = "格式化C#代码";
            this.格式化C代码ToolStripMenuItem.Click += new System.EventHandler(this.格式化C代码ToolStripMenuItem_Click);
            // 
            // JavaScript
            // 
            this.JavaScript.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.JavaScript.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.逃逸JavaScriptToolStripMenuItem,
            this.逃逸JavaScript数组ToolStripMenuItem,
            this.压缩JavaScriptToolStripMenuItem,
            this.javaScript模板ToolStripMenuItem,
            this.压缩HTMToolStripMenuItem});
            this.JavaScript.Image = ((System.Drawing.Image)(resources.GetObject("JavaScript.Image")));
            this.JavaScript.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.JavaScript.Name = "JavaScript";
            this.JavaScript.Size = new System.Drawing.Size(82, 22);
            this.JavaScript.Text = "JavaScript";
            // 
            // 逃逸JavaScriptToolStripMenuItem
            // 
            this.逃逸JavaScriptToolStripMenuItem.Name = "逃逸JavaScriptToolStripMenuItem";
            this.逃逸JavaScriptToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.逃逸JavaScriptToolStripMenuItem.Text = "逃逸JavaScript(移除换行符)";
            this.逃逸JavaScriptToolStripMenuItem.Click += new System.EventHandler(this.逃逸JavaScriptToolStripMenuItem_Click);
            // 
            // 逃逸JavaScript数组ToolStripMenuItem
            // 
            this.逃逸JavaScript数组ToolStripMenuItem.Name = "逃逸JavaScript数组ToolStripMenuItem";
            this.逃逸JavaScript数组ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.逃逸JavaScript数组ToolStripMenuItem.Text = "逃逸JavaScript数组";
            this.逃逸JavaScript数组ToolStripMenuItem.Click += new System.EventHandler(this.逃逸JavaScript数组ToolStripMenuItem_Click);
            // 
            // 压缩JavaScriptToolStripMenuItem
            // 
            this.压缩JavaScriptToolStripMenuItem.Name = "压缩JavaScriptToolStripMenuItem";
            this.压缩JavaScriptToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.压缩JavaScriptToolStripMenuItem.Text = "压缩JavaScript（文件）";
            this.压缩JavaScriptToolStripMenuItem.Click += new System.EventHandler(this.压缩JavaScriptToolStripMenuItem_Click);
            // 
            // javaScript模板ToolStripMenuItem
            // 
            this.javaScript模板ToolStripMenuItem.Name = "javaScript模板ToolStripMenuItem";
            this.javaScript模板ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.javaScript模板ToolStripMenuItem.Text = "JavaScript 模板";
            this.javaScript模板ToolStripMenuItem.Click += new System.EventHandler(this.javaScript模板ToolStripMenuItem_Click);
            // 
            // 压缩HTMToolStripMenuItem
            // 
            this.压缩HTMToolStripMenuItem.Name = "压缩HTMToolStripMenuItem";
            this.压缩HTMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.压缩HTMToolStripMenuItem.Text = "压缩HTM";
            this.压缩HTMToolStripMenuItem.Click += new System.EventHandler(this.压缩HTMToolStripMenuItem_Click);
            // 
            // toolStripSplitButton3
            // 
            this.toolStripSplitButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.排序ToolStripMenuItem1});
            this.toolStripSplitButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton3.Image")));
            this.toolStripSplitButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton3.Name = "toolStripSplitButton3";
            this.toolStripSplitButton3.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton3.Text = "toolStripSplitButton3";
            // 
            // 排序ToolStripMenuItem1
            // 
            this.排序ToolStripMenuItem1.Name = "排序ToolStripMenuItem1";
            this.排序ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.排序ToolStripMenuItem1.Text = "排序";
            this.排序ToolStripMenuItem1.Click += new System.EventHandler(this.排序ToolStripMenuItem1_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 50);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.listBox);
            this.splitContainer1.Panel1.Controls.Add(this.databaseBox);
            this.splitContainer1.Panel1.Controls.Add(this.toolStrip3);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textBox);
            this.splitContainer1.Panel2.Controls.Add(this.toolStrip);
            this.splitContainer1.Size = new System.Drawing.Size(1460, 607);
            this.splitContainer1.SplitterDistance = 407;
            this.splitContainer1.TabIndex = 2;
            // 
            // listBox
            // 
            this.listBox.ContextMenuStrip = this.contextMenuStrip1;
            this.listBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 12;
            this.listBox.Location = new System.Drawing.Point(0, 45);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(407, 562);
            this.listBox.TabIndex = 1;
            this.listBox.DoubleClick += new System.EventHandler(this.listBox_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.导出全部ToolStripMenuItem,
            this.导入文件ToolStripMenuItem,
            this.导出文件ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 70);
            // 
            // 导出全部ToolStripMenuItem
            // 
            this.导出全部ToolStripMenuItem.Name = "导出全部ToolStripMenuItem";
            this.导出全部ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.导出全部ToolStripMenuItem.Text = "导出全部";
            this.导出全部ToolStripMenuItem.Click += new System.EventHandler(this.导出全部ToolStripMenuItem_Click);
            // 
            // 导入文件ToolStripMenuItem
            // 
            this.导入文件ToolStripMenuItem.Name = "导入文件ToolStripMenuItem";
            this.导入文件ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.导入文件ToolStripMenuItem.Text = "导入文件";
            this.导入文件ToolStripMenuItem.Click += new System.EventHandler(this.导入文件ToolStripMenuItem_Click);
            // 
            // 导出文件ToolStripMenuItem
            // 
            this.导出文件ToolStripMenuItem.Name = "导出文件ToolStripMenuItem";
            this.导出文件ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.导出文件ToolStripMenuItem.Text = "导出文件";
            this.导出文件ToolStripMenuItem.Click += new System.EventHandler(this.导出文件ToolStripMenuItem_Click);
            // 
            // databaseBox
            // 
            this.databaseBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.databaseBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.databaseBox.FormattingEnabled = true;
            this.databaseBox.Location = new System.Drawing.Point(0, 25);
            this.databaseBox.Name = "databaseBox";
            this.databaseBox.Size = new System.Drawing.Size(407, 20);
            this.databaseBox.TabIndex = 0;
            this.databaseBox.SelectedIndexChanged += new System.EventHandler(this.databaseBox_SelectedIndexChanged);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.压缩,
            this.模拟,
            this.图片Button,
            this.Safari,
            this.服务器});
            this.toolStrip3.Location = new System.Drawing.Point(0, 0);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(407, 25);
            this.toolStrip3.TabIndex = 2;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // 压缩
            // 
            this.压缩.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.压缩.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.压缩目录加密ToolStripMenuItem,
            this.压缩子目录加密ToolStripMenuItem,
            this.解压子目录加密ToolStripMenuItem,
            this.toolStripSeparator11,
            this.压缩CSharp目录ToolStripMenuItem,
            this.压缩子目录ToolStripMenuItem,
            this.压缩单个文件ToolStripMenuItem,
            this.压缩IntellijAndroidToolStripMenuItem});
            this.压缩.Image = ((System.Drawing.Image)(resources.GetObject("压缩.Image")));
            this.压缩.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.压缩.Name = "压缩";
            this.压缩.Size = new System.Drawing.Size(48, 22);
            this.压缩.Text = "压缩";
            // 
            // 压缩目录加密ToolStripMenuItem
            // 
            this.压缩目录加密ToolStripMenuItem.Name = "压缩目录加密ToolStripMenuItem";
            this.压缩目录加密ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.压缩目录加密ToolStripMenuItem.Text = "压缩目录（加密）";
            this.压缩目录加密ToolStripMenuItem.Click += new System.EventHandler(this.压缩目录加密ToolStripMenuItem_Click);
            // 
            // 压缩子目录加密ToolStripMenuItem
            // 
            this.压缩子目录加密ToolStripMenuItem.Name = "压缩子目录加密ToolStripMenuItem";
            this.压缩子目录加密ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.压缩子目录加密ToolStripMenuItem.Text = "压缩子目录（加密）";
            this.压缩子目录加密ToolStripMenuItem.Click += new System.EventHandler(this.压缩子目录加密ToolStripMenuItem_Click);
            // 
            // 解压子目录加密ToolStripMenuItem
            // 
            this.解压子目录加密ToolStripMenuItem.Name = "解压子目录加密ToolStripMenuItem";
            this.解压子目录加密ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.解压子目录加密ToolStripMenuItem.Text = "解压子目录（加密）";
            this.解压子目录加密ToolStripMenuItem.Click += new System.EventHandler(this.解压子目录加密ToolStripMenuItem_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(182, 6);
            // 
            // 压缩CSharp目录ToolStripMenuItem
            // 
            this.压缩CSharp目录ToolStripMenuItem.Name = "压缩CSharp目录ToolStripMenuItem";
            this.压缩CSharp目录ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.压缩CSharp目录ToolStripMenuItem.Text = "压缩CSharp目录";
            this.压缩CSharp目录ToolStripMenuItem.Click += new System.EventHandler(this.压缩CSharp目录加密ToolStripMenuItem_Click);
            // 
            // 压缩子目录ToolStripMenuItem
            // 
            this.压缩子目录ToolStripMenuItem.Name = "压缩子目录ToolStripMenuItem";
            this.压缩子目录ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.压缩子目录ToolStripMenuItem.Text = "压缩子目录";
            this.压缩子目录ToolStripMenuItem.Click += new System.EventHandler(this.压缩子目录ToolStripMenuItem_Click);
            // 
            // 压缩单个文件ToolStripMenuItem
            // 
            this.压缩单个文件ToolStripMenuItem.Name = "压缩单个文件ToolStripMenuItem";
            this.压缩单个文件ToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.压缩单个文件ToolStripMenuItem.Text = "压缩单个文件";
            this.压缩单个文件ToolStripMenuItem.Click += new System.EventHandler(this.压缩单个文件ToolStripMenuItem_Click);
            // 
            // 压缩IntellijAndroidToolStripMenuItem
            // 
            this.压缩IntellijAndroidToolStripMenuItem.Name = "压缩IntellijAndroidToolStripMenuItem";
            this.压缩IntellijAndroidToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.压缩IntellijAndroidToolStripMenuItem.Text = "压缩Intellij Android";
            this.压缩IntellijAndroidToolStripMenuItem.Click += new System.EventHandler(this.压缩IntellijAndroidToolStripMenuItem_Click);
            // 
            // 模拟
            // 
            this.模拟.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.模拟.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.获取当前鼠标坐标ToolStripMenuItem,
            this.获取当前鼠标窗口句柄ToolStripMenuItem,
            this.模拟上传百度云ToolStripMenuItem});
            this.模拟.Image = ((System.Drawing.Image)(resources.GetObject("模拟.Image")));
            this.模拟.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.模拟.Name = "模拟";
            this.模拟.Size = new System.Drawing.Size(48, 22);
            this.模拟.Text = "模拟";
            // 
            // 获取当前鼠标坐标ToolStripMenuItem
            // 
            this.获取当前鼠标坐标ToolStripMenuItem.Name = "获取当前鼠标坐标ToolStripMenuItem";
            this.获取当前鼠标坐标ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.获取当前鼠标坐标ToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.获取当前鼠标坐标ToolStripMenuItem.Text = "获取当前鼠标坐标";
            this.获取当前鼠标坐标ToolStripMenuItem.Click += new System.EventHandler(this.获取当前鼠标坐标ToolStripMenuItem_Click);
            // 
            // 获取当前鼠标窗口句柄ToolStripMenuItem
            // 
            this.获取当前鼠标窗口句柄ToolStripMenuItem.Name = "获取当前鼠标窗口句柄ToolStripMenuItem";
            this.获取当前鼠标窗口句柄ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D2)));
            this.获取当前鼠标窗口句柄ToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.获取当前鼠标窗口句柄ToolStripMenuItem.Text = "获取当前鼠标窗口句柄";
            this.获取当前鼠标窗口句柄ToolStripMenuItem.Click += new System.EventHandler(this.获取当前鼠标窗口句柄ToolStripMenuItem_Click);
            // 
            // 模拟上传百度云ToolStripMenuItem
            // 
            this.模拟上传百度云ToolStripMenuItem.Name = "模拟上传百度云ToolStripMenuItem";
            this.模拟上传百度云ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D3)));
            this.模拟上传百度云ToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.模拟上传百度云ToolStripMenuItem.Text = "模拟上传百度云";
            this.模拟上传百度云ToolStripMenuItem.Click += new System.EventHandler(this.模拟上传百度云ToolStripMenuItem_Click);
            // 
            // 图片Button
            // 
            this.图片Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.图片Button.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.qRDecoderToolStripMenuItem});
            this.图片Button.Image = ((System.Drawing.Image)(resources.GetObject("图片Button.Image")));
            this.图片Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.图片Button.Name = "图片Button";
            this.图片Button.Size = new System.Drawing.Size(48, 22);
            this.图片Button.Text = "图片";
            // 
            // qRDecoderToolStripMenuItem
            // 
            this.qRDecoderToolStripMenuItem.Name = "qRDecoderToolStripMenuItem";
            this.qRDecoderToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.qRDecoderToolStripMenuItem.Text = "QRDecoder";
            this.qRDecoderToolStripMenuItem.Click += new System.EventHandler(this.qRDecoderToolStripMenuItem_Click);
            // 
            // Safari
            // 
            this.Safari.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Safari.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.创建文件夹ToolStripMenuItem,
            this.创建目录ToolStripMenuItem,
            this.离线文档ToolStripMenuItem,
            this.转换成HTM文档ToolStripMenuItem,
            this.下载图片ToolStripMenuItem,
            this.生成未下载文件列表ToolStripMenuItem,
            this.生成未下载文件列表imagesToolStripMenuItem,
            this.创建EpubToolStripMenuItem,
            this.toolStripSeparator16,
            this.整理Epub文件ToolStripMenuItem,
            this.整理Mobi文件ToolStripMenuItem,
            this.pdfToTextToolStripMenuItem});
            this.Safari.Image = ((System.Drawing.Image)(resources.GetObject("Safari.Image")));
            this.Safari.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Safari.Name = "Safari";
            this.Safari.Size = new System.Drawing.Size(57, 22);
            this.Safari.Text = "Safari";
            // 
            // 创建文件夹ToolStripMenuItem
            // 
            this.创建文件夹ToolStripMenuItem.Name = "创建文件夹ToolStripMenuItem";
            this.创建文件夹ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.创建文件夹ToolStripMenuItem.Text = "创建文件夹";
            this.创建文件夹ToolStripMenuItem.Click += new System.EventHandler(this.创建文件夹ToolStripMenuItem_Click);
            // 
            // 创建目录ToolStripMenuItem
            // 
            this.创建目录ToolStripMenuItem.Name = "创建目录ToolStripMenuItem";
            this.创建目录ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.创建目录ToolStripMenuItem.Text = "创建目录";
            this.创建目录ToolStripMenuItem.Click += new System.EventHandler(this.创建目录ToolStripMenuItem_Click);
            // 
            // 离线文档ToolStripMenuItem
            // 
            this.离线文档ToolStripMenuItem.Name = "离线文档ToolStripMenuItem";
            this.离线文档ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.离线文档ToolStripMenuItem.Text = "离线文档";
            this.离线文档ToolStripMenuItem.Click += new System.EventHandler(this.离线文档ToolStripMenuItem_Click);
            // 
            // 转换成HTM文档ToolStripMenuItem
            // 
            this.转换成HTM文档ToolStripMenuItem.Name = "转换成HTM文档ToolStripMenuItem";
            this.转换成HTM文档ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.转换成HTM文档ToolStripMenuItem.Text = "转换成HTM文档";
            this.转换成HTM文档ToolStripMenuItem.Click += new System.EventHandler(this.转换成HTM文档ToolStripMenuItem_Click);
            // 
            // 下载图片ToolStripMenuItem
            // 
            this.下载图片ToolStripMenuItem.Name = "下载图片ToolStripMenuItem";
            this.下载图片ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.下载图片ToolStripMenuItem.Text = "下载图片";
            this.下载图片ToolStripMenuItem.Click += new System.EventHandler(this.下载图片ToolStripMenuItem_Click);
            // 
            // 生成未下载文件列表ToolStripMenuItem
            // 
            this.生成未下载文件列表ToolStripMenuItem.Name = "生成未下载文件列表ToolStripMenuItem";
            this.生成未下载文件列表ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.生成未下载文件列表ToolStripMenuItem.Text = "生成未下载文件列表（links）";
            this.生成未下载文件列表ToolStripMenuItem.Click += new System.EventHandler(this.生成未下载文件列表ToolStripMenuItem_Click);
            // 
            // 生成未下载文件列表imagesToolStripMenuItem
            // 
            this.生成未下载文件列表imagesToolStripMenuItem.Name = "生成未下载文件列表imagesToolStripMenuItem";
            this.生成未下载文件列表imagesToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.生成未下载文件列表imagesToolStripMenuItem.Text = "生成未下载文件列表（images）";
            this.生成未下载文件列表imagesToolStripMenuItem.Click += new System.EventHandler(this.生成未下载文件列表imagesToolStripMenuItem_Click);
            // 
            // 创建EpubToolStripMenuItem
            // 
            this.创建EpubToolStripMenuItem.Name = "创建EpubToolStripMenuItem";
            this.创建EpubToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.创建EpubToolStripMenuItem.Text = "创建Epub";
            this.创建EpubToolStripMenuItem.Click += new System.EventHandler(this.创建EpubToolStripMenuItem_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(247, 6);
            // 
            // 整理Epub文件ToolStripMenuItem
            // 
            this.整理Epub文件ToolStripMenuItem.Name = "整理Epub文件ToolStripMenuItem";
            this.整理Epub文件ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.整理Epub文件ToolStripMenuItem.Text = "整理Epub文件";
            this.整理Epub文件ToolStripMenuItem.Click += new System.EventHandler(this.整理Epub文件ToolStripMenuItem_Click);
            // 
            // 整理Mobi文件ToolStripMenuItem
            // 
            this.整理Mobi文件ToolStripMenuItem.Name = "整理Mobi文件ToolStripMenuItem";
            this.整理Mobi文件ToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.整理Mobi文件ToolStripMenuItem.Text = "整理Mobi文件";
            this.整理Mobi文件ToolStripMenuItem.Click += new System.EventHandler(this.整理Mobi文件ToolStripMenuItem_Click);
            // 
            // pdfToTextToolStripMenuItem
            // 
            this.pdfToTextToolStripMenuItem.Name = "pdfToTextToolStripMenuItem";
            this.pdfToTextToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.pdfToTextToolStripMenuItem.Text = "Pdf to Text";
            this.pdfToTextToolStripMenuItem.Click += new System.EventHandler(this.pdfToTextToolStripMenuItem_Click);
            // 
            // 服务器
            // 
            this.服务器.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.服务器.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.插入新文档ToolStripMenuItem,
            this.更新文档ToolStripMenuItem,
            this.删除文档ToolStripMenuItem,
            this.toolStripSeparator12,
            this.toolStripSeparator13});
            this.服务器.Image = ((System.Drawing.Image)(resources.GetObject("服务器.Image")));
            this.服务器.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.服务器.Name = "服务器";
            this.服务器.Size = new System.Drawing.Size(60, 22);
            this.服务器.Text = "服务器";
            // 
            // 插入新文档ToolStripMenuItem
            // 
            this.插入新文档ToolStripMenuItem.Name = "插入新文档ToolStripMenuItem";
            this.插入新文档ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.插入新文档ToolStripMenuItem.Text = "插入新文档";
            this.插入新文档ToolStripMenuItem.Click += new System.EventHandler(this.插入新文档ToolStripMenuItem_Click);
            // 
            // 更新文档ToolStripMenuItem
            // 
            this.更新文档ToolStripMenuItem.Name = "更新文档ToolStripMenuItem";
            this.更新文档ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.更新文档ToolStripMenuItem.Text = "更新文档";
            this.更新文档ToolStripMenuItem.Click += new System.EventHandler(this.更新文档ToolStripMenuItem_Click);
            // 
            // 删除文档ToolStripMenuItem
            // 
            this.删除文档ToolStripMenuItem.Name = "删除文档ToolStripMenuItem";
            this.删除文档ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.删除文档ToolStripMenuItem.Text = "删除文档";
            this.删除文档ToolStripMenuItem.Click += new System.EventHandler(this.删除文档ToolStripMenuItem_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(133, 6);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(133, 6);
            // 
            // textBox
            // 
            this.textBox.AcceptsTab = true;
            this.textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox.ContextMenuStrip = this.contextMenuStrip;
            this.textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox.Location = new System.Drawing.Point(0, 25);
            this.textBox.MaxLength = 32767000;
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox.Size = new System.Drawing.Size(1049, 582);
            this.textBox.TabIndex = 0;
            this.textBox.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            this.textBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.复制ToolStripMenuItem,
            this.剪切ToolStripMenuItem,
            this.toolStripSeparator8,
            this.复制表格ToolStripMenuItem,
            this.粘贴ToolStripMenuItem,
            this.toolStripSeparator5,
            this.粘贴代码ToolStripMenuItem,
            this.粘贴格式化源代码ToolStripMenuItem,
            this.删除偶数行ToolStripMenuItem});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(197, 192);
            // 
            // 复制ToolStripMenuItem
            // 
            this.复制ToolStripMenuItem.Name = "复制ToolStripMenuItem";
            this.复制ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.复制ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.复制ToolStripMenuItem.Text = "复制";
            this.复制ToolStripMenuItem.Click += new System.EventHandler(this.复制ToolStripMenuItem_Click);
            // 
            // 剪切ToolStripMenuItem
            // 
            this.剪切ToolStripMenuItem.Name = "剪切ToolStripMenuItem";
            this.剪切ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.剪切ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.剪切ToolStripMenuItem.Text = "剪切";
            this.剪切ToolStripMenuItem.Click += new System.EventHandler(this.剪切ToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(193, 6);
            // 
            // 复制表格ToolStripMenuItem
            // 
            this.复制表格ToolStripMenuItem.Name = "复制表格ToolStripMenuItem";
            this.复制表格ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.复制表格ToolStripMenuItem.Text = "复制（表格）";
            this.复制表格ToolStripMenuItem.Click += new System.EventHandler(this.复制表格ToolStripMenuItem_Click);
            // 
            // 粘贴ToolStripMenuItem
            // 
            this.粘贴ToolStripMenuItem.Name = "粘贴ToolStripMenuItem";
            this.粘贴ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.粘贴ToolStripMenuItem.Text = "粘贴";
            this.粘贴ToolStripMenuItem.Click += new System.EventHandler(this.粘贴ToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(193, 6);
            // 
            // 粘贴代码ToolStripMenuItem
            // 
            this.粘贴代码ToolStripMenuItem.Name = "粘贴代码ToolStripMenuItem";
            this.粘贴代码ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.粘贴代码ToolStripMenuItem.Text = "粘贴（代码）";
            this.粘贴代码ToolStripMenuItem.Click += new System.EventHandler(this.粘贴代码ToolStripMenuItem_Click);
            // 
            // 粘贴格式化源代码ToolStripMenuItem
            // 
            this.粘贴格式化源代码ToolStripMenuItem.Name = "粘贴格式化源代码ToolStripMenuItem";
            this.粘贴格式化源代码ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.粘贴格式化源代码ToolStripMenuItem.Text = "粘贴（格式化源代码）";
            this.粘贴格式化源代码ToolStripMenuItem.Click += new System.EventHandler(this.粘贴格式化源代码ToolStripMenuItem_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.h1Button,
            this.H2,
            this.H3,
            this.H4,
            this.目录,
            this.置顶,
            this.formatButton,
            this.粘贴格式,
            this.粘贴代码,
            this.toolStripSeparator14,
            this.CookBook,
            this.toolStripSplitButton2,
            this.词典,
            this.toolStripButton1,
            this.codeSplitButton});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(1049, 25);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "toolStrip4";
            // 
            // h1Button
            // 
            this.h1Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.h1Button.Image = ((System.Drawing.Image)(resources.GetObject("h1Button.Image")));
            this.h1Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.h1Button.Name = "h1Button";
            this.h1Button.Size = new System.Drawing.Size(28, 22);
            this.h1Button.Text = "H1";
            this.h1Button.Click += new System.EventHandler(this.h1Button_Click);
            // 
            // H2
            // 
            this.H2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.H2.Image = ((System.Drawing.Image)(resources.GetObject("H2.Image")));
            this.H2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(28, 22);
            this.H2.Text = "H2";
            this.H2.Click += new System.EventHandler(this.H2_Click);
            // 
            // H3
            // 
            this.H3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.H3.Image = ((System.Drawing.Image)(resources.GetObject("H3.Image")));
            this.H3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(28, 22);
            this.H3.Text = "H3";
            this.H3.Click += new System.EventHandler(this.H3_Click);
            // 
            // H4
            // 
            this.H4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.H4.Image = ((System.Drawing.Image)(resources.GetObject("H4.Image")));
            this.H4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(28, 22);
            this.H4.Text = "H4";
            this.H4.Click += new System.EventHandler(this.H4_Click);
            // 
            // 目录
            // 
            this.目录.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.目录.Image = ((System.Drawing.Image)(resources.GetObject("目录.Image")));
            this.目录.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.目录.Name = "目录";
            this.目录.Size = new System.Drawing.Size(36, 22);
            this.目录.Text = "目录";
            this.目录.Click += new System.EventHandler(this.目录_Click);
            // 
            // 置顶
            // 
            this.置顶.Name = "置顶";
            this.置顶.Size = new System.Drawing.Size(6, 25);
            // 
            // formatButton
            // 
            this.formatButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.formatButton.Image = ((System.Drawing.Image)(resources.GetObject("formatButton.Image")));
            this.formatButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.formatButton.Name = "formatButton";
            this.formatButton.Size = new System.Drawing.Size(96, 22);
            this.formatButton.Text = "粘贴（格式化）";
            this.formatButton.Click += new System.EventHandler(this.formatButton_Click);
            // 
            // 粘贴格式
            // 
            this.粘贴格式.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.粘贴格式.Image = ((System.Drawing.Image)(resources.GetObject("粘贴格式.Image")));
            this.粘贴格式.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.粘贴格式.Name = "粘贴格式";
            this.粘贴格式.Size = new System.Drawing.Size(112, 22);
            this.粘贴格式.Text = "粘贴（格式HTM）";
            this.粘贴格式.Click += new System.EventHandler(this.粘贴格式_Click);
            // 
            // 粘贴代码
            // 
            this.粘贴代码.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.粘贴代码.Image = ((System.Drawing.Image)(resources.GetObject("粘贴代码.Image")));
            this.粘贴代码.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.粘贴代码.Name = "粘贴代码";
            this.粘贴代码.Size = new System.Drawing.Size(84, 22);
            this.粘贴代码.Text = "粘贴（代码）";
            this.粘贴代码.Click += new System.EventHandler(this.粘贴代码ToolStripMenuItem_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // CookBook
            // 
            this.CookBook.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.CookBook.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programmingToolStripMenuItem});
            this.CookBook.Image = ((System.Drawing.Image)(resources.GetObject("CookBook.Image")));
            this.CookBook.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CookBook.Name = "CookBook";
            this.CookBook.Size = new System.Drawing.Size(86, 22);
            this.CookBook.Text = "CookBook";
            this.CookBook.ButtonClick += new System.EventHandler(this.CookBook_ButtonClick);
            // 
            // programmingToolStripMenuItem
            // 
            this.programmingToolStripMenuItem.Name = "programmingToolStripMenuItem";
            this.programmingToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.programmingToolStripMenuItem.Text = "Programming";
            this.programmingToolStripMenuItem.Click += new System.EventHandler(this.programmingToolStripMenuItem_Click);
            // 
            // toolStripSplitButton2
            // 
            this.toolStripSplitButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.提取链接列表ToolStripMenuItem});
            this.toolStripSplitButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton2.Image")));
            this.toolStripSplitButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton2.Name = "toolStripSplitButton2";
            this.toolStripSplitButton2.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton2.Text = "toolStripSplitButton2";
            // 
            // 提取链接列表ToolStripMenuItem
            // 
            this.提取链接列表ToolStripMenuItem.Name = "提取链接列表ToolStripMenuItem";
            this.提取链接列表ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.提取链接列表ToolStripMenuItem.Text = "提取链接列表";
            this.提取链接列表ToolStripMenuItem.Click += new System.EventHandler(this.提取链接列表ToolStripMenuItem_Click);
            // 
            // 词典
            // 
            this.词典.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.词典.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.导入ToolStripMenuItem,
            this.检查词典数据库完整性ToolStripMenuItem,
            this.导入文件夹ToolStripMenuItem,
            this.导入文件夹MerriamToolStripMenuItem,
            this.toolStripSeparator15,
            this.转化为Kindle字典ToolStripMenuItem,
            this.转化为Kindle字典MerriamToolStripMenuItem});
            this.词典.Image = ((System.Drawing.Image)(resources.GetObject("词典.Image")));
            this.词典.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.词典.Name = "词典";
            this.词典.Size = new System.Drawing.Size(48, 22);
            this.词典.Text = "词典";
            this.词典.ButtonClick += new System.EventHandler(this.词典_Click);
            // 
            // 导入ToolStripMenuItem
            // 
            this.导入ToolStripMenuItem.Name = "导入ToolStripMenuItem";
            this.导入ToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.导入ToolStripMenuItem.Text = "导入";
            this.导入ToolStripMenuItem.Click += new System.EventHandler(this.导入ToolStripMenuItem_Click);
            // 
            // 检查词典数据库完整性ToolStripMenuItem
            // 
            this.检查词典数据库完整性ToolStripMenuItem.Name = "检查词典数据库完整性ToolStripMenuItem";
            this.检查词典数据库完整性ToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.检查词典数据库完整性ToolStripMenuItem.Text = "检查词典数据库完整性";
            this.检查词典数据库完整性ToolStripMenuItem.Click += new System.EventHandler(this.检查词典数据库完整性ToolStripMenuItem_Click);
            // 
            // 导入文件夹ToolStripMenuItem
            // 
            this.导入文件夹ToolStripMenuItem.Name = "导入文件夹ToolStripMenuItem";
            this.导入文件夹ToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.导入文件夹ToolStripMenuItem.Text = "导入文件夹（有道）";
            this.导入文件夹ToolStripMenuItem.Click += new System.EventHandler(this.导入文件夹ToolStripMenuItem_Click);
            // 
            // 导入文件夹MerriamToolStripMenuItem
            // 
            this.导入文件夹MerriamToolStripMenuItem.Name = "导入文件夹MerriamToolStripMenuItem";
            this.导入文件夹MerriamToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.导入文件夹MerriamToolStripMenuItem.Text = "导入文件夹（Merriam）";
            this.导入文件夹MerriamToolStripMenuItem.Click += new System.EventHandler(this.导入文件夹MerriamToolStripMenuItem_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(243, 6);
            // 
            // 转化为Kindle字典ToolStripMenuItem
            // 
            this.转化为Kindle字典ToolStripMenuItem.Name = "转化为Kindle字典ToolStripMenuItem";
            this.转化为Kindle字典ToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.转化为Kindle字典ToolStripMenuItem.Text = "转化为Kindle字典（有道）";
            this.转化为Kindle字典ToolStripMenuItem.Click += new System.EventHandler(this.转化为Kindle字典ToolStripMenuItem_Click);
            // 
            // 转化为Kindle字典MerriamToolStripMenuItem
            // 
            this.转化为Kindle字典MerriamToolStripMenuItem.Name = "转化为Kindle字典MerriamToolStripMenuItem";
            this.转化为Kindle字典MerriamToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.转化为Kindle字典MerriamToolStripMenuItem.Text = "转化为Kindle字典（Merriam）";
            this.转化为Kindle字典MerriamToolStripMenuItem.Click += new System.EventHandler(this.转化为Kindle字典MerriamToolStripMenuItem_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // codeSplitButton
            // 
            this.codeSplitButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.codeSplitButton.Image = ((System.Drawing.Image)(resources.GetObject("codeSplitButton.Image")));
            this.codeSplitButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.codeSplitButton.Name = "codeSplitButton";
            this.codeSplitButton.Size = new System.Drawing.Size(48, 22);
            this.codeSplitButton.Text = "代码";
            this.codeSplitButton.ButtonClick += new System.EventHandler(this.codeSplitButton_ButtonClick);
            // 
            // 删除偶数行ToolStripMenuItem
            // 
            this.删除偶数行ToolStripMenuItem.Name = "删除偶数行ToolStripMenuItem";
            this.删除偶数行ToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.删除偶数行ToolStripMenuItem.Text = "删除偶数行";
            this.删除偶数行ToolStripMenuItem.Click += new System.EventHandler(this.删除偶数行ToolStripMenuItem_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1460, 657);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.toolStrip1);
            this.Name = "mainForm";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainForm_FormClosing);
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.contextMenuStrip.ResumeLayout(false);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.ComboBox databaseBox;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem 复制ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 粘贴ToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox findBox;
        private System.Windows.Forms.ToolStripSplitButton 查找;
        private System.Windows.Forms.ToolStripMenuItem 保留正则表达式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton 翻译;
        private System.Windows.Forms.ToolStripButton 程序;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem 保存;
        private System.Windows.Forms.ToolStripSplitButton 压缩;
        private System.Windows.Forms.ToolStripMenuItem 压缩目录加密ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton 新建;
        private System.Windows.Forms.ToolStripButton 中文;
        private System.Windows.Forms.ToolStripSplitButton 模拟;
        private System.Windows.Forms.ToolStripMenuItem 获取当前鼠标坐标ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 模拟上传百度云ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 获取当前鼠标窗口句柄ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 保留行正则表达式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 刷选行正则表达式ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton 代码;
        private System.Windows.Forms.ToolStripButton 粗体;
        private System.Windows.Forms.ToolStripButton 标题;
        private System.Windows.Forms.ToolStripButton 斜体;
        private System.Windows.Forms.ToolStripButton 图片;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton HTMLS;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSplitButton StringBuilderButton;
        private System.Windows.Forms.ToolStripMenuItem 文件到数组ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩CSharp目录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton UL;
        private System.Windows.Forms.ToolStripButton Markdowns;
        private System.Windows.Forms.ToolStripMenuItem 翻译ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 代码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem 粘贴代码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton 删除;
        private System.Windows.Forms.ToolStripSplitButton 格式化;
        private System.Windows.Forms.ToolStripMenuItem 换行符ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSplitButton 其他;
        private System.Windows.Forms.ToolStripMenuItem 执行命令无窗口ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 格式化成一行ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton JavaScript;
        private System.Windows.Forms.ToolStripMenuItem 逃逸JavaScriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton 服务器;
        private System.Windows.Forms.ToolStripMenuItem 逃逸JavaScript数组ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 字符串到数组ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 排序ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 插入元数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 插入新文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 随机字符串ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 更新文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton3;
        private System.Windows.Forms.ToolStripMenuItem 排序ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton 顶端;
        private System.Windows.Forms.ToolStripButton 底端;
        private System.Windows.Forms.ToolStripMenuItem 复制表格ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 文件SHA1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩JavaScriptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem javaScript模板ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩HTMToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton Safari;
        private System.Windows.Forms.ToolStripMenuItem 创建文件夹ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 创建目录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 离线文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 转换成HTM文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 下载图片ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成未下载文件列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩子目录加密ToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton H3;
        private System.Windows.Forms.ToolStripButton 粘贴代码;
        private System.Windows.Forms.ToolStripButton H2;
        private System.Windows.Forms.ToolStripButton 目录;
        private System.Windows.Forms.ToolStripSeparator 置顶;
        private System.Windows.Forms.ToolStripButton 粘贴格式;
        private System.Windows.Forms.ToolStripMenuItem 压缩子目录ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripSplitButton 图片Button;
        private System.Windows.Forms.ToolStripMenuItem qRDecoderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩单个文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem 字符串到字节数组多行ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripSplitButton CookBook;
        private System.Windows.Forms.ToolStripButton 置顶Button;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 导出全部ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成未下载文件列表imagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton2;
        private System.Windows.Forms.ToolStripMenuItem 提取链接列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton H4;
        private System.Windows.Forms.ToolStripMenuItem programmingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 创建EpubToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 解压子目录加密ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 压缩IntellijAndroidToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton 词典;
        private System.Windows.Forms.ToolStripMenuItem 导入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 检查词典数据库完整性ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导入文件夹ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 字符串到数组简单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripMenuItem 转化为Kindle字典ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导入文件夹MerriamToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 转化为Kindle字典MerriamToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem 整理Epub文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 标题2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 粘贴为代码块ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 格式化C代码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pdfToTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem 整理Mobi文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSplitButton codeSplitButton;
        private System.Windows.Forms.ToolStripMenuItem 导入文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导出文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton formatButton;
        private System.Windows.Forms.ToolStripButton h1Button;
        private System.Windows.Forms.ToolStripMenuItem 格式化ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton 插入元数据;
        private System.Windows.Forms.ToolStripComboBox replaceBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem 替换所选内容ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 剪切ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem 粘贴格式化源代码ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除偶数行ToolStripMenuItem;
    }
}

